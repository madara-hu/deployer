# 🔥 Hustler Agency Portfolio

A premium, highly interactive portfolio website with an "Interactive Dark Room" concept. Built with Next.js 14, TypeScript, Tailwind CSS, GSAP, and Framer Motion.

![Tech Stack](https://img.shields.io/badge/Next.js-14-black) ![TypeScript](https://img.shields.io/badge/TypeScript-5-blue) ![Tailwind](https://img.shields.io/badge/Tailwind-3-38bdf8) ![GSAP](https://img.shields.io/badge/GSAP-3-88CE02) ![Framer Motion](https://img.shields.io/badge/Framer_Motion-11-0055FF)

## ✨ Features

- **Interactive Dark Room** - Pull the lamp cord to illuminate the website
- **Animated Stickman** - Walks in, waves, and exits after the light turns on
- **Volumetric Light Effects** - Realistic beam, ambient glow, and floating dust particles
- **Smooth Scroll** - Powered by Lenis for buttery-smooth scrolling
- **3D Tilt Cards** - Glassmorphism service cards with mouse-tracking tilt
- **Typing Effect** - Dynamic text animations in the hero section
- **Fully Responsive** - Optimized for all devices with `clamp()` sizing
- **Static Export** - Ready for Cloudflare Pages deployment

## 🛠️ Tech Stack

| Technology | Purpose |
|---|---|
| Next.js 14 (App Router) | Framework |
| TypeScript | Type Safety |
| Tailwind CSS | Styling |
| GSAP | Lamp physics & light animations |
| Framer Motion | Page transitions & stickman |
| Lenis | Smooth scrolling |
| Lucide React | Icons |

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production (static export)
npm run build

# Preview production build
npm run start
```

## 📁 Project Structure

```
hustler-agency/
├── src/
│   ├── app/
│   │   ├── layout.tsx          # Root layout with fonts
│   │   ├── page.tsx            # Main page
│   │   └── globals.css         # Global styles & animations
│   ├── components/
│   │   ├── Lamp.tsx            # Interactive desk lamp with cord pull
│   │   ├── Stickman.tsx        # Animated SVG stickman character
│   │   ├── Hero.tsx            # Hero section with lamp interaction
│   │   ├── Navigation.tsx      # Fixed navigation bar
│   │   ├── About.tsx           # About me section with skills
│   │   ├── Services.tsx        # Services with 3D tilt cards
│   │   ├── Work.tsx            # Project portfolio grid
│   │   ├── Contact.tsx         # Contact form with WhatsApp/Email
│   │   ├── Footer.tsx          # Minimal footer
│   │   ├── TypingEffect.tsx    # Typing animation component
│   │   ├── LampContext.tsx     # Shared lamp state context
│   │   └── SmoothScroll.tsx    # Lenis smooth scroll wrapper
│   └── lib/
│       ├── projects.ts         # Project data (easy to update!)
│       └── utils.ts            # Utility functions
├── public/
│   └── photo.png               # Profile photo
├── package.json
├── next.config.mjs             # Static export config
├── tailwind.config.ts          # Theme customization
└── setup.sh                    # One-click setup script
```

## 🎨 Customization

### Update Projects
Edit `src/lib/projects.ts`:
```typescript
export const projects: Project[] = [
  {
    id: 1,
    title: 'Your Project',
    description: 'Description here...',
    tags: ['Next.js', 'React'],
    gradient: 'from-blue-500/20 to-purple-500/20',
    link: 'https://your-project.com',
  },
  // Add more...
];
```

### Update Photo
Replace `public/photo.png` with your own image.

### Update Contact Info
Edit `src/components/Contact.tsx`:
- WhatsApp: `https://wa.me/YOUR_NUMBER`
- Email: `mailto:YOUR_EMAIL`

### Update Colors
Edit `tailwind.config.ts` → `theme.extend.colors`

### Update Typography
Edit `src/app/layout.tsx` → font imports

## ☁️ Deploy to Cloudflare Pages

1. Push code to GitHub/GitLab
2. Go to [Cloudflare Pages Dashboard](https://dash.cloudflare.com/?to=/:account/pages)
3. Click **Create a project** → **Connect to Git**
4. Select your repository
5. Configure:
   - **Build command:** `npm run build`
   - **Build output directory:** `out`
6. Click **Deploy**

## 📱 The Interactive Experience

1. **Page loads** → Dark room with a desk lamp and glowing cord
2. **Pull the cord** → Drag the neon-green knob downward
3. **Light turns on** → Bulb brightens, beam expands, ambient glow fills the room
4. **Content reveals** → Hero text, photo, and navigation fade in smoothly
5. **Stickman enters** → Walks in from the left, waves at the lamp, exits right
6. **Scroll down** → Explore About, Services, Work, and Contact sections

## 🎯 Performance

- Static HTML export (no server required)
- Optimized bundle size (~172KB first load)
- No runtime JavaScript for static content
- CDN-ready for global deployment

## 📄 License

MIT License - Feel free to use this for your own portfolio!

---

Built with ❤️ by [Hustler Agency](https://hustleragency.com)
