export interface Project {
  id: number;
  title: string;
  description: string;
  tags: string[];
  gradient: string;
  link: string;
}

export const projects: Project[] = [
  {
    id: 1,
    title: 'Luxe E-Commerce',
    description:
      'A premium e-commerce platform with real-time inventory, AI recommendations, and seamless checkout.',
    tags: ['Next.js', 'Stripe', 'PostgreSQL', 'AI'],
    gradient: 'from-amber-500/20 to-orange-600/20',
    link: '#',
  },
  {
    id: 2,
    title: 'FinTech Dashboard',
    description:
      'Real-time financial analytics dashboard with interactive charts and portfolio management.',
    tags: ['React', 'D3.js', 'Node.js', 'WebSocket'],
    gradient: 'from-blue-500/20 to-cyan-500/20',
    link: '#',
  },
  {
    id: 3,
    title: 'SaaS Landing Page',
    description:
      'High-converting landing page with advanced animations, A/B testing, and 98+ PageSpeed score.',
    tags: ['Next.js', 'GSAP', 'Tailwind', 'Vercel'],
    gradient: 'from-purple-500/20 to-pink-500/20',
    link: '#',
  },
  {
    id: 4,
    title: 'Creative Portfolio',
    description:
      'Award-winning portfolio website with 3D experiences, smooth scroll, and immersive storytelling.',
    tags: ['Three.js', 'GSAP', 'React', 'WebGL'],
    gradient: 'from-emerald-500/20 to-teal-500/20',
    link: '#',
  },
  {
    id: 5,
    title: 'Health & Fitness App',
    description:
      'Cross-platform mobile app with workout tracking, nutrition plans, and social features.',
    tags: ['React Native', 'Firebase', 'TypeScript'],
    gradient: 'from-rose-500/20 to-red-500/20',
    link: '#',
  },
  {
    id: 6,
    title: 'Brand Identity System',
    description:
      'Complete brand identity including logo, typography, color system, and design guidelines.',
    tags: ['Branding', 'Figma', 'Illustrator', 'Strategy'],
    gradient: 'from-lime-500/20 to-green-500/20',
    link: '#',
  },
];
