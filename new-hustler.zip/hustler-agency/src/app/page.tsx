import Navigation from '@/components/Navigation';
import Hero from '@/components/Hero';
import About from '@/components/About';
import Services from '@/components/Services';
import Work from '@/components/Work';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';
import SmoothScroll from '@/components/SmoothScroll';
import { LampProvider } from '@/components/LampContext';

export default function Home() {
  return (
    <LampProvider>
      <SmoothScroll>
        <Navigation />
        <main>
          <Hero />
          <About />
          <Services />
          <Work />
          <Contact />
        </main>
        <Footer />
      </SmoothScroll>
    </LampProvider>
  );
}
