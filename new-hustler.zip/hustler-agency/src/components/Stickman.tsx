'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

interface StickmanProps {
  isActive: boolean;
}

export default function Stickman({ isActive }: StickmanProps) {
  const [phase, setPhase] = useState<'entering' | 'stopped' | 'waving' | 'exiting' | 'done'>('done');

  useEffect(() => {
    if (!isActive) return;

    // Phase 1: Enter from left (2s)
    const t1 = setTimeout(() => setPhase('entering'), 500);

    // Phase 2: Stop and look (1s after entering)
    const t2 = setTimeout(() => setPhase('stopped'), 3000);

    // Phase 3: Wave (0.5s after stopping)
    const t3 = setTimeout(() => setPhase('waving'), 3800);

    // Phase 4: Exit right (1.5s after waving)
    const t4 = setTimeout(() => setPhase('exiting'), 5500);

    // Phase 5: Done
    const t5 = setTimeout(() => setPhase('done'), 7500);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
      clearTimeout(t5);
    };
  }, [isActive]);

  if (phase === 'done') return null;

  const isWalking = phase === 'entering' || phase === 'exiting';

  return (
    <motion.div
      className="absolute bottom-[15%] z-10 pointer-events-none"
      initial={{
        x: phase === 'entering' ? '-20vw' : '50vw',
        opacity: 0,
      }}
      animate={{
        x:
          phase === 'entering'
            ? '35vw'
            : phase === 'stopped' || phase === 'waving'
            ? '35vw'
            : phase === 'exiting'
            ? '120vw'
            : '35vw',
        opacity: phase === 'exiting' ? [1, 1, 0] : 1,
      }}
      transition={{
        duration: phase === 'entering' ? 2.5 : phase === 'exiting' ? 2 : 0,
        ease: 'easeInOut',
        opacity: { duration: 0.5 },
      }}
      style={{
        width: 'clamp(50px, 8vw, 80px)',
        height: 'clamp(100px, 16vw, 160px)',
      }}
    >
      <svg
        viewBox="0 0 100 200"
        className="w-full h-full"
        style={{ overflow: 'visible' }}
      >
        {/* Head */}
        <motion.circle
          cx="50"
          cy="28"
          r="14"
          fill="none"
          stroke="#CCFF00"
          strokeWidth="2.5"
          animate={
            phase === 'waving'
              ? { rotate: [0, 5, -5, 0] }
              : {}
          }
          transition={{ duration: 0.6, repeat: phase === 'waving' ? 2 : 0 }}
          style={{ originX: '50px', originY: '28px' }}
        />

        {/* Eyes */}
        <motion.circle
          cx="44"
          cy="26"
          r="2"
          fill="#CCFF00"
          animate={phase === 'waving' ? { scaleY: [1, 0.3, 1] } : {}}
          transition={{ duration: 0.3, repeat: phase === 'waving' ? 3 : 0 }}
          style={{ originX: '44px', originY: '26px' }}
        />
        <motion.circle
          cx="56"
          cy="26"
          r="2"
          fill="#CCFF00"
          animate={phase === 'waving' ? { scaleY: [1, 0.3, 1] } : {}}
          transition={{ duration: 0.3, repeat: phase === 'waving' ? 3 : 0 }}
          style={{ originX: '56px', originY: '26px' }}
        />

        {/* Smile */}
        <motion.path
          d="M 44 32 Q 50 37 56 32"
          fill="none"
          stroke="#CCFF00"
          strokeWidth="1.5"
          strokeLinecap="round"
          animate={phase === 'waving' ? { d: 'M 43 31 Q 50 38 57 31' } : {}}
          transition={{ duration: 0.3 }}
        />

        {/* Body */}
        <motion.line
          x1="50"
          y1="42"
          x2="50"
          y2="110"
          stroke="#CCFF00"
          strokeWidth="2.5"
          strokeLinecap="round"
          animate={
            isWalking
              ? { y: [0, 3, 0, 3, 0] }
              : {}
          }
          transition={{ duration: 0.5, repeat: Infinity }}
        />

        {/* Left Arm */}
        <motion.line
          x1="50"
          y1="58"
          x2="28"
          y2="90"
          stroke="#CCFF00"
          strokeWidth="2.5"
          strokeLinecap="round"
          animate={
            isWalking
              ? {
                  x2: [28, 42, 58, 42, 28],
                  y2: [90, 82, 90, 82, 90],
                }
              : phase === 'waving'
              ? {
                  x2: [28, 15, 25, 10, 28],
                  y2: [90, 55, 60, 50, 90],
                }
              : {}
          }
          transition={
            phase === 'waving'
              ? { duration: 0.4, repeat: 4 }
              : { duration: 0.5, repeat: Infinity }
          }
        />

        {/* Right Arm */}
        <motion.line
          x1="50"
          y1="58"
          x2="72"
          y2="90"
          stroke="#CCFF00"
          strokeWidth="2.5"
          strokeLinecap="round"
          animate={
            isWalking
              ? {
                  x2: [72, 58, 42, 58, 72],
                  y2: [90, 82, 90, 82, 90],
                }
              : {}
          }
          transition={{ duration: 0.5, repeat: Infinity }}
        />

        {/* Left Leg */}
        <motion.line
          x1="50"
          y1="110"
          x2="35"
          y2="158"
          stroke="#CCFF00"
          strokeWidth="2.5"
          strokeLinecap="round"
          animate={
            isWalking
              ? {
                  x2: [35, 50, 65, 50, 35],
                  y2: [158, 148, 158, 148, 158],
                }
              : {}
          }
          transition={{ duration: 0.5, repeat: Infinity }}
        />

        {/* Right Leg */}
        <motion.line
          x1="50"
          y1="110"
          x2="65"
          y2="158"
          stroke="#CCFF00"
          strokeWidth="2.5"
          strokeLinecap="round"
          animate={
            isWalking
              ? {
                  x2: [65, 50, 35, 50, 65],
                  y2: [158, 148, 158, 148, 158],
                }
              : {}
          }
          transition={{ duration: 0.5, repeat: Infinity }}
        />

        {/* Glow effect */}
        <motion.circle
          cx="50"
          cy="100"
          r="40"
          fill="none"
          stroke="#CCFF00"
          strokeWidth="0.5"
          animate={{ opacity: [0.1, 0.3, 0.1], r: [38, 42, 38] }}
          transition={{ duration: 2, repeat: Infinity }}
        />
      </svg>
    </motion.div>
  );
}
