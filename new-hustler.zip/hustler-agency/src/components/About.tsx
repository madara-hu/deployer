'use client';

import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { Code2, Palette, Rocket, Zap } from 'lucide-react';

const stats = [
  { value: '50+', label: 'Projects Delivered' },
  { value: '30+', label: 'Happy Clients' },
  { value: '3+', label: 'Years Experience' },
  { value: '99%', label: 'Client Satisfaction' },
];

const skills = [
  { name: 'Next.js / React', level: 95 },
  { name: 'TypeScript', level: 90 },
  { name: 'UI/UX Design', level: 88 },
  { name: 'Node.js / API', level: 85 },
  { name: 'Tailwind CSS', level: 92 },
  { name: 'GSAP / Animations', level: 87 },
];

export default function About() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="about" className="relative py-24 md:py-32 px-6 md:px-10 bg-[#050505]">
      {/* Subtle gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#050505] via-[#080808] to-[#050505] pointer-events-none" />

      <div ref={ref} className="relative max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center"
        >
          {/* Photo */}
          <div className="relative">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative rounded-2xl overflow-hidden"
            >
              <div className="aspect-[4/5] relative">
                <img
                  src="/photo.png"
                  alt="Navneet - Founder of Hustler Agency"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent" />
              </div>
              {/* Glow border */}
              <div className="absolute -inset-[1px] rounded-2xl bg-gradient-to-br from-accent/30 via-transparent to-lamp-gold/20 -z-10 blur-sm" />
            </motion.div>

            {/* Floating badges */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="absolute -top-4 -right-4 md:top-4 md:right-[-20px] glass-card px-4 py-3 flex items-center gap-2"
            >
              <Rocket size={18} className="text-accent" />
              <span className="text-sm font-medium">Full-Stack Dev</span>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.8 }}
              className="absolute -bottom-4 -left-4 md:bottom-8 md:left-[-20px] glass-card px-4 py-3 flex items-center gap-2"
            >
              <Palette size={18} className="text-accent" />
              <span className="text-sm font-medium">UI/UX Designer</span>
            </motion.div>
          </div>

          {/* Content */}
          <div>
            <motion.span
              initial={{ opacity: 0 }}
              animate={isInView ? { opacity: 1 } : {}}
              transition={{ delay: 0.3 }}
              className="text-accent text-sm font-medium tracking-widest uppercase"
            >
              About Me
            </motion.span>

            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mt-3 mb-6"
            >
              Hi, I&apos;m{' '}
              <span className="text-accent">Navneet</span>
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="text-white/50 text-lg leading-relaxed mb-8"
            >
              I am a creative developer and designer based in India, passionate about
              crafting digital experiences that leave lasting impressions. At Hustler
              Agency, we blend cutting-edge technology with stunning design to build
              websites that don&apos;t just look amazing — they perform exceptionally.
            </motion.p>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="text-white/40 leading-relaxed mb-10"
            >
              From concept to deployment, I handle every aspect of the development
              process. Whether it&apos;s a sleek portfolio, a complex web application, or
              a complete brand identity — I bring ideas to life with precision and creativity.
            </motion.p>

            {/* Skills */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.7 }}
              className="space-y-4"
            >
              {skills.map((skill, i) => (
                <div key={skill.name}>
                  <div className="flex justify-between text-sm mb-1.5">
                    <span className="text-white/70">{skill.name}</span>
                    <span className="text-accent">{skill.level}%</span>
                  </div>
                  <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={isInView ? { width: `${skill.level}%` } : {}}
                      transition={{ duration: 1, delay: 0.8 + i * 0.1, ease: 'easeOut' }}
                      className="h-full bg-gradient-to-r from-accent to-lamp-gold rounded-full"
                    />
                  </div>
                </div>
              ))}
            </motion.div>
          </div>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16 md:mt-24"
        >
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 1.1 + i * 0.1 }}
              className="glass-card p-6 text-center"
            >
              <div className="font-display text-3xl md:text-4xl font-bold text-accent mb-1">
                {stat.value}
              </div>
              <div className="text-white/40 text-sm">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
