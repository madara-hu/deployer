'use client';

import { motion, useMotionValue, useTransform } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import {
  Code2,
  Palette,
  Search,
  Smartphone,
  ShoppingBag,
  Layers,
} from 'lucide-react';

const services = [
  {
    icon: Code2,
    title: 'Web Development',
    description:
      'High-performance websites built with Next.js, React, and modern frameworks. Blazing fast, SEO-optimized, and scalable.',
    tags: ['Next.js', 'React', 'TypeScript', 'Node.js'],
  },
  {
    icon: Palette,
    title: 'UI/UX Design',
    description:
      'Beautiful, intuitive interfaces that users love. From wireframes to pixel-perfect designs with complete design systems.',
    tags: ['Figma', 'Prototyping', 'Design Systems', 'User Research'],
  },
  {
    icon: ShoppingBag,
    title: 'E-Commerce',
    description:
      'Full-featured online stores with seamless checkout, inventory management, and conversion-optimized user flows.',
    tags: ['Shopify', 'Stripe', 'WooCommerce', 'Custom'],
  },
  {
    icon: Search,
    title: 'SEO Optimization',
    description:
      'Data-driven SEO strategies that boost your visibility. Technical SEO, content optimization, and performance tuning.',
    tags: ['Technical SEO', 'Core Web Vitals', 'Analytics', 'Content'],
  },
  {
    icon: Smartphone,
    title: 'Mobile Apps',
    description:
      'Cross-platform mobile applications with native-like performance. Beautiful UI with smooth animations and offline support.',
    tags: ['React Native', 'iOS', 'Android', 'Expo'],
  },
  {
    icon: Layers,
    title: 'Brand Identity',
    description:
      'Complete brand systems that tell your story. Logo design, typography, color palettes, and comprehensive brand guidelines.',
    tags: ['Logo Design', 'Brand Guide', 'Typography', 'Color Theory'],
  },
];

function TiltCard({
  children,
  index,
}: {
  children: React.ReactNode;
  index: number;
}) {
  const cardRef = useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const rotateX = useTransform(y, [-100, 100], [8, -8]);
  const rotateY = useTransform(x, [-100, 100], [-8, 8]);

  function handleMouse(e: React.MouseEvent) {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    x.set(e.clientX - centerX);
    y.set(e.clientY - centerY);
  }

  function handleLeave() {
    x.set(0);
    y.set(0);
  }

  return (
    <motion.div
      ref={cardRef}
      onMouseMove={handleMouse}
      onMouseLeave={handleLeave}
      style={{ rotateX, rotateY, transformStyle: 'preserve-3d' }}
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="glass-card p-6 md:p-8 cursor-default"
    >
      {children}
    </motion.div>
  );
}

export default function Services() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section
      id="services"
      className="relative py-24 md:py-32 px-6 md:px-10 bg-[#050505]"
    >
      <div className="absolute inset-0 bg-gradient-to-b from-[#050505] via-[#0a0a0a] to-[#050505] pointer-events-none" />

      <div ref={ref} className="relative max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16 md:mb-20"
        >
          <span className="text-accent text-sm font-medium tracking-widest uppercase">
            What I Do
          </span>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mt-3 mb-5">
            Services I <span className="text-accent">Offer</span>
          </h2>
          <p className="text-white/40 max-w-2xl mx-auto text-lg">
            End-to-end digital solutions crafted with precision and creativity.
            Every project is built to perform and designed to impress.
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, i) => (
            <TiltCard key={service.title} index={i}>
              <motion.div
                style={{ transform: 'translateZ(30px)' }}
                className="space-y-4"
              >
                <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center">
                  <service.icon size={24} className="text-accent" />
                </div>
                <h3 className="font-display text-xl font-semibold text-white">
                  {service.title}
                </h3>
                <p className="text-white/40 text-sm leading-relaxed">
                  {service.description}
                </p>
                <div className="flex flex-wrap gap-2 pt-2">
                  {service.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-xs px-2.5 py-1 rounded-full bg-white/5 text-white/50 border border-white/5"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </motion.div>
            </TiltCard>
          ))}
        </div>
      </div>
    </section>
  );
}
