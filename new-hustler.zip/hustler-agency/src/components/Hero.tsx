'use client';

import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Lamp from './Lamp';
import Stickman from './Stickman';
import TypingEffect from './TypingEffect';
import { ArrowDown, Sparkles } from 'lucide-react';
import { useLamp } from './LampContext';

export default function Hero() {
  const { isLightOn, turnOnLight } = useLamp();
  const [showStickman, setShowStickman] = useState(false);
  const handleLightOn = useCallback(() => {
    turnOnLight();
    setTimeout(() => setShowStickman(true), 800);
  }, [turnOnLight]);

  return (
    <section className="relative min-h-screen w-full overflow-hidden bg-[#050505]">
      {/* Ambient light effects */}
      <div className="ambient-glow" />
      <div className="light-beam-overlay" />

      {/* Dark room content */}
      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Main hero grid */}
        <div className="flex-1 flex items-center relative px-6 md:px-10 pt-20">
          <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            {/* Left: Text Content */}
            <div className="order-2 lg:order-1">
              <AnimatePresence>
                {isLightOn && (
                  <motion.div
                    initial={{ opacity: 0, x: -30 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 1, ease: 'easeOut', delay: 0.3 }}
                  >
                    {/* Overline */}
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.5 }}
                      className="flex items-center gap-2 mb-4 md:mb-6"
                    >
                      <Sparkles size={14} className="text-accent" />
                      <span className="text-accent text-xs md:text-sm font-medium tracking-widest uppercase">
                        Premium Digital Agency
                      </span>
                    </motion.div>

                    {/* Main heading */}
                    <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-bold leading-[0.9] mb-6 md:mb-8">
                      <span className="block text-white">HUSTLER</span>
                      <span className="block">
                        <span className="text-white/90">AGEN</span>
                        <span className="text-accent">CY</span>
                      </span>
                    </h1>

                    {/* Typing effect */}
                    <motion.p
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.8 }}
                      className="text-lg md:text-xl text-white/50 mb-8 md:mb-10 max-w-md font-light"
                    >
                      <TypingEffect
                        texts={[
                          'I build websites that break the internet.',
                          'Crafting digital experiences that convert.',
                          'Design meets performance.',
                        ]}
                      />
                    </motion.p>

                    {/* CTA Buttons */}
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 1 }}
                      className="flex flex-wrap gap-4"
                    >
                      <a href="#work" className="neon-btn">
                        View My Work
                        <ArrowDown size={16} className="rotate-[-90deg]" />
                      </a>
                      <a
                        href="#contact"
                        className="px-8 py-3.5 rounded-full border border-white/15 text-white/70 hover:text-white hover:border-white/30 transition-all duration-300 text-sm font-medium"
                      >
                        Get In Touch
                      </a>
                    </motion.div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Before light on - instruction text */}
              <AnimatePresence>
                {!isLightOn && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.5 }}
                    className="text-center lg:text-left"
                  >
                    <p className="text-white/20 text-sm md:text-base animate-pulse">
                      Pull the cord to illuminate the room...
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Right: Lamp + Photo */}
            <div className="order-1 lg:order-2 relative flex items-center justify-center">
              {/* Photo (appears when light is on) */}
              <AnimatePresence>
                {isLightOn && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 1, delay: 0.5, ease: 'easeOut' }}
                    className="absolute left-0 md:left-[-10%] top-1/2 -translate-y-1/2 z-20 w-[140px] md:w-[200px] lg:w-[220px]"
                  >
                    <div className="photo-glow-frame active rounded-2xl overflow-hidden shadow-2xl">
                      <img
                        src="/photo.png"
                        alt="Navneet - Hustler Agency"
                        className="w-full h-auto object-cover"
                        style={{
                          filter: 'brightness(1.1) contrast(1.05)',
                        }}
                      />
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Lamp */}
              <div className="relative z-30 w-full max-w-[320px] md:max-w-[380px]">
                <Lamp
                  isOn={isLightOn}
                  onLightOn={handleLightOn}
                />
              </div>

              {/* Stickman */}
              <Stickman isActive={showStickman} />
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <AnimatePresence>
          {isLightOn && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 2 }}
              className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20"
            >
              <motion.div
                animate={{ y: [0, 8, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="flex flex-col items-center gap-2 text-white/30"
              >
                <span className="text-xs tracking-widest uppercase">Scroll</span>
                <ArrowDown size={16} />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
