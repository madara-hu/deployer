'use client';

import { createContext, useContext, useState, useCallback } from 'react';

interface LampContextType {
  isLightOn: boolean;
  turnOnLight: () => void;
}

const LampContext = createContext<LampContextType>({
  isLightOn: false,
  turnOnLight: () => {},
});

export function LampProvider({ children }: { children: React.ReactNode }) {
  const [isLightOn, setIsLightOn] = useState(false);

  const turnOnLight = useCallback(() => {
    setIsLightOn(true);
  }, []);

  return (
    <LampContext.Provider value={{ isLightOn, turnOnLight }}>
      {children}
    </LampContext.Provider>
  );
}

export function useLamp() {
  return useContext(LampContext);
}
