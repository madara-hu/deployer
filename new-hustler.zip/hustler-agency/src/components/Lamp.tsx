'use client';

import { useEffect, useRef, useCallback } from 'react';
import gsap from 'gsap';

interface LampProps {
  isOn: boolean;
  onLightOn: () => void;
}

export default function Lamp({ isOn, onLightOn }: LampProps) {
  const cordKnobRef = useRef<SVGCircleElement>(null);
  const cordLineRef = useRef<SVGLineElement>(null);
  const bulbRef = useRef<SVGCircleElement>(null);
  const bulbGlowRef = useRef<SVGCircleElement>(null);
  const beamRef = useRef<SVGPolygonElement>(null);
  const dustContainerRef = useRef<SVGGElement>(null);
  const isDragging = useRef(false);
  const hasTriggered = useRef(false);
  const dragStart = useRef({ x: 0, y: 0 });

  // Responsive lamp positions
  const getPositions = useCallback(() => {
    const isMobile = window.innerWidth < 768;
    return {
      cordAttachX: isMobile ? 200 : 340,
      cordAttachY: 220,
      cordRestX: isMobile ? 200 : 340,
      cordRestY: 340,
      bulbX: isMobile ? 200 : 340,
      bulbY: 225,
      threshold: 50,
    };
  }, []);

  useEffect(() => {
    const knob = cordKnobRef.current;
    const line = cordLineRef.current;
    const bulb = bulbRef.current;
    const bulbGlow = bulbGlowRef.current;
    const beam = beamRef.current;
    if (!knob || !line || !bulb || !bulbGlow || !beam) return;

    const pos = getPositions();

    // Subtle pulse animation on cord knob to attract attention
    const pulseTl = gsap.timeline({ repeat: -1, yoyo: true });
    pulseTl.to(knob, {
      attr: { r: 7 },
      duration: 1.5,
      ease: 'power1.inOut',
    });

    const getEventPos = (e: MouseEvent | TouchEvent) => {
      if ('touches' in e && e.touches.length > 0) {
        return { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }
      if ('changedTouches' in e && (e as TouchEvent).changedTouches.length > 0) {
        return {
          x: (e as TouchEvent).changedTouches[0].clientX,
          y: (e as TouchEvent).changedTouches[0].clientY,
        };
      }
      return { x: (e as MouseEvent).clientX, y: (e as MouseEvent).clientY };
    };

    const handleStart = (e: MouseEvent | TouchEvent) => {
      if (isOn || hasTriggered.current) return;
      isDragging.current = true;
      const evtPos = getEventPos(e);
      dragStart.current = { x: evtPos.x, y: evtPos.y };
      pulseTl.pause();
      e.preventDefault();
    };

    const handleMove = (e: MouseEvent | TouchEvent) => {
      if (!isDragging.current) return;
      const evtPos = getEventPos(e);

      const dx = evtPos.x - dragStart.current.x;
      const dy = evtPos.y - dragStart.current.y;
      const pullDistance = Math.max(0, dy);
      const maxPull = 80;
      const clampedPull = Math.min(pullDistance, maxPull);

      const newKnobX = pos.cordRestX + dx * 0.2;
      const newKnobY = pos.cordRestY + clampedPull;

      gsap.set(knob, {
        attr: { cx: newKnobX, cy: newKnobY },
      });
      gsap.set(line, {
        attr: { x2: newKnobX, y2: newKnobY },
      });

      // Visual feedback - knob grows as you pull
      const pullRatio = clampedPull / pos.threshold;
      gsap.set(knob, {
        attr: { r: 5 + pullRatio * 3 },
      });

      if (pullRatio > 0.8) {
        gsap.to(knob, {
          attr: { fill: '#FFD700' },
          duration: 0.2,
          overwrite: true,
        });
      }
    };

    const handleEnd = () => {
      if (!isDragging.current) return;
      isDragging.current = false;

      const knobY = parseFloat(knob.getAttribute('cy') || String(pos.cordRestY));
      const pullDistance = knobY - pos.cordRestY;

      if (pullDistance > pos.threshold && !hasTriggered.current) {
        hasTriggered.current = true;
        onLightOn();

        // Cord snap animation
        gsap.to(knob, {
          attr: { cy: pos.cordRestY + 20, r: 5, fill: '#CCFF00' },
          duration: 0.3,
          ease: 'power2.out',
        });
        gsap.to(line, {
          attr: { y2: pos.cordRestY + 20 },
          duration: 0.3,
          ease: 'power2.out',
        });

        // Bulb brightens
        gsap.to(bulb, {
          attr: { fill: '#FFF8DC', r: 16 },
          duration: 0.3,
          delay: 0.1,
        });
        gsap.to(bulbGlow, {
          attr: { r: 35, opacity: 0.6 },
          duration: 0.5,
          delay: 0.15,
        });

        // Light beam appears
        gsap.to(beam, {
          attr: { opacity: 0.7 },
          duration: 0.8,
          delay: 0.3,
          ease: 'power2.out',
        });

        // Ambient glow via CSS class
        setTimeout(() => {
          const ambientGlow = document.querySelector('.ambient-glow');
          const beamOverlay = document.querySelector('.light-beam-overlay');
          if (ambientGlow) {
            gsap.to(ambientGlow, {
              opacity: 1,
              duration: 1.2,
              ease: 'power2.out',
            });
          }
          if (beamOverlay) {
            gsap.to(beamOverlay, {
              opacity: 1,
              duration: 1,
              delay: 0.2,
              ease: 'power2.out',
            });
          }
        }, 200);

        // Dust particles appear
        if (dustContainerRef.current) {
          gsap.to(dustContainerRef.current, {
            opacity: 1,
            duration: 1,
            delay: 0.5,
          });
        }
      } else {
        // Spring back - elastic animation
        gsap.to(knob, {
          attr: {
            cx: pos.cordRestX,
            cy: pos.cordRestY,
            r: 5,
            fill: '#CCFF00',
          },
          duration: 0.8,
          ease: 'elastic.out(1, 0.4)',
        });
        gsap.to(line, {
          attr: { x2: pos.cordRestX, y2: pos.cordRestY },
          duration: 0.8,
          ease: 'elastic.out(1, 0.4)',
        });
        pulseTl.resume();
      }
    };

    // Mouse events
    knob.addEventListener('mousedown', handleStart);
    window.addEventListener('mousemove', handleMove);
    window.addEventListener('mouseup', handleEnd);

    // Touch events
    knob.addEventListener('touchstart', handleStart, { passive: false });
    window.addEventListener('touchmove', handleMove, { passive: false });
    window.addEventListener('touchend', handleEnd);

    return () => {
      knob.removeEventListener('mousedown', handleStart);
      window.removeEventListener('mousemove', handleMove);
      window.removeEventListener('mouseup', handleEnd);
      knob.removeEventListener('touchstart', handleStart);
      window.removeEventListener('touchmove', handleMove);
      window.removeEventListener('touchend', handleEnd);
      pulseTl.kill();
    };
  }, [isOn, onLightOn, getPositions]);

  return (
    <div
      className="relative w-full h-full flex items-center justify-center"
      style={{ minHeight: 'clamp(350px, 50vh, 600px)' }}
    >
      <svg
        viewBox="0 0 400 500"
        className="w-full h-full max-w-[350px] md:max-w-[400px]"
        style={{ filter: 'drop-shadow(0 0 20px rgba(0,0,0,0.5))' }}
      >
        <defs>
          <radialGradient id="bulbGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#FFF8DC" stopOpacity="1" />
            <stop offset="40%" stopColor="#FFD700" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#FFD700" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="beamGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#FFD700" stopOpacity="0.25" />
            <stop offset="50%" stopColor="#FFA500" stopOpacity="0.08" />
            <stop offset="100%" stopColor="#FFA500" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="shadeGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#2a2a2a" />
            <stop offset="100%" stopColor="#1a1a1a" />
          </linearGradient>
          <linearGradient id="poleGrad" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#333" />
            <stop offset="50%" stopColor="#444" />
            <stop offset="100%" stopColor="#2a2a2a" />
          </linearGradient>
          <linearGradient id="baseGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#3a3a3a" />
            <stop offset="100%" stopColor="#1a1a1a" />
          </linearGradient>
        </defs>

        {/* Light beam (hidden initially) */}
        <polygon
          ref={beamRef}
          points="310,235 370,235 420,490 260,490"
          fill="url(#beamGrad)"
          opacity="0"
        />

        {/* Desk surface */}
        <rect x="120" y="460" width="200" height="8" rx="4" fill="#1a1a1a" />
        <rect x="130" y="455" width="180" height="8" rx="4" fill="#222" />

        {/* Lamp base */}
        <ellipse cx="220" cy="452" rx="55" ry="12" fill="url(#baseGrad)" />
        <ellipse cx="220" cy="448" rx="50" ry="10" fill="#2a2a2a" />
        <ellipse cx="220" cy="446" rx="45" ry="8" fill="#333" />

        {/* Lamp pole */}
        <rect x="215" y="290" width="10" height="160" fill="url(#poleGrad)" rx="5" />

        {/* Lamp arm (curved) */}
        <path
          d="M 220 290 Q 220 220 280 195 Q 320 180 340 185"
          stroke="#333"
          strokeWidth="7"
          fill="none"
          strokeLinecap="round"
        />
        <path
          d="M 220 290 Q 220 220 280 195 Q 320 180 340 185"
          stroke="#3a3a3a"
          strokeWidth="4"
          fill="none"
          strokeLinecap="round"
        />

        {/* Lamp shade */}
        <path
          d="M 295 170 L 385 170 L 365 220 L 315 220 Z"
          fill="url(#shadeGrad)"
          stroke="#444"
          strokeWidth="1"
        />
        {/* Shade rim highlight */}
        <path
          d="M 295 170 L 385 170"
          stroke="#555"
          strokeWidth="2"
          strokeLinecap="round"
        />
        {/* Shade inner */}
        <path
          d="M 310 175 L 370 175 L 355 215 L 325 215 Z"
          fill="#111"
        />

        {/* Bulb glow (hidden initially) */}
        <circle
          ref={bulbGlowRef}
          cx="340"
          cy="225"
          r="15"
          fill="url(#bulbGlow)"
          opacity="0"
        />

        {/* Bulb */}
        <circle
          ref={bulbRef}
          cx="340"
          cy="225"
          r="12"
          fill="#333"
        />

        {/* Pull cord attachment point */}
        <circle cx="340" cy="220" r="3" fill="#555" />

        {/* Pull cord */}
        <line
          ref={cordLineRef}
          x1="340"
          y1="220"
          x2="340"
          y2="340"
          stroke="#999"
          strokeWidth="1.5"
          strokeLinecap="round"
        />

        {/* Cord knob (interactive) */}
        <circle
          ref={cordKnobRef}
          cx="340"
          cy="340"
          r="5"
          fill="#CCFF00"
          className="cursor-grab active:cursor-grabbing"
          style={{ filter: 'drop-shadow(0 0 4px rgba(204,255,0,0.6))' }}
        />

        {/* Dust particles in light beam */}
        <g ref={dustContainerRef} opacity="0">
          {Array.from({ length: 15 }).map((_, i) => (
            <circle
              key={i}
              cx={310 + Math.random() * 80}
              cy={260 + Math.random() * 200}
              r={Math.random() * 1.5 + 0.5}
              fill="rgba(255, 215, 0, 0.4)"
            >
              <animate
                attributeName="cy"
                values={`${260 + Math.random() * 200};${240 + Math.random() * 180};${260 + Math.random() * 200}`}
                dur={`${3 + Math.random() * 4}s`}
                repeatCount="indefinite"
              />
              <animate
                attributeName="cx"
                values={`${310 + Math.random() * 80};${320 + Math.random() * 70};${310 + Math.random() * 80}`}
                dur={`${4 + Math.random() * 3}s`}
                repeatCount="indefinite"
              />
              <animate
                attributeName="opacity"
                values="0.2;0.6;0.2"
                dur={`${2 + Math.random() * 3}s`}
                repeatCount="indefinite"
              />
            </circle>
          ))}
        </g>
      </svg>
    </div>
  );
}
