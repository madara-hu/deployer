#!/bin/bash
# ============================================
# Hustler Agency - Setup Script
# Complete portfolio website for Cloudflare Pages
# ============================================

set -e

echo "🚀 Setting up Hustler Agency Portfolio..."
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
  echo "❌ Node.js is required. Please install Node.js 18+ first."
  exit 1
fi

echo "✅ Node.js $(node -v) detected"

# Install dependencies
echo ""
echo "📦 Installing dependencies..."
npm install

# Build the project
echo ""
echo "🔨 Building project..."
npm run build

echo ""
echo "✅ Build complete! The static site is in the 'out/' directory."
echo ""
echo "📁 Deployment Instructions:"
echo "   Cloudflare Pages:"
echo "   1. Go to https://dash.cloudflare.com/?to=/:account/pages"
echo "   2. Click 'Create a project' → 'Connect to Git'"
echo "   3. Select your repository"
echo "   4. Set Build command: npm run build"
echo "   5. Set Build output directory: out"
echo "   6. Deploy!"
echo ""
echo "🖥️  Local Preview:"
echo "   npm run start"
echo "   (or: npx serve out)"
echo ""
echo "🎨 Customization:"
echo "   - Update projects in: src/lib/projects.ts"
echo "   - Replace photo in: public/photo.png"
echo "   - Update contact info in: src/components/Contact.tsx"
echo "   - Update colors in: tailwind.config.ts"
echo ""
echo "🎉 Happy coding!"
