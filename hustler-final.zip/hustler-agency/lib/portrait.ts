import 'server-only';
import { existsSync } from 'node:fs';
import path from 'node:path';

/**
 * A real portrait is optional at build time. Add public/images/navneet.jpg,
 * .jpeg, .png or .webp and rebuild; it is automatically used in both places.
 * No fictional person is shown when a portrait has not been supplied.
 */
export function getPortraitSrc(): string | null {
  const filenames = ['navneet.webp', 'navneet.jpg', 'navneet.jpeg', 'navneet.png'];
  const filename = filenames.find((name) => existsSync(path.join(process.cwd(), 'public', 'images', name)));
  return filename ? `/images/${filename}` : null;
}
