/**
 * PROJECTS — add a new object to this array to publish a project.
 * Place its cover in public/images and set `cover` to /images/your-file.webp.
 * Every object automatically gets a card and a statically exported detail page.
 * The examples below are original concept explorations, not client claims.
 */
export type Project = {
  slug: string;
  name: string;
  category: string;
  tagline: string;
  description: string;
  cover: string;
  coverAlt: string;
  tags: string[];
  palette: 'lime' | 'stone' | 'amber';
  brief: string;
  direction: string;
  services: string[];
};

export const projects: Project[] = [
  {
    slug: 'velocity',
    name: 'VELOCITY',
    category: 'PERFORMANCE / IDENTITY',
    tagline: 'Built for the relentless.',
    description: 'A bold identity system for a new kind of movement.',
    cover: '/images/velocity.webp',
    coverAlt: 'Black performance running shoe lit by a fine line of neon green.',
    tags: ['BRAND STRATEGY', 'VISUAL IDENTITY', 'CAMPAIGN'],
    palette: 'lime',
    brief: 'What if a performance brand felt less like a product and more like a state of mind? Velocity explores an identity for people who are always in motion.',
    direction: 'Sharp contrasts, kinetic typography and an electric signature colour come together in a world designed to feel as fast as it looks.',
    services: ['Brand strategy', 'Visual identity', 'Art direction', 'Campaign concept'],
  },
  {
    slug: 'monoform',
    name: 'MONOFORM',
    category: 'SPACES / DIGITAL',
    tagline: 'Less, but never ordinary.',
    description: 'A digital world shaped by space, light and intention.',
    cover: '/images/monoform.webp',
    coverAlt: 'A lime sphere in a quiet, monumental concrete gallery.',
    tags: ['DIGITAL DESIGN', 'ART DIRECTION', 'IDENTITY'],
    palette: 'stone',
    brief: 'Monoform imagines an architecture practice with a point of view: a belief that the most powerful spaces leave room to breathe.',
    direction: 'A restrained visual language pairs monumental imagery with precise typography and a confident accent of colour. Every detail has a reason to be there.',
    services: ['Creative direction', 'Visual identity', 'Digital design', 'Editorial concept'],
  },
  {
    slug: 'after-hours',
    name: 'AFTER HOURS',
    category: 'FRAGRANCE / CAMPAIGN',
    tagline: 'Made for the in-between.',
    description: 'An atmospheric brand concept that lingers a little longer.',
    cover: '/images/afterhours.webp',
    coverAlt: 'A dark glass fragrance bottle illuminated by a warm amber glow.',
    tags: ['CREATIVE DIRECTION', 'CAMPAIGN', 'BRAND WORLD'],
    palette: 'amber',
    brief: 'After Hours is a fragrance concept inspired by the moments between night and morning: magnetic, intimate and a little unexpected.',
    direction: 'Deep shadows, liquid amber and tactile details create a sensory world with the confidence to say more by showing less.',
    services: ['Brand world', 'Creative direction', 'Campaign concept', 'Content direction'],
  },
];
