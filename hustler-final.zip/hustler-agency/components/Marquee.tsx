import { Mark } from './Mark';

const words = ['GOOD IDEAS MOVE', 'BRAVE BRANDS WIN', 'MAKE IT MATTER', 'NEVER BLEND IN'];

export default function Marquee() {
  return (
    <div className="marquee" aria-hidden="true">
      <div className="marquee-track">
        {[0, 1].map((copy) => <div className="marquee-copy" key={copy}>{words.map((word) => <span key={word}><Mark />{word}</span>)}</div>)}
      </div>
    </div>
  );
}
