import Link from 'next/link';
import { ArrowUpRight } from 'lucide-react';
import { projects } from '@/lib/projects';
import SectionLabel from './SectionLabel';

export default function Work() {
  return (
    <section className="work-section section-pad" id="work" aria-labelledby="work-title">
      <div className="page-shell">
        <SectionLabel number="01">SELECTED WORK</SectionLabel>
        <div className="section-intro work-intro">
          <div>
            <p className="overline">A LITTLE LOOK AT WHAT&apos;S POSSIBLE</p>
            <h2 id="work-title" className="section-heading">Made to <span className="serif-accent">move.</span><br />Made to matter<span className="lime">.</span></h2>
          </div>
          <p className="section-intro-copy">A collection of concept explorations, crafted to show what happens when strategy meets a little creative courage.</p>
        </div>
        <div className="project-grid">
          {projects.map((project, index) => (
            <Link className={`project-card project-card-${index + 1}`} key={project.slug} href={`/projects/${project.slug}/`} aria-label={`Explore ${project.name} concept`}>
              <div className={`project-image project-image-${project.palette}`}>
                {/* Static, self-hosted and intentionally unoptimized by Next for Cloudflare export. */}
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={project.cover} alt={project.coverAlt} loading="lazy" decoding="async" />
                <span className="project-image-overlay" />
                <span className="project-topline"><span>HUSTLER / CONCEPT {String(index + 1).padStart(2, '0')}</span><span>✳</span></span>
                <span className="project-image-word">{project.name}<span>✳</span></span>
                <span className="project-image-meta">AN INDEPENDENT CREATIVE EXPLORATION</span>
                <span className="project-view-icon"><ArrowUpRight size={20} /></span>
              </div>
              <div className="project-details"><div><p className="project-category">{project.category}</p><h3>{project.name}</h3><p className="project-description">{project.description}</p></div><span className="project-number">/{String(index + 1).padStart(2, '0')}</span></div>
            </Link>
          ))}
        </div>
        <div className="work-endnote"><span><i /> CONCEPTS WITH CHARACTER</span><span>ALWAYS CURIOUS. ALWAYS CREATING.</span></div>
      </div>
    </section>
  );
}
