import Link from 'next/link';
import { ArrowUp, ArrowUpRight } from 'lucide-react';
import { Mark } from './Mark';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="page-shell">
        <div className="footer-main">
          <div className="footer-brand"><Link href="/" aria-label="Hustler Agency home"><Mark /><span>HUSTLER<br />AGENCY<span className="lime">.</span></span></Link><p>Independent thinking.<br />Unforgettable work.</p></div>
          <div className="footer-col"><span>EXPLORE</span><Link href="/#work">Work</Link><Link href="/#services">Services</Link><Link href="/#about">About</Link></div>
          <div className="footer-col"><span>CONNECT</span><a href="mailto:navneetsingh88077@gmail.com">Email <ArrowUpRight size={13} /></a><a href="https://wa.me/917632978903" target="_blank" rel="noopener noreferrer">WhatsApp <ArrowUpRight size={13} /></a><Link href="/#contact">Start a project <ArrowUpRight size={13} /></Link></div>
          <a href="#top" className="back-top" aria-label="Back to top"><ArrowUp size={20} /></a>
        </div>
        <div className="footer-big" aria-hidden="true">HUSTLER<span>✳</span></div>
        <div className="footer-bottom"><span>© {new Date().getFullYear()} HUSTLER AGENCY. ALL RIGHTS RESERVED.</span><span>MADE WITH INTENTION <span className="lime">✳</span> BUILT FOR THE BOLD.</span></div>
      </div>
    </footer>
  );
}
