'use client';

import dynamic from 'next/dynamic';
import { Component, useEffect, useRef, useState } from 'react';
import type { ErrorInfo, ReactNode } from 'react';

const OrbScene = dynamic(() => import('./OrbScene'), { ssr: false });

class CanvasBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch(_error: Error, _info: ErrorInfo) { /* The CSS orb remains as a graceful fallback. */ }
  render() { return this.state.failed ? null : this.props.children; }
}

type DeviceNavigator = Navigator & { deviceMemory?: number; connection?: { saveData?: boolean } };

export default function HeroOrb() {
  const root = useRef<HTMLDivElement>(null);
  const [enabled, setEnabled] = useState(false);
  const [mobile, setMobile] = useState(false);
  const [inView, setInView] = useState(false);
  const [tabVisible, setTabVisible] = useState(true);

  useEffect(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
    const small = window.matchMedia('(max-width: 700px)');
    const device = navigator as DeviceNavigator;
    const update = () => {
      setMobile(small.matches);
      let webgl = false;
      try {
        const probe = document.createElement('canvas');
        webgl = Boolean(probe.getContext('webgl') || probe.getContext('experimental-webgl'));
        // Release the test context immediately so it doesn't compete with the scene.
        const gl = probe.getContext('webgl');
        gl?.getExtension('WEBGL_lose_context')?.loseContext();
      } catch { webgl = false; }
      const lowPower = (device.deviceMemory !== undefined && device.deviceMemory <= 2) || (navigator.hardwareConcurrency !== undefined && navigator.hardwareConcurrency <= 2);
      setEnabled(webgl && !reduce.matches && !device.connection?.saveData && !lowPower);
    };
    const onVisibility = () => setTabVisible(!document.hidden);
    update();
    reduce.addEventListener('change', update);
    small.addEventListener('change', update);
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      reduce.removeEventListener('change', update);
      small.removeEventListener('change', update);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, []);

  useEffect(() => {
    const element = root.current;
    if (!element) return;
    if (!('IntersectionObserver' in window)) { setInView(true); return; }
    const observer = new IntersectionObserver(([entry]) => setInView(entry.isIntersecting), { rootMargin: '80px' });
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  return (
    <div className="hero-orb" ref={root} aria-hidden="true">
      <div className={`orb-fallback ${enabled ? 'orb-fallback-soft' : ''}`} />
      {enabled && <CanvasBoundary><OrbScene mobile={mobile} active={inView && tabVisible} /></CanvasBoundary>}
    </div>
  );
}
