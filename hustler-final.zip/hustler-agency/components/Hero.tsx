import Link from 'next/link';
import { ArrowDownRight, ArrowUpRight } from 'lucide-react';
import HeroOrb from './HeroOrb';
import { Mark } from './Mark';
import Marquee from './Marquee';

export default function Hero({ portraitSrc }: { portraitSrc: string | null }) {
  return (
    <section className="hero" aria-labelledby="hero-title">
      <div className="hero-grid page-shell">
        <div className="hero-copy">
          <div className="hero-eyebrow"><span className="eyebrow-dot" />INDEPENDENT CREATIVE STUDIO <span className="eyebrow-separator">/</span> BUILT FOR THE BOLD</div>
          <h1 id="hero-title" className="hero-title"><span>HUSTLER</span><span>AGENCY<span className="title-period">.</span></span></h1>
          <div className="hero-rule"><span /><Mark /><span /></div>
          <div className="hero-bottom-copy">
            <p>Big ideas deserve <em>bold execution.</em><br />Let&apos;s make something impossible to ignore.</p>
            <Link href="/#work" className="hero-discover" aria-label="Explore selected work"><span>EXPLORE<br />THE WORK</span><span className="round-arrow"><ArrowDownRight size={19} /></span></Link>
          </div>
        </div>
        <div className={`hero-visual ${portraitSrc ? 'has-portrait' : 'is-abstract'}`}>
          <div className="hero-visual-image" style={{ backgroundImage: `url('${portraitSrc || '/images/hero-abstract.webp'}')` }} role={portraitSrc ? 'img' : undefined} aria-label={portraitSrc ? 'Portrait of Navneet, creative behind Hustler Agency' : undefined} />
          <div className="hero-visual-shade" />
          <div className="visual-topline"><span>THE ART OF<br />STANDING OUT</span><span>HA / 01</span></div>
          <div className="visual-side-label">CREATIVE THINKING. REAL IMPACT.</div>
          <div className="visual-bottomline"><span className="visual-symbol"><Mark /></span><span>GOOD WORK<br />DOES THE TALKING.</span><ArrowUpRight size={18} /></div>
          <span className="visual-corner visual-corner-a" /><span className="visual-corner visual-corner-b" />
        </div>
        <HeroOrb />
        <div className="hero-scroll"><span>SCROLL TO EXPLORE</span><span className="scroll-line" /></div>
        <div className="hero-side-note">STRATEGY <span>✳</span> DESIGN <span>✳</span> DIGITAL</div>
      </div>
      <Marquee />
    </section>
  );
}
