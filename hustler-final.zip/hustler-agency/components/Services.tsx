'use client';

import { ArrowUpRight, Boxes, Compass, Monitor, PenTool } from 'lucide-react';
import { motion, useMotionValue, useReducedMotion, useSpring } from 'framer-motion';
import type { LucideIcon } from 'lucide-react';
import type { PointerEvent } from 'react';
import SectionLabel from './SectionLabel';

const services: { number: string; title: string; description: string; list: string; icon: LucideIcon }[] = [
  { number: '01', title: 'Brand identity', description: 'An unmistakable look and a clear point of view. Because blending in was never the plan.', list: 'STRATEGY · IDENTITY · GUIDELINES', icon: PenTool },
  { number: '02', title: 'Digital experiences', description: 'Websites with purpose, personality and the kind of details people remember.', list: 'WEB DESIGN · DEVELOPMENT · UX', icon: Monitor },
  { number: '03', title: 'Creative direction', description: 'A bigger vision, brought to life across every touchpoint your audience meets.', list: 'ART DIRECTION · CAMPAIGNS · CONTENT', icon: Compass },
  { number: '04', title: 'Content & growth', description: 'Considered creative that keeps your story moving and your brand showing up.', list: 'SOCIAL CREATIVE · CONTENT · CAMPAIGNS', icon: Boxes },
];

function ServiceCard({ service }: { service: typeof services[number] }) {
  const reduced = useReducedMotion();
  const rx = useMotionValue(0);
  const ry = useMotionValue(0);
  const rotateX = useSpring(rx, { stiffness: 160, damping: 22, mass: 0.5 });
  const rotateY = useSpring(ry, { stiffness: 160, damping: 22, mass: 0.5 });
  function onMove(event: PointerEvent<HTMLElement>) {
    if (reduced || event.pointerType !== 'mouse') return;
    const rect = event.currentTarget.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width;
    const y = (event.clientY - rect.top) / rect.height;
    rx.set((0.5 - y) * 7);
    ry.set((x - 0.5) * 7);
    event.currentTarget.style.setProperty('--glow-x', `${x * 100}%`);
    event.currentTarget.style.setProperty('--glow-y', `${y * 100}%`);
  }
  function reset() { rx.set(0); ry.set(0); }
  const Icon = service.icon;
  return (
    <motion.article className="service-card" style={{ rotateX, rotateY, transformPerspective: 900 }} onPointerMove={onMove} onPointerLeave={reset}>
      <div className="service-card-top"><span className="service-number">/{service.number}</span><Icon className="service-icon" size={29} strokeWidth={1.25} /></div>
      <div className="service-content"><h3>{service.title}<span className="lime">.</span></h3><p>{service.description}</p></div>
      <div className="service-card-bottom"><span>{service.list}</span><ArrowUpRight size={16} /></div>
    </motion.article>
  );
}

export default function Services() {
  return (
    <section className="services-section section-pad" id="services" aria-labelledby="services-title">
      <div className="page-shell">
        <SectionLabel number="02">WHAT WE DO</SectionLabel>
        <div className="section-intro services-intro"><div><p className="overline">THINK BIG. BUILD WITH INTENTION.</p><h2 className="section-heading" id="services-title">All the right moves<span className="lime">.</span><br /><span className="serif-accent">One creative partner.</span></h2></div><p className="section-intro-copy">From the first spark to the final detail, we bring ideas to life with clarity, character and a whole lot of heart.</p></div>
        <div className="service-grid">{services.map((service) => <ServiceCard service={service} key={service.number} />)}</div>
        <div className="services-note"><span>GOOD DESIGN IS GOOD BUSINESS.</span><a href="/#contact">LET&apos;S MAKE SOMETHING GOOD <ArrowUpRight size={16} /></a></div>
      </div>
    </section>
  );
}
