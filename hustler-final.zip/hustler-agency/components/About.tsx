import Link from 'next/link';
import { ArrowUpRight } from 'lucide-react';
import { Mark } from './Mark';
import SectionLabel from './SectionLabel';

export default function About({ portraitSrc }: { portraitSrc: string | null }) {
  return (
    <section className="about-section section-pad" id="about" aria-labelledby="about-title">
      <div className="page-shell">
        <SectionLabel number="03">THE PERSON BEHIND THE WORK</SectionLabel>
        <div className="about-grid">
          <div className="about-image-wrap">
            <div className={`about-image ${portraitSrc ? 'about-has-portrait' : 'about-is-abstract'}`}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={portraitSrc || '/images/hero-abstract.webp'} alt={portraitSrc ? 'Navneet, creative behind Hustler Agency' : ''} loading="lazy" decoding="async" />
              <div className="about-image-tint" />
              <div className="about-frame-top"><span>THE HUMAN<br />BEHIND HUSTLER</span><Mark /></div>
              <div className="about-frame-bottom"><span>NAVNEET</span><span>CREATIVE MIND<br />HUSTLER AGENCY</span></div>
              <div className="about-image-no">03 / 04</div>
            </div>
            <div className="about-image-caption"><span>INDEPENDENT BY NATURE</span><span>INTENTIONAL BY DESIGN ↗</span></div>
          </div>
          <div className="about-content">
            <p className="overline"><span className="eyebrow-dot" /> NICE TO MEET YOU</p>
            <h2 className="section-heading about-heading" id="about-title">Hi, I&apos;m<br /><span className="serif-accent">Navneet.</span><span className="lime">✳</span></h2>
            <p className="about-lead">I believe good ideas deserve more than a good-looking logo.</p>
            <p className="about-text">They deserve a distinct voice, a thoughtful digital home, and the confidence to stand out. That&apos;s why I created Hustler Agency: to bring strategy and creativity together for brands ready to make their mark.</p>
            <p className="about-text">No noise for the sake of it. Just considered work, meaningful details, and ideas that move people.</p>
            <Link href="/#contact" className="text-link">LET’S WORK TOGETHER <span><ArrowUpRight size={16} /></span></Link>
            <div className="about-signature"><span>IDEAS WITH INTENTION.</span><Mark /><span>MADE WITH HUSTLE.</span></div>
          </div>
        </div>
      </div>
    </section>
  );
}
