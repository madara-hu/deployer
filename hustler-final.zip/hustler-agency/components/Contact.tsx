'use client';

import { ArrowUpRight, Send } from 'lucide-react';
import { useState } from 'react';
import type { FormEvent } from 'react';
import SectionLabel from './SectionLabel';

const EMAIL = 'navneetsingh88077@gmail.com';
const WHATSAPP = 'https://wa.me/917632978903';

export default function Contact() {
  const [draft, setDraft] = useState('');
  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const name = String(form.get('name') || '').trim();
    const email = String(form.get('email') || '').trim();
    const service = String(form.get('service') || '').trim();
    const message = String(form.get('message') || '').trim();
    const subject = `Project inquiry from ${name}`;
    const body = `Hi Navneet,\n\n${message}\n\nName: ${name}\nEmail: ${email}\nInterested in: ${service}\n`;
    const href = `mailto:${EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    setDraft(href);
    // A static site has no server inbox; this honestly opens an email draft.
    window.location.href = href;
  }
  return (
    <section className="contact-section section-pad" id="contact" aria-labelledby="contact-title">
      <div className="page-shell">
        <SectionLabel number="04">LET&apos;S MAKE IT HAPPEN</SectionLabel>
        <div className="contact-grid">
          <div className="contact-copy">
            <p className="overline"><span className="eyebrow-dot" /> GOOD THINGS START WITH A HELLO</p>
            <h2 className="section-heading contact-heading" id="contact-title">Have a good<br />one in <span className="serif-accent">mind?</span><br /><span className="contact-outline">Let&apos;s talk.</span></h2>
            <p>Whether you have a fully formed brief or just a spark of an idea, we&apos;d love to hear about it.</p>
            <div className="contact-links">
              <a href={`mailto:${EMAIL}`}><span><small>DROP AN EMAIL</small>{EMAIL}</span><ArrowUpRight size={19} /></a>
              <a href={WHATSAPP} target="_blank" rel="noopener noreferrer"><span><small>OR SAY HELLO ON</small>WhatsApp</span><ArrowUpRight size={19} /></a>
            </div>
          </div>
          <div className="contact-form-wrap">
            <div className="form-heading"><div><span className="form-kicker">TELL US A LITTLE ABOUT IT</span><h3>Let&apos;s start something<span className="lime">.</span></h3></div><span className="form-icon"><Send size={19} strokeWidth={1.5} /></span></div>
            <form onSubmit={handleSubmit}>
              <div className="form-row"><label><span className="field-label">YOUR NAME <i>*</i></span><input name="name" autoComplete="name" placeholder="What should we call you?" required maxLength={80} /></label><label><span className="field-label">EMAIL ADDRESS <i>*</i></span><input type="email" name="email" autoComplete="email" placeholder="Where can we reach you?" required maxLength={254} /></label></div>
              <label><span className="field-label">WHAT ARE YOU LOOKING FOR? <i>*</i></span><select name="service" required defaultValue=""><option value="" disabled>Choose a service</option><option>Brand identity</option><option>Digital experiences</option><option>Creative direction</option><option>Content & growth</option><option>Something else entirely</option></select></label>
              <label><span className="field-label">THE BIG IDEA <i>*</i></span><textarea name="message" placeholder="Tell us a little about your project..." rows={4} required maxLength={1500} /></label>
              <button type="submit" className="submit-button"><span>OPEN EMAIL DRAFT</span><ArrowUpRight size={19} /></button>
              <p className="form-hint">This opens your email app with your message ready to send.</p>
              {draft && <p className="form-confirmation" role="status">Your draft is ready. If your email app didn&apos;t open, <a href={draft}>open it here</a> or message us on WhatsApp.</p>}
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
