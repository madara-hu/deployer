'use client';

import { Canvas, useFrame } from '@react-three/fiber';
import { Float } from '@react-three/drei';
import { useRef } from 'react';
import type { Group } from 'three';

function Sculpture({ mobile }: { mobile: boolean }) {
  const group = useRef<Group>(null);
  useFrame((_, delta) => {
    if (!group.current) return;
    const step = Math.min(delta, 0.05);
    group.current.rotation.y += step * 0.18;
    group.current.rotation.z += step * 0.08;
  });
  const segments = mobile ? 40 : 64;
  return (
    <Float speed={1.1} rotationIntensity={0.18} floatIntensity={0.28}>
      <group ref={group} rotation={[0.35, 0.15, -0.35]}>
        <mesh>
          <torusGeometry args={[0.88, 0.105, 8, segments]} />
          <meshStandardMaterial color="#ccff00" metalness={0.68} roughness={0.24} />
        </mesh>
        <mesh rotation={[Math.PI / 2.45, 0.3, 0.2]} scale={0.87}>
          <torusGeometry args={[0.88, 0.075, 8, segments]} />
          <meshStandardMaterial color="#8aa54c" metalness={0.72} roughness={0.28} />
        </mesh>
        <mesh rotation={[0.2, Math.PI / 1.7, 0.4]} scale={1.14}>
          <torusGeometry args={[0.88, 0.018, 6, segments]} />
          <meshStandardMaterial color="#e3c184" metalness={0.8} roughness={0.3} />
        </mesh>
      </group>
    </Float>
  );
}

export default function OrbScene({ mobile, active }: { mobile: boolean; active: boolean }) {
  return (
    <Canvas
      aria-hidden="true"
      dpr={mobile ? 1 : [1, 1.25]}
      frameloop={active ? 'always' : 'never'}
      camera={{ position: [0, 0, 4.2], fov: 42 }}
      gl={{ antialias: false, alpha: true, powerPreference: 'low-power' }}
      performance={{ min: 0.5 }}
    >
      <ambientLight intensity={1.3} />
      <directionalLight position={[2, 4, 5]} color="#eaffad" intensity={3} />
      <directionalLight position={[-4, -2, 2]} color="#e8a94f" intensity={1.4} />
      <Sculpture mobile={mobile} />
    </Canvas>
  );
}
