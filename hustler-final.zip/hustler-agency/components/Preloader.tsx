'use client';

import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { useEffect, useState } from 'react';
import { Mark } from './Mark';

export default function Preloader() {
  const [count, setCount] = useState(0);
  const [visible, setVisible] = useState(true);
  const reducedMotion = useReducedMotion();

  useEffect(() => {
    if (reducedMotion) {
      setCount(100);
      setVisible(false);
      return;
    }
    let frame = 0;
    let hideTimer: ReturnType<typeof setTimeout> | undefined;
    const startedAt = performance.now();
    const duration = 850;
    const tick = (now: number) => {
      const progress = Math.min((now - startedAt) / duration, 1);
      // Ease gently to a decisive finish without making the visitor wait.
      const eased = 1 - Math.pow(1 - progress, 2.2);
      setCount(Math.round(eased * 100));
      if (progress < 1) frame = requestAnimationFrame(tick);
      else hideTimer = setTimeout(() => setVisible(false), 110);
    };
    frame = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(frame);
      if (hideTimer) clearTimeout(hideTimer);
    };
  }, [reducedMotion]);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="preloader"
          aria-hidden="true"
          exit={{ y: '-101%' }}
          transition={{ duration: 0.65, ease: [0.76, 0, 0.24, 1] }}
        >
          <div className="preloader-top"><span>HUSTLER AGENCY</span><span>INDEPENDENT CREATIVE STUDIO</span></div>
          <div className="preloader-center"><Mark className="preloader-mark" /><span>MADE FOR<br />WHAT&apos;S NEXT.</span></div>
          <div className="preloader-bottom"><span>LOADING THE GOOD STUFF</span><span className="preloader-count">{String(count).padStart(2, '0')}<small>%</small></span></div>
          <div className="preloader-line"><span style={{ transform: `scaleX(${count / 100})` }} /></div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
