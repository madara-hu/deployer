/** A custom geometric mark, used consistently throughout the site. */
export function Mark({ className = '' }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" fill="none" aria-hidden="true" className={className}>
      <path d="M17.5 1h5v13.9l9.83-9.83 3.54 3.54-9.83 9.83H40v5H26.04l9.83 9.83-3.54 3.54-9.83-9.83V40h-5V26.04l-9.83 9.83-3.54-3.54 9.83-9.83H0v-5h13.96L4.13 8.61l3.54-3.54 9.83 9.83V1Z" fill="currentColor" />
    </svg>
  );
}
