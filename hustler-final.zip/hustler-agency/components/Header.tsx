'use client';

import Link from 'next/link';
import { ArrowUpRight, Menu, X } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import { Mark } from './Mark';

const navItems = [
  { label: 'WORK', href: '/#work' },
  { label: 'SERVICES', href: '/#services' },
  { label: 'ABOUT', href: '/#about' },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    function closeOnEscape(event: KeyboardEvent) { if (event.key === 'Escape') setOpen(false); }
    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, []);

  return (
    <header className="site-header" id="top">
      <div className="header-inner page-shell">
        <Link href="/" className="brand" aria-label="Hustler Agency home" onClick={() => setOpen(false)}>
          <span className="brand-icon"><Mark /></span>
          <span className="brand-wordmark">HUSTLER<span>AGENCY<span className="brand-reg">✳</span></span></span>
        </Link>
        <nav className="desktop-nav" aria-label="Main navigation">
          {navItems.map((item, i) => <Link key={item.label} href={item.href}><span className="nav-index">0{i + 1}</span>{item.label}</Link>)}
        </nav>
        <Link className="header-contact" href="/#contact"><span>LET&apos;S TALK</span><ArrowUpRight size={16} strokeWidth={1.8} /></Link>
        <button className="menu-toggle" type="button" onClick={() => setOpen((v) => !v)} aria-expanded={open} aria-controls="mobile-navigation" aria-label={open ? 'Close menu' : 'Open menu'}>
          {open ? <X size={23} /> : <Menu size={23} />}
        </button>
      </div>
      <AnimatePresence>
        {open && (
          <motion.nav id="mobile-navigation" className="mobile-nav" aria-label="Mobile navigation" initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.2 }}>
            {navItems.map((item, i) => <Link key={item.label} href={item.href} onClick={() => setOpen(false)}><span>0{i + 1}</span>{item.label}<ArrowUpRight size={19} /></Link>)}
            <Link href="/#contact" onClick={() => setOpen(false)}><span>04</span>CONTACT<ArrowUpRight size={19} /></Link>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}
