import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowDown, ArrowLeft, ArrowUpRight } from 'lucide-react';
import { notFound } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { projects } from '@/lib/projects';

export const dynamicParams = false;
export function generateStaticParams() { return projects.map((project) => ({ slug: project.slug })); }
export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const project = projects.find((item) => item.slug === params.slug);
  return { title: project ? `${project.name} — Concept` : 'Project', description: project?.description };
}

export default function ProjectPage({ params }: { params: { slug: string } }) {
  const project = projects.find((item) => item.slug === params.slug);
  if (!project) notFound();
  const currentIndex = projects.findIndex((item) => item.slug === project.slug);
  const nextProject = projects[(currentIndex + 1) % projects.length];
  return (
    <>
      <Header />
      <main id="main" className="project-page">
        <div className="page-shell project-page-top">
          <Link href="/#work" className="project-back"><ArrowLeft size={16} /> ALL CONCEPTS</Link>
          <div className="project-page-heading"><div><p className="overline">CREATIVE CONCEPT <span className="lime">✳</span> {project.category}</p><h1>{project.name}<span className="lime">.</span></h1><p>{project.tagline}</p></div><span className="project-page-index">{String(currentIndex + 1).padStart(2, '0')} / {String(projects.length).padStart(2, '0')}</span></div>
        </div>
        <div className={`project-page-visual project-image-${project.palette}`}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={project.cover} alt={project.coverAlt} />
          <div className="project-page-visual-overlay" />
          <span>HUSTLER AGENCY / INDEPENDENT CONCEPT</span><span><ArrowDown size={18} /> SCROLL TO DISCOVER</span>
        </div>
        <div className="page-shell project-page-body">
          <div className="project-body-label"><span>THE IDEA</span><span>(01)</span></div>
          <div className="project-body-copy"><p className="overline">A CONCEPT WITH CHARACTER</p><h2>{project.tagline}</h2><p>{project.brief}</p><p>{project.direction}</p><div className="project-services"><span>THE CREATIVE MIX</span><div>{project.services.map((service) => <span key={service}>{service}</span>)}</div></div></div>
        </div>
        <div className="page-shell project-next"><span>NEXT UP</span><Link href={`/projects/${nextProject.slug}/`}><span>{nextProject.name}<small>{nextProject.category}</small></span><span className="project-next-arrow"><ArrowUpRight size={28} /></span></Link></div>
      </main>
      <Footer />
    </>
  );
}
