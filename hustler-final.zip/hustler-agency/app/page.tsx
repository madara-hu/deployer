import About from '@/components/About';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import Preloader from '@/components/Preloader';
import Services from '@/components/Services';
import Work from '@/components/Work';
import { getPortraitSrc } from '@/lib/portrait';

export default function Home() {
  const portraitSrc = getPortraitSrc();
  return (
    <>
      <Preloader />
      <Header />
      <main id="main">
        <Hero portraitSrc={portraitSrc} />
        <Work />
        <Services />
        <About portraitSrc={portraitSrc} />
        <Contact />
      </main>
      <Footer />
    </>
  );
}
