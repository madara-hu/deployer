import type { Metadata, Viewport } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: 'Hustler Agency — Built for the bold',
    template: '%s — Hustler Agency',
  },
  description: 'Hustler Agency is an independent creative studio building distinctive brands and digital experiences for ambitious ideas.',
  applicationName: 'Hustler Agency',
  openGraph: {
    title: 'Hustler Agency — Built for the bold',
    description: 'Distinctive brands and digital experiences for ambitious ideas.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Hustler Agency — Built for the bold',
    description: 'Distinctive brands and digital experiences for ambitious ideas.',
  },
};

export const viewport: Viewport = { themeColor: '#050505', width: 'device-width', initialScale: 1 };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <a className="skip-link" href="#main">Skip to content</a>
        <noscript><style>{'.preloader { display: none !important; }'}</style></noscript>
        {children}
      </body>
    </html>
  );
}
