import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{js,ts,jsx,tsx,mdx}', './components/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: { obsidian: '#050505', lime: '#ccff00', amber: '#e4b669' },
      fontFamily: { display: ['Space Grotesk', 'Arial', 'sans-serif'], sans: ['Inter', 'Arial', 'sans-serif'] },
    },
  },
  plugins: [],
};
export default config;
