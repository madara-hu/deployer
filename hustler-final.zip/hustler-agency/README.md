# Hustler Agency

A cinematic, mobile-first portfolio for Navneet and Hustler Agency. Built with Next.js 14 App Router, TypeScript, Tailwind CSS, Framer Motion, React Three Fiber, Drei, and Lucide. The entire site, including project detail pages, is exported as static files for Cloudflare Pages.

## Quick start

Use Node.js 20 (see `.nvmrc`) and npm. From the project folder:

```bash
npm ci
npm run dev
```

Open the local URL printed by Next.js. For a production export and a local preview:

```bash
npm run build
npm run start
```

The production files are written to `out/`. `npm run start` serves those exported files; it does **not** run a Next.js production server.

## Deploy to Cloudflare Pages

1. Push this project to a Git repository and connect the repository in **Cloudflare Dashboard → Workers & Pages → Create → Pages**.
2. Point the root directory at the folder containing `package.json`.
3. Set the build command to **`npm ci && npm run build`**.
4. Set the build output directory to **`out`**.
5. Set the build environment variable **`NODE_VERSION`** to **`20`** and deploy.

You can select a static Next.js preset if offered, but confirm the command and output directory above. The project already specifies `output: 'export'`, `images: { unoptimized: true }`, and `trailingSlash: true`. It uses no Workers, server functions, server actions, or Cloudflare-specific runtime. Use Git integration rather than uploading the source zip directly: Cloudflare needs to run the build before publishing `out/`.

## Add or edit projects

Edit **`lib/projects.ts`**. Each object in the `projects` array becomes a work card **and** a detail page on the next build. Duplicate an object, give it a unique URL-safe `slug`, update its copy and services, and add the cover image to `public/images`. Set `cover` to a root-relative path such as `/images/my-project.webp`. Keep `palette` as `lime`, `stone`, or `amber`. Rebuild after editing.

The three included projects are explicitly labelled **concept explorations**, not claimed client work. Replace or extend them with your real projects when ready. Their campaign imagery was created for this site.

## Portrait and copy

The site includes an AI-edited, cinematic version of Navneet's supplied photo at `public/images/navneet.webp`. It is used in the hero and about section. To replace it, overwrite that file with another `.webp`, or remove it and add `navneet.jpg`, `navneet.jpeg`, or `navneet.png` in the same folder. The image is detected at build time, so rebuild after changing it. If no portrait exists, the site gracefully falls back to original abstract artwork.

All main copy is in the components in `components/`; contact links are in `Contact.tsx` and `Footer.tsx`. Only supplied contact destinations are linked; add verified Instagram/LinkedIn URLs to the footer when available.

## Contact form

Because this is a **static** site, the form does not send or store messages on a server. It creates a pre-filled email draft addressed to `navneetsingh88077@gmail.com` in the visitor's email app. The visitor must send the draft. Direct email and WhatsApp links are also provided. For server-side delivery without a mail client, connect a form service or an API and update `components/Contact.tsx`.

## Performance and accessibility

- Self-hosted, compressed WebP imagery and local, licensed fonts; no external font requests.
- The 3D scene is lazy-loaded, uses low-polygon geometry and capped pixel density (DPR 1 on mobile, at most 1.25 on desktop), and pauses when offscreen or the tab is hidden.
- A CSS fallback is used for low-power devices, data-saver, unavailable WebGL, or reduced-motion preferences. Reduced motion also stops the marquee.
- Semantic navigation, keyboard focus states, native form labels and validation, and no horizontal scrolling at tested mobile widths.

Actual animation smoothness depends on the visitor's device and browser.

## Regenerate the source archive

`setup.sh` is a self-contained copy of this source. From a directory that does not already contain `hustler-agency/`, run:

```bash
bash setup.sh
```

It creates `hustler-agency/` and `hustler-final.zip` in the current directory. Python 3 is required. To choose different paths:

```bash
bash setup.sh ./my-hustler-project ./hustler-final.zip
```

The archive contains source files and the lockfile, not `node_modules`, `.next`, or the generated `out/` directory. Run the build commands above after extraction.

## Security note

The requested Next.js 14.2.35 is an older, unsupported major version, and `npm audit` flags critical advisories against that version. Many concern a deployed Next.js server; this project exports static files and does not deploy that server, which removes those server-runtime attack paths, but it is not a blanket security guarantee. Review the advisories, keep the build environment trusted, and plan to upgrade to a currently supported Next.js major. The PostCSS dependency is overridden to a patched release; `three-mesh-bvh` is overridden to 0.8.3 for the pinned Three.js version.

## Fonts

Inter and Space Grotesk are distributed under the SIL Open Font License; the license texts are included in `public/fonts/`.
