import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './app/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './lib/**/*.{ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        void: '#000000',
        pitch: '#04060a',
        panel: '#080c10',
        matrix: '#00ff9c',
        matrixDim: '#0a3d28',
        cyan: '#22e6ff',
        acid: '#c6ff00',
        ash: '#8a949e',
      },
      fontFamily: {
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
        sans: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif'],
      },
      boxShadow: {
        neon: '0 0 24px rgba(0,255,156,0.35)',
        cyan: '0 0 32px rgba(34,230,255,0.30)',
      },
      screens: {
        xs: '420px',
      },
      animation: {
        blink: 'blink 1s steps(1) infinite',
        scan: 'scan 6s linear infinite',
        flicker: 'flicker 4s linear infinite',
      },
      keyframes: {
        blink: {
          '0%, 49%': { opacity: '1' },
          '50%, 100%': { opacity: '0' },
        },
        scan: {
          '0%': { transform: 'translateY(-100%)' },
          '100%': { transform: 'translateY(100%)' },
        },
        flicker: {
          '0%, 100%': { opacity: '1' },
          '92%': { opacity: '1' },
          '93%': { opacity: '0.65' },
          '94%': { opacity: '1' },
          '96%': { opacity: '0.8' },
          '97%': { opacity: '1' },
        },
      },
    },
  },
  plugins: [],
};

export default config;
