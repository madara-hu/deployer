#!/usr/bin/env bash
# ============================================================
#  HUSTLER PORTFOLIO — one-shot setup for Termux / Codespaces
#  Run from INSIDE the hustler-portfolio folder:
#      chmod +x setup.sh && ./setup.sh
# ============================================================
set -euo pipefail

BLUE="\033[1;34m"; GREEN="\033[1;32m"; RED="\033[1;31m"; DIM="\033[2m"; NC="\033[0m"
say() { printf "${BLUE}[hustler]${NC} %s\n" "$1"; }
ok()  { printf "${GREEN}[ ok ]${NC} %s\n" "$1"; }
die() { printf "${RED}[fail]${NC} %s\n" "$1"; exit 1; }

# ------------------------------------------------------------
# 0. sanity: must run from the project root
# ------------------------------------------------------------
[ -f package.json ] || die "package.json not found. cd into hustler-portfolio first."
[ -f next.config.mjs ] || die "next.config.mjs not found. wrong directory."

command -v node >/dev/null 2>&1 || die "node is missing. Termux: pkg install nodejs && pkg install git"
command -v npm  >/dev/null 2>&1 || die "npm is missing. Termux: pkg install nodejs"

NODE_MAJOR=$(node -p "process.versions.node.split('.')[0]")
[ "$NODE_MAJOR" -ge 18 ] || die "Node 18+ required, found $(node -v)"

say "node $(node -v) / npm $(npm -v)"

# ------------------------------------------------------------
# 1. folder structure (idempotent)
# ------------------------------------------------------------
say "verifying folder structure"
mkdir -p app components lib public out
for f in app/page.tsx app/layout.tsx app/globals.css \
         components/Hero.tsx components/About.tsx components/TerminalSection.tsx \
         components/Contact.tsx components/Scene3D.tsx components/SceneBackground.tsx \
         components/AudioGhost.tsx components/CustomCursor.tsx components/MagneticButton.tsx \
         components/Reveal.tsx components/Nav.tsx components/StackMarquee.tsx \
         lib/site.ts lib/utils.ts lib/hooks.ts; do
  [ -f "$f" ] || die "missing source file: $f  (re-extract hustler-hacker.zip)"
done
ok "sources present"

# ------------------------------------------------------------
# 2. assets (never overwrite your own)
# ------------------------------------------------------------
if [ ! -f public/photo.png ]; then
  say "public/photo.png missing -> writing 1x1 placeholder you must replace"
  printf 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8DwHwAFAAH/q842iQAAAABJRU5ErkJggg==' | base64 -d > public/photo.png
fi
if [ ! -f public/solo.mp3 ]; then
  say "public/solo.mp3 missing -> writing 4s silent loop placeholder you must replace"
  printf '//uQxAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=' | base64 -d > public/solo.mp3
fi
ok "assets ready (photo.png / solo.mp3)"

# ------------------------------------------------------------
# 3. dependencies
# ------------------------------------------------------------
say "installing dependencies (this is the slow part on mobile data)"
if ! npm install --no-audit --no-fund; then
  say "npm install failed -> retrying with --legacy-peer-deps"
  npm install --legacy-peer-deps --no-audit --no-fund
fi
ok "dependencies installed"

# ------------------------------------------------------------
# 4. production build (static export -> ./out)
# ------------------------------------------------------------
say "building static export"
npm run build
[ -f out/index.html ] || die "build finished but out/index.html is missing"
ok "static export ready in ./out"

# ------------------------------------------------------------
# 5. zip the source (no node_modules / .next / out)
# ------------------------------------------------------------
say "packing source archive"
cd ..
if command -v zip >/dev/null 2>&1; then
  rm -f hustler-hacker.zip
  zip -rq hustler-hacker.zip hustler-portfolio \
    -x "*/node_modules/*" -x "*/.next/*" -x "*/out/*" -x "*/.git/*"
  ok "hustler-hacker.zip -> $(pwd)/hustler-hacker.zip ($(du -h hustler-hacker.zip | cut -f1))"
else
  tar -czf hustler-hacker.tar.gz --exclude=node_modules --exclude=.next --exclude=out hustler-portfolio
  ok "zip not installed; wrote hustler-hacker.tar.gz instead"
fi

cd hustler-portfolio

cat <<EOF

${GREEN}==================================================================${NC}
 DEPLOY
${DIM} preview locally ${NC}
   npx serve out

${DIM} cloudflare pages (first time) ${NC}
   npx wrangler login
   npx wrangler pages deploy out --project-name hustler-portfolio

${DIM} every deploy after that ${NC}
   npm run build && npx wrangler pages deploy out --project-name hustler-portfolio
${GREEN}==================================================================${NC}
 replace public/photo.png and public/solo.mp3 with your own files.
 rebuild after replacing: npm run build
EOF
