# HUSTLER // Navneet Singh — 3D Hacker Portfolio

Static-exported Next.js 14 (App Router) portfolio built for **Cloudflare Pages**, authored entirely from **Termux / GitHub Codespaces**.

Ultra-dark matrix aesthetic, glitch HUD hero, wireframe 3D globe (React Three Fiber), Lenis smooth scroll, GSAP timelines, Framer Motion UI, magnetic buttons, custom glowing cursor, fake interactive terminal, and a **ghost audio engine** — music loops from the first moment with zero visible controls.

---

## 1. STACK

| Layer | Tech |
| --- | --- |
| Framework | Next.js `14.2.35` (App Router, `output: 'export'`) |
| Language | TypeScript `5.5.4` |
| Styling | Tailwind CSS `3.4.10` |
| Motion | GSAP `3.12.5` + Framer Motion `11.3.24` |
| Smooth scroll | `lenis` `1.1.14` (the maintained successor of `@studio-freight/lenis`) |
| 3D | `three` `0.166.1` + `@react-three/fiber` `8.17.10` + `@react-three/drei` `9.109.2` |
| Deploy | Cloudflare Pages (`wrangler pages deploy out`) |

> **Why `lenis` and not `@studio-freight/lenis`?** The old scope was renamed; installing it throws a deprecation warning and the package is no longer updated. `lenis` is the same API (`new Lenis({...})`), same maintainer, zero code changes.

---

## 2. INSTALL (Termux or Codespace)

```bash
# Termux only, first time
pkg update -y && pkg install -y nodejs git

# from inside the unzipped folder
cd hustler-portfolio

# if you ever hit a peer-dependency wall, use:
npm install --legacy-peer-deps
# otherwise
npm install

npm run dev          # http://localhost:3000
```

Everything in this repo is already pinned, so `npm install` resolves clean on npm 10 / node 20.

---

## 3. BUILD (static export)

```bash
npm run build
```

Output goes to `./out`:

```
out/index.html
out/404.html
out/_next/...
out/photo.png
out/solo.mp3
out/icon.svg
```

Preview the production build locally:

```bash
npx serve out
```

---

## 4. DEPLOY TO CLOUDFLARE PAGES

### A. Wrangler CLI (the way you asked for)

```bash
npm install -D wrangler        # once
npx wrangler login             # opens the browser auth flow
npx wrangler pages deploy out --project-name hustler-portfolio
```

First run creates the project and prints the live URL (`https://hustler-portfolio.pages.dev`).
Every later deploy is just:

```bash
npm run build && npx wrangler pages deploy out --project-name hustler-portfolio
```

`wrangler pages deploy` does **not** support `--branch main` anymore for Pages — omit it. Anything after the first deploy is a preview deployment unless you pass `--branch main` is omitted and the project default branch matches.

### B. Dashboard / Git integration

1. Push this folder to GitHub (`gh repo create hustler-portfolio --public --source=. --push`).
2. Cloudflare Dashboard → **Workers & Pages → Create → Pages → Connect to Git**.
3. Build command: `npm run build`
4. Build output directory: `out`
5. Framework preset: **Next.js (Static HTML Export)**
6. Environment variable (only needed if npm complains): `NPM_CONFIG_LEGACY_PEER_DEPS = true`

No Node runtime, no `wrangler.toml` needed for static hosting. The included `wrangler.toml` is only there so `wrangler pages deploy out` knows the project name and output dir.

---

## 5. SWAP YOUR ASSETS

| File | Purpose |
| --- | --- |
| `public/photo.png` | Hero portrait (HUD-framed). Drop your own, keep the same filename. 3:4 portrait works best. |
| `public/solo.mp3` | Ghost autoplay track. Replace with your own audio; keep the name or edit `components/AudioGhost.tsx`. |
| `public/icon.svg` | Favicon. |

### How the ghost audio works (`components/AudioGhost.tsx`)

```ts
const audio = new Audio('/solo.mp3');
audio.loop = true;   // never stops
audio.volume = 0.45; // no controls exposed anywhere
```

* No `<audio>` element is rendered, so **nothing shows up in the DOM, no player, no mute button, no UI**.
* It tries to play instantly on load.
* Chrome/Safari/Firefox block *unmuted* autoplay before a gesture, so the component silently arms one-shot listeners (`pointerdown`, `touchstart`, `keydown`, `scroll`, `wheel`, `click`) and starts the loop the millisecond the visitor touches the page — no prompt, no toast, no indication.
* A keep-alive interval resumes playback if the OS pauses it (screen lock / tab switch).

---

## 6. PROJECT MAP

```
hustler-portfolio/
├── app/
│   ├── globals.css          # theme tokens, glitch, HUD corners, scanlines, cursor rules
│   ├── layout.tsx           # metadata, fonts, SmoothScroll + CustomCursor + AudioGhost
│   └── page.tsx             # section composition
├── components/
│   ├── About.tsx            # dossier section (real name used ONCE)
│   ├── AudioGhost.tsx       # invisible looping autoplay engine
│   ├── Contact.tsx          # email / whatsapp / copy-to-clipboard + footer
│   ├── CustomCursor.tsx     # glowing magnetic cursor (desktop pointers only)
│   ├── Hero.tsx             # giant glitch wordmark, HUD photo, typewriter, CTAs
│   ├── MagneticButton.tsx   # gsap.quickTo magnetic pull
│   ├── Nav.tsx              # sticky nav + mobile sheet
│   ├── Reveal.tsx           # GSAP ScrollTrigger reveal wrapper
│   ├── Scene3D.tsx          # R3F wireframe globe, orbit rings, particle shell, grid
│   ├── SceneBackground.tsx  # ssr:false dynamic mount, deferred 260ms
│   ├── StackMarquee.tsx     # infinite framer-motion marquee
│   └── TerminalSection.tsx  # interactive fake shell
├── lib/
│   ├── hooks.ts             # useTypewriter, useInViewOnce
│   ├── site.ts              # all copy + contact data in one place
│   └── utils.ts             # lenis-aware scrollToSection, clipboard copy
├── public/
│   ├── photo.png
│   ├── solo.mp3
│   ├── icon.svg
│   └── _headers
├── next.config.mjs          # output: 'export', images.unoptimized
├── tailwind.config.ts
├── tsconfig.json
├── wrangler.toml
└── setup.sh
```

---

## 7. PERFORMANCE NOTES (why it does not lag on a phone)

* 3D scene is `ssr: false`, mounted **260 ms after first paint** — never blocks the hero.
* `dpr` capped at `1.35` on mobile / `1.75` desktop, `AdaptiveDpr` from drei downgrades resolution if frames drop.
* Particle count drops from 900 → 420 on small screens; antialias disabled on mobile.
* No texture, no environment map, no post-processing — pure wireframe + additive points.
* All motion respects `prefers-reduced-motion`.

## 8. TROUBLESHOOTING

| Symptom | Fix |
| --- | --- |
| `ERESOLVE could not resolve` | `npm install --legacy-peer-deps` |
| `Module not found: Can't resolve '@/components/...'` | confirm `tsconfig.json` has `"paths": { "@/*": ["./*"] }` and you are inside `hustler-portfolio/` |
| Blank page after deploy | build output dir must be `out`, not `.next` |
| `next: not found` in Termux | `pkg install nodejs` again, then `npm install` |
| Music silent on first load | expected: browser autoplay policy. It starts on the first tap/scroll/keypress — by design, invisibly. |
| Hydration warning | none should appear; `suppressHydrationWarning` is set on `<html>` because of browser extensions injecting attributes |

© Navneet Singh — HUSTLER. All lines of code reserved.
