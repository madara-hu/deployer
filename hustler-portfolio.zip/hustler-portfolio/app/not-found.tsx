import Link from "next/link";

export default function NotFound() {
  return (
    <main className="relative flex min-h-[100svh] flex-col items-center justify-center px-6 text-center">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(circle_at_50%_40%,rgba(0,224,122,0.12),transparent_60%)]"
      />
      <p className="text-[11px] uppercase tracking-[0.3em] text-neon/80">
        Error 404
      </p>
      <h1 className="display mt-5 text-[clamp(3rem,12vw,8rem)]">
        <span className="text-gradient-ghost">Off the</span>{" "}
        <span className="text-gradient-neon">grid.</span>
      </h1>
      <p className="mt-5 max-w-sm text-sm leading-relaxed text-white/45">
        This page doesn&apos;t exist — or it moved while you were looking. Let&apos;s
        get you back somewhere interesting.
      </p>
      <Link href="/" className="btn-neon mt-9">
        Back to Hustler
      </Link>
    </main>
  );
}
