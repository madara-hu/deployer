import type { Metadata, Viewport } from "next";
import { Inter, Space_Grotesk } from "next/font/google";
import "./globals.css";
import SmoothScroll from "@/components/providers/SmoothScroll";
import Cursor from "@/components/ui/Cursor";
import ScrollProgress from "@/components/ui/ScrollProgress";
import Preloader from "@/components/ui/Preloader";
import Navbar from "@/components/sections/Navbar";

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
});

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  display: "swap",
  weight: ["400", "500", "600", "700"],
  variable: "--font-space",
});

const siteUrl = "https://hustler.agency";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Hustler Agency — Premium Digital Experiences by Navneet",
    template: "%s · Hustler Agency",
  },
  description:
    "Hustler is a design-led digital studio founded by Navneet. We turn complex ideas into premium websites, apps, interfaces and brands that people remember.",
  keywords: [
    "Hustler Agency",
    "Navneet",
    "creative agency",
    "web development",
    "UI/UX design",
    "app development",
    "branding",
    "Next.js portfolio",
  ],
  authors: [{ name: "Navneet", url: siteUrl }],
  creator: "Navneet",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: siteUrl,
    siteName: "Hustler Agency",
    title: "Hustler Agency — Premium Digital Experiences",
    description:
      "We turn complex ideas into premium digital experiences. Web, apps, UI/UX and branding by Navneet.",
  },
  twitter: {
    card: "summary_large_image",
    title: "Hustler Agency — Premium Digital Experiences",
    description:
      "Design-led digital studio founded by Navneet. Web, apps, UI/UX and branding.",
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#050505",
  colorScheme: "dark",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html
      lang="en"
      className={`${inter.variable} ${spaceGrotesk.variable}`}
      suppressHydrationWarning
    >
      <body className="relative min-h-screen overflow-x-hidden bg-void font-sans text-white antialiased selection:bg-neon/25">
        <SmoothScroll>
          <Preloader />
          <ScrollProgress />
          <Cursor />
          <Navbar />
          <main id="main">{children}</main>
        </SmoothScroll>
        {/* Global ambient light blobs */}
        <div
          aria-hidden
          className="pointer-events-none fixed inset-0 -z-10 overflow-hidden"
        >
          <div className="absolute -left-40 top-[-10%] h-[520px] w-[520px] rounded-full bg-neon/[0.07] blur-[140px]" />
          <div className="absolute -right-40 top-[35%] h-[560px] w-[560px] rounded-full bg-violet-neon/[0.08] blur-[150px]" />
          <div className="absolute bottom-[-15%] left-1/3 h-[420px] w-[420px] rounded-full bg-neon/[0.05] blur-[130px]" />
          <div className="absolute inset-0 dot-grid opacity-[0.35]" />
        </div>
      </body>
    </html>
  );
}
