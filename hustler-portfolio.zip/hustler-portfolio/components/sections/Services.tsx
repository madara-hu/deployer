"use client";

import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { EASE, viewportOnce } from "@/lib/animations";
import { services } from "@/lib/services";
import SectionHeading from "@/components/ui/SectionHeading";
import TiltCard from "@/components/ui/TiltCard";
import { SERVICE_GLYPHS } from "@/components/ui/ServiceGlyph";

const ICONS = SERVICE_GLYPHS;

export default function Services() {
  return (
    <section id="services" className="relative scroll-mt-24 py-24 sm:py-32">
      <div className="container-x">
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <SectionHeading
            eyebrow="What I do"
            lead="Services built for"
            accent="ambitious brands"
            description="Four disciplines, one senior partner. Every engagement is scoped, designed and built in-house — so the thing you approve is the thing that ships."
          />
          <motion.a
            href="#contact"
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={viewportOnce}
            transition={{ duration: 0.8, ease: EASE, delay: 0.15 }}
            className="btn-ghost shrink-0 self-start md:self-end"
            data-cursor="Enquire"
          >
            Book a discovery call
            <ArrowUpRight className="h-4 w-4" strokeWidth={2.4} />
          </motion.a>
        </div>

        {/* Cards */}
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:mt-16">
          {services.map((service, index) => {
            const Icon = ICONS[service.icon] ?? SERVICE_GLYPHS.sparkles;
            const isNeon = service.accent === "neon";

            return (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 34 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={viewportOnce}
                transition={{ duration: 0.9, ease: EASE, delay: index * 0.08 }}
              >
                <TiltCard intensity={7} className="group h-full">
                  <div
                    className={`relative flex h-full flex-col overflow-hidden rounded-3xl border border-white/[0.08] bg-gradient-to-b from-white/[0.045] to-white/[0.015] p-7 transition-all duration-500 sm:p-9
                      ${
                        isNeon
                          ? "hover:border-neon/40 hover:shadow-[0_0_70px_-25px_rgba(0,224,122,0.55)]"
                          : "hover:border-violet-neon/40 hover:shadow-[0_0_70px_-25px_rgba(124,58,237,0.55)]"
                      }`}
                  >
                    {/* Hover glow bloom */}
                    <div
                      aria-hidden
                      className={`pointer-events-none absolute -right-20 -top-24 h-56 w-56 rounded-full opacity-0 blur-[70px] transition-opacity duration-700 group-hover:opacity-100 ${
                        isNeon ? "bg-neon/25" : "bg-violet-neon/25"
                      }`}
                    />

                    <div className="relative flex items-start justify-between">
                      <span
                        className={`grid h-12 w-12 place-items-center rounded-2xl border transition-all duration-500 ${
                          isNeon
                            ? "border-neon/25 bg-neon/10 text-neon group-hover:bg-neon/15 group-hover:shadow-[0_0_30px_-6px_rgba(0,224,122,0.7)]"
                            : "border-violet-neon/25 bg-violet-neon/10 text-violet-soft group-hover:bg-violet-neon/15 group-hover:shadow-[0_0_30px_-6px_rgba(124,58,237,0.7)]"
                        }`}
                      >
                        <Icon className="h-5 w-5" />
                      </span>

                      <span className="font-display text-xs font-medium tracking-[0.2em] text-white/25">
                        {service.index}
                      </span>
                    </div>

                    <h3 className="relative mt-7 font-display text-2xl font-semibold tracking-[-0.025em] text-white sm:text-[1.75rem]">
                      {service.title}
                    </h3>

                    <p className="relative mt-3 text-sm leading-relaxed text-white/50">
                      {service.description}
                    </p>

                    {/* Tags */}
                    <div className="relative mt-6 flex flex-wrap gap-1.5">
                      {service.tags.map((tag) => (
                        <span
                          key={tag}
                          className="rounded-full border border-white/[0.08] bg-white/[0.03] px-2.5 py-1 text-[10.5px] font-medium uppercase tracking-[0.1em] text-white/45 transition-colors duration-300 group-hover:text-white/65"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>

                    <div className="relative mt-auto flex items-center justify-between pt-8">
                      <span className="text-[11px] uppercase tracking-[0.18em] text-white/25 transition-colors group-hover:text-white/45">
                        From ₹ {isNeon ? "1,20,000" : "85,000"}
                      </span>
                      <span
                        className={`grid h-9 w-9 place-items-center rounded-full border transition-all duration-500 group-hover:rotate-45 ${
                          isNeon
                            ? "border-neon/30 text-neon group-hover:bg-neon group-hover:text-black"
                            : "border-violet-neon/30 text-violet-soft group-hover:bg-violet-neon group-hover:text-white"
                        }`}
                      >
                        <ArrowUpRight className="h-4 w-4" strokeWidth={2.4} />
                      </span>
                    </div>
                  </div>
                </TiltCard>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
