"use client";

import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { EASE, viewportOnce } from "@/lib/animations";
import SectionHeading from "@/components/ui/SectionHeading";

const testimonials = [
  {
    quote:
      "Navneet rebuilt our entire onboarding in six weeks. Activation went from 41% to 68%. He thinks like a product owner, not a vendor.",
    name: "Aarav Mehta",
    role: "Co-founder, Aether",
    initials: "AM",
  },
  {
    quote:
      "The only designer we've worked with who shipped production code alongside the Figma file. Handoff became a non-event.",
    name: "Sofia Lindqvist",
    role: "Head of Product, Orbit",
    initials: "SL",
  },
  {
    quote:
      "Our identity finally matches the quality of the work we make. Every detail was considered — right down to the motion curve.",
    name: "Dev Raghavan",
    role: "Principal, Monolith Studio",
    initials: "DR",
  },
] as const;

export default function Testimonials() {
  return (
    <section className="relative py-24 sm:py-32">
      <div className="container-x">
        <SectionHeading
          eyebrow="Kind words"
          lead="Trusted by founders"
          accent="who ship"
          align="center"
          className="mx-auto max-w-2xl"
        />

        <div className="mt-14 grid gap-5 lg:grid-cols-3">
          {testimonials.map((item, index) => (
            <motion.figure
              key={item.name}
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={viewportOnce}
              transition={{ duration: 0.9, ease: EASE, delay: index * 0.1 }}
              className="group relative flex flex-col justify-between overflow-hidden rounded-3xl border border-white/[0.08] bg-white/[0.025] p-7 transition-colors duration-500 hover:border-neon/25 hover:bg-white/[0.045]"
            >
              <div
                aria-hidden
                className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full bg-neon/0 blur-[60px] transition-colors duration-700 group-hover:bg-neon/15"
              />

              <div>
                <div className="flex gap-0.5">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className="h-3.5 w-3.5 fill-neon text-neon"
                      strokeWidth={0}
                    />
                  ))}
                </div>
                <blockquote className="mt-5 text-[14.5px] leading-relaxed text-white/65">
                  &ldquo;{item.quote}&rdquo;
                </blockquote>
              </div>

              <figcaption className="mt-7 flex items-center gap-3 border-t border-white/[0.07] pt-5">
                <span className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-neon/25 to-violet-neon/25 text-[11px] font-semibold tracking-wide text-white ring-1 ring-white/10">
                  {item.initials}
                </span>
                <span>
                  <span className="block text-[13px] font-semibold text-white">
                    {item.name}
                  </span>
                  <span className="block text-[11px] uppercase tracking-[0.12em] text-white/35">
                    {item.role}
                  </span>
                </span>
              </figcaption>
            </motion.figure>
          ))}
        </div>
      </div>
    </section>
  );
}
