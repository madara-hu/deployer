"use client";

import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { ArrowUpRight, Quote } from "lucide-react";
import { EASE, viewportOnce } from "@/lib/animations";
import { site } from "@/lib/site";
import { stats } from "@/lib/site";
import Counter from "@/components/ui/Counter";

export default function About() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  const imageY = useTransform(scrollYProgress, [0, 1], [50, -50]);

  return (
    <section
      ref={ref}
      id="about"
      className="relative scroll-mt-24 py-24 sm:py-32 lg:py-40"
    >
      <div className="container-x">
        <div className="grid items-center gap-14 lg:grid-cols-[0.95fr_1.05fr] lg:gap-20">
          {/* ------------------------------- Portrait ------------------------------- */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={viewportOnce}
            transition={{ duration: 1.1, ease: EASE }}
            className="relative mx-auto w-full max-w-md lg:mx-0"
          >
            {/* Rotating conic glow frame */}
            <div className="relative aspect-[4/5] w-full">
              <div
                aria-hidden
                className="absolute -inset-4 animate-spin-slow rounded-[2.5rem] bg-[conic-gradient(from_0deg,transparent_0%,rgba(0,224,122,0.65)_18%,transparent_38%,rgba(124,58,237,0.55)_62%,transparent_82%,rgba(0,224,122,0.65)_100%)] opacity-70 blur-[18px]"
              />
              <div
                aria-hidden
                className="absolute -inset-6 rounded-[3rem] bg-neon/10 blur-[60px]"
              />

              <div className="glass relative h-full w-full overflow-hidden rounded-[2rem] p-2">
                <div className="relative h-full w-full overflow-hidden rounded-[1.6rem] bg-ink-900">
                  <motion.div
                    style={{ y: imageY }}
                    className="absolute inset-[-8%]"
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=1000&q=80"
                      alt="Navneet, founder of Hustler Agency"
                      className="h-full w-full object-cover object-center opacity-90 saturate-[0.85]"
                      loading="lazy"
                    />
                  </motion.div>
                  <div className="absolute inset-0 bg-gradient-to-t from-void via-void/25 to-transparent" />

                  {/* Floating name plate */}
                  <div className="absolute inset-x-3 bottom-3 flex items-center justify-between rounded-2xl border border-white/10 bg-black/45 px-4 py-3 backdrop-blur-xl">
                    <div>
                      <p className="font-display text-base font-semibold tracking-tight text-white">
                        Navneet
                      </p>
                      <p className="text-[11px] uppercase tracking-[0.18em] text-white/45">
                        {site.role}
                      </p>
                    </div>
                    <span className="flex items-center gap-1.5 rounded-full border border-neon/30 bg-neon/10 px-2.5 py-1 text-[10px] font-medium uppercase tracking-[0.14em] text-neon">
                      <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-neon" />
                      Open
                    </span>
                  </div>
                </div>
              </div>

              {/* Corner brackets */}
              <span aria-hidden className="absolute -left-3 -top-3 h-8 w-8 border-l border-t border-neon/50" />
              <span aria-hidden className="absolute -bottom-3 -right-3 h-8 w-8 border-b border-r border-neon/50" />
            </div>
          </motion.div>

          {/* -------------------------------- Copy -------------------------------- */}
          <div className="flex flex-col">
            <motion.span
              initial={{ opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={viewportOnce}
              transition={{ duration: 0.7, ease: EASE }}
              className="eyebrow"
            >
              <span className="h-1.5 w-1.5 rounded-full bg-neon shadow-[0_0_10px_2px_rgba(0,224,122,0.8)]" />
              About the studio
            </motion.span>

            <motion.h2
              initial={{ opacity: 0, y: 28, filter: "blur(8px)" }}
              whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              viewport={viewportOnce}
              transition={{ duration: 1, ease: EASE, delay: 0.05 }}
              className="display mt-6 text-[clamp(1.75rem,3.9vw,3.2rem)]"
            >
              <span className="block text-gradient-ghost">Hi, I&apos;m Navneet.</span>
              <span className="block text-gradient-neon">
                I turn complex ideas into premium digital experiences.
              </span>
            </motion.h2>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={viewportOnce}
              transition={{ duration: 0.9, ease: EASE, delay: 0.14 }}
              className="mt-7 space-y-5 text-[15px] leading-relaxed text-white/55 sm:text-base"
            >
              <p>
                Hustler started as a one-person obsession: make the web feel
                less like software and more like a place. Seven years and
                sixty-eight launches later, it&apos;s a small, senior studio that
                partners with founders and product teams to ship interfaces
                people actually remember.
              </p>
              <p>
                I lead design and engineering end-to-end — strategy, interface
                architecture, motion, and the code that ships it. No account
                managers, no handoff chaos. You work directly with the person
                building your product.
              </p>
            </motion.div>

            {/* Pull quote */}
            <motion.figure
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={viewportOnce}
              transition={{ duration: 0.9, ease: EASE, delay: 0.2 }}
              className="mt-8 flex gap-3 rounded-2xl border border-white/[0.08] bg-white/[0.025] p-5"
            >
              <Quote className="mt-0.5 h-4 w-4 shrink-0 text-neon" />
              <blockquote className="text-sm italic leading-relaxed text-white/60">
                &ldquo;Premium isn&apos;t decoration — it&apos;s restraint,
                speed, and the confidence to remove things.&rdquo;
                <figcaption className="mt-2 text-[11px] uppercase not-italic tracking-[0.18em] text-white/30">
                  Navneet — Founder
                </figcaption>
              </blockquote>
            </motion.figure>

            {/* Stats */}
            <motion.dl
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={viewportOnce}
              transition={{ duration: 0.9, ease: EASE, delay: 0.26 }}
              className="mt-9 grid grid-cols-2 gap-x-4 gap-y-6 border-t border-white/[0.08] pt-8 sm:grid-cols-4"
            >
              {stats.map((stat) => (
                <div key={stat.label}>
                  <dd className="font-display text-3xl font-semibold tracking-[-0.03em] text-white sm:text-4xl">
                    <Counter to={stat.value} suffix={stat.suffix} />
                  </dd>
                  <dt className="mt-1.5 text-[11px] uppercase leading-tight tracking-[0.16em] text-white/35">
                    {stat.label}
                  </dt>
                </div>
              ))}
            </motion.dl>

            <motion.a
              href="#contact"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={viewportOnce}
              transition={{ duration: 0.8, delay: 0.3 }}
              data-cursor="Talk"
              className="link-line mt-9 inline-flex items-center gap-2 self-start text-sm font-semibold text-white"
            >
              Let&apos;s build something premium
              <ArrowUpRight className="h-4 w-4 text-neon" strokeWidth={2.5} />
            </motion.a>
          </div>
        </div>
      </div>
    </section>
  );
}
