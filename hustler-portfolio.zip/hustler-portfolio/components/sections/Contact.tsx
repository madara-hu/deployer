"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, Check, Copy, Mail, MapPin, Phone } from "lucide-react";
import { EASE, viewportOnce } from "@/lib/animations";
import { site } from "@/lib/site";
import MagneticButton from "@/components/ui/MagneticButton";

export default function Contact() {
  const [copied, setCopied] = useState(false);

  const copyEmail = async () => {
    try {
      await navigator.clipboard.writeText(site.email);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  };

  return (
    <section id="contact" className="relative scroll-mt-24 py-24 sm:py-32">
      <div className="container-x">
        <motion.div
          initial={{ opacity: 0, y: 34 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={viewportOnce}
          transition={{ duration: 1, ease: EASE }}
          className="relative overflow-hidden rounded-[2rem] border border-white/[0.08] bg-gradient-to-b from-white/[0.06] to-white/[0.015] p-8 sm:rounded-[2.5rem] sm:p-12 lg:p-16"
        >
          {/* Ambient glows */}
          <div aria-hidden className="pointer-events-none absolute -left-24 -top-24 h-72 w-72 rounded-full bg-neon/15 blur-[100px]" />
          <div aria-hidden className="pointer-events-none absolute -bottom-32 -right-20 h-80 w-80 rounded-full bg-violet-neon/15 blur-[110px]" />
          <div aria-hidden className="pointer-events-none absolute inset-0 dot-grid opacity-30" />

          <div className="relative grid gap-12 lg:grid-cols-[1.15fr_0.85fr] lg:gap-16">
            {/* Left: CTA */}
            <div>
              <span className="eyebrow">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-neon shadow-[0_0_10px_2px_rgba(0,224,122,0.9)]" />
                {site.availability}
              </span>

              <h2 className="display mt-6 text-[clamp(2.1rem,5.2vw,4.1rem)]">
                <span className="text-gradient-ghost">Let&apos;s build</span>
                <br />
                <span className="text-gradient-neon">something loud.</span>
              </h2>

              <p className="mt-6 max-w-md text-[15px] leading-relaxed text-white/50">
                Tell me what you&apos;re working on — a rough idea is plenty.
                You&apos;ll get a reply within one business day, with a straight
                answer on whether Hustler is the right fit.
              </p>

              <div className="mt-9 flex flex-col gap-3 sm:flex-row sm:items-center">
                <MagneticButton
                  href={`mailto:${site.email}?subject=New%20project%20enquiry%20—%20Hustler`}
                  cursor="Email"
                  className="btn-neon justify-center"
                >
                  Let&apos;s Talk
                  <ArrowUpRight className="h-4 w-4" strokeWidth={2.6} />
                </MagneticButton>

                <button
                  type="button"
                  onClick={copyEmail}
                  data-cursor={copied ? "Copied" : "Copy"}
                  className="btn-ghost justify-center"
                >
                  {copied ? (
                    <>
                      <Check className="h-4 w-4 text-neon" strokeWidth={2.6} />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4" strokeWidth={2.2} />
                      {site.email}
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Right: Details card */}
            <div className="glass-deep flex flex-col justify-between gap-6 rounded-3xl p-6 sm:p-7">
              <div className="space-y-5">
                {[
                  { icon: Mail, label: "Email", value: site.email, href: `mailto:${site.email}` },
                  { icon: Phone, label: "Phone", value: site.phone, href: `tel:${site.phone.replace(/\s/g, "")}` },
                  { icon: MapPin, label: "Based in", value: site.location },
                ].map((row) => {
                  const Icon = row.icon;
                  const content = (
                    <div className="group flex items-start gap-3.5">
                      <span className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-white/10 bg-white/[0.04] text-white/55 transition-colors duration-300 group-hover:border-neon/35 group-hover:text-neon">
                        <Icon className="h-4 w-4" strokeWidth={1.9} />
                      </span>
                      <span>
                        <span className="block text-[10px] uppercase tracking-[0.2em] text-white/30">
                          {row.label}
                        </span>
                        <span className="mt-1 block text-[13.5px] font-medium text-white/80 transition-colors group-hover:text-neon">
                          {row.value}
                        </span>
                      </span>
                    </div>
                  );
                  return row.href ? (
                    <a key={row.label} href={row.href} className="block">
                      {content}
                    </a>
                  ) : (
                    <div key={row.label}>{content}</div>
                  );
                })}
              </div>

              <div className="rounded-2xl border border-white/[0.08] bg-black/25 p-4">
                <p className="text-[11px] uppercase tracking-[0.2em] text-neon/80">
                  Current slots
                </p>
                <p className="mt-2 text-[13px] leading-relaxed text-white/50">
                  2 project slots open for Q1 2026. Typical engagement:{" "}
                  <span className="text-white/75">₹1.2L – ₹6L</span>, 4–8 weeks.
                </p>
                <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: "72%" }}
                    viewport={viewportOnce}
                    transition={{ duration: 1.4, ease: EASE, delay: 0.3 }}
                    className="h-full rounded-full bg-gradient-to-r from-neon to-neon-soft"
                  />
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
