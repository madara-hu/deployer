"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion, useScroll, useMotionValueEvent } from "framer-motion";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { navLinks, site } from "@/lib/site";
import { EASE } from "@/lib/animations";
import MagneticButton from "@/components/ui/MagneticButton";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { scrollY } = useScroll();

  useMotionValueEvent(scrollY, "change", (latest) => {
    setScrolled(latest > 40);
  });

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <>
      <motion.header
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1, ease: EASE, delay: 0.2 }}
        className="fixed inset-x-0 top-0 z-[90]"
      >
        <div className="container-x">
          <div
            className={`mt-4 flex items-center justify-between rounded-full px-4 py-3 transition-all duration-500 sm:px-5 ${
              scrolled
                ? "glass shadow-glass"
                : "border border-transparent bg-transparent"
            }`}
          >
            {/* Logo */}
            <a
              href="#top"
              data-cursor="Top"
              className="group flex items-center gap-2.5 pl-1"
              aria-label="Hustler — back to top"
            >
              <span className="relative grid h-8 w-8 place-items-center rounded-full bg-neon/10 ring-1 ring-neon/40">
                <span className="h-2 w-2 rounded-full bg-neon shadow-[0_0_12px_2px_rgba(0,224,122,0.9)]" />
                <span className="absolute inset-0 animate-pulse-ring rounded-full ring-1 ring-neon/40" />
              </span>
              <span className="font-display text-lg font-bold tracking-[-0.03em] text-white">
                Hustler<span className="text-neon">.</span>
              </span>
            </a>

            {/* Desktop nav */}
            <nav className="hidden items-center gap-1 md:flex">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className="group relative rounded-full px-4 py-2 text-sm font-medium text-white/60 transition-colors duration-300 hover:text-white"
                >
                  <span className="relative z-10">{link.label}</span>
                  <span className="absolute inset-0 scale-90 rounded-full bg-white/[0.07] opacity-0 transition-all duration-300 group-hover:scale-100 group-hover:opacity-100" />
                </a>
              ))}
            </nav>

            <div className="flex items-center gap-2">
              <MagneticButton
                href="#contact"
                cursor="Let's talk"
                className="hidden btn-neon !px-5 !py-2.5 text-[13px] sm:inline-flex"
              >
                Let&apos;s Talk
                <ArrowUpRight className="h-4 w-4" strokeWidth={2.5} />
              </MagneticButton>

              <button
                type="button"
                onClick={() => setOpen((v) => !v)}
                aria-label={open ? "Close menu" : "Open menu"}
                aria-expanded={open}
                className="grid h-10 w-10 place-items-center rounded-full border border-white/10 bg-white/[0.04] text-white md:hidden"
              >
                {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
              </button>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Mobile menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.35 }}
            className="fixed inset-0 z-[95] md:hidden"
          >
            <div
              className="absolute inset-0 bg-void/95 backdrop-blur-2xl"
              onClick={() => setOpen(false)}
            />
            <motion.nav
              initial={{ y: 24, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 24, opacity: 0 }}
              transition={{ duration: 0.5, ease: EASE }}
              className="relative flex h-full flex-col justify-center gap-2 px-7"
            >
              {navLinks.map((link, i) => (
                <motion.a
                  key={link.href}
                  href={link.href}
                  onClick={() => setOpen(false)}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.08 * i + 0.1, duration: 0.5, ease: EASE }}
                  className="flex items-baseline justify-between border-b border-white/10 py-4"
                >
                  <span className="font-display text-3xl font-semibold tracking-[-0.03em] text-white">
                    {link.label}
                  </span>
                  <span className="text-[11px] uppercase tracking-[0.2em] text-white/30">
                    0{i + 1}
                  </span>
                </motion.a>
              ))}

              <motion.a
                href="#contact"
                onClick={() => setOpen(false)}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 0.5 }}
                className="btn-neon mt-8 justify-center"
              >
                Let&apos;s Talk
                <ArrowUpRight className="h-4 w-4" strokeWidth={2.5} />
              </motion.a>

              <p className="mt-6 text-xs text-white/35">{site.email}</p>
            </motion.nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
