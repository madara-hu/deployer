"use client";

import { motion } from "framer-motion";
import {
  ArrowUp,
  ArrowUpRight,
  Github,
  Instagram,
  Linkedin,
  type LucideIcon,
} from "lucide-react";
import { EASE, viewportOnce } from "@/lib/animations";
import { navLinks, site, socials } from "@/lib/site";

const SOCIAL_ICONS: Record<string, LucideIcon> = {
  instagram: Instagram,
  github: Github,
  linkedin: Linkedin,
};

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="relative overflow-hidden border-t border-white/[0.07] pt-28">
      {/* Giant CTA line above the footer */}
      <div className="container-x">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={viewportOnce}
          transition={{ duration: 1, ease: EASE }}
          className="flex flex-col items-start justify-between gap-8 border-b border-white/[0.07] pb-14 md:flex-row md:items-end"
        >
          <div>
            <p className="text-[11px] uppercase tracking-[0.28em] text-white/30">
              Ready when you are
            </p>
            <h2 className="display mt-4 text-[clamp(2.5rem,8vw,6rem)]">
              <span className="text-gradient-ghost">Say hello</span>
              <span className="text-neon">.</span>
            </h2>
          </div>

          <a
            href={`mailto:${site.email}`}
            data-cursor="Email"
            className="group flex items-center gap-3 text-base font-medium text-white/70 transition-colors hover:text-white sm:text-lg"
          >
            {site.email}
            <span className="grid h-11 w-11 place-items-center rounded-full border border-neon/40 bg-neon/10 text-neon transition-all duration-500 group-hover:rotate-45 group-hover:bg-neon group-hover:text-black">
              <ArrowUpRight className="h-4 w-4" strokeWidth={2.5} />
            </span>
          </a>
        </motion.div>

        {/* Link columns */}
        <div className="grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-4">
          <div className="lg:col-span-2">
            <a href="#top" className="flex items-center gap-2.5">
              <span className="relative grid h-8 w-8 place-items-center rounded-full bg-neon/10 ring-1 ring-neon/40">
                <span className="h-2 w-2 rounded-full bg-neon shadow-[0_0_12px_2px_rgba(0,224,122,0.9)]" />
              </span>
              <span className="font-display text-lg font-bold tracking-[-0.03em]">
                Hustler<span className="text-neon">.</span>
              </span>
            </a>
            <p className="mt-5 max-w-xs text-[13.5px] leading-relaxed text-white/40">
              A design-led digital studio by Navneet. We turn complex ideas into
              premium digital experiences — websites, products and brands with a
              point of view.
            </p>

            <div className="mt-6 flex items-center gap-2.5">
              {socials.map((social) => {
                const Icon = SOCIAL_ICONS[social.icon] ?? Instagram;
                return (
                  <a
                    key={social.label}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={social.label}
                    data-cursor={social.label}
                    className="group grid h-10 w-10 place-items-center rounded-full border border-white/10 bg-white/[0.03] text-white/55 transition-all duration-500 hover:-translate-y-0.5 hover:border-neon/40 hover:bg-neon/10 hover:text-neon"
                  >
                    <Icon className="h-4 w-4" strokeWidth={1.8} />
                  </a>
                );
              })}
            </div>
          </div>

          <nav aria-label="Footer navigation">
            <p className="text-[10px] uppercase tracking-[0.24em] text-white/30">
              Navigate
            </p>
            <ul className="mt-4 space-y-2.5">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-[13.5px] text-white/50 transition-colors hover:text-white"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <p className="text-[10px] uppercase tracking-[0.24em] text-white/30">
              Elsewhere
            </p>
            <ul className="mt-4 space-y-2.5">
              {socials.map((social) => (
                <li key={social.label}>
                  <a
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group inline-flex items-center gap-1.5 text-[13.5px] text-white/50 transition-colors hover:text-white"
                  >
                    {social.label}
                    <span className="text-[11px] text-white/25 group-hover:text-neon">
                      {social.handle}
                    </span>
                  </a>
                </li>
              ))}
              <li>
                <a
                  href={`mailto:${site.email}`}
                  className="text-[13.5px] text-white/50 transition-colors hover:text-white"
                >
                  {site.email}
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="flex flex-col items-center justify-between gap-4 border-t border-white/[0.07] py-7 sm:flex-row">
          <p className="text-[11.5px] text-white/30">
            © {year} Hustler Agency · Crafted by Navneet in {site.location.split("—")[0].trim()}
          </p>
          <div className="flex items-center gap-5">
            <span className="flex items-center gap-1.5 text-[11.5px] text-white/30">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-neon" />
              All systems operational
            </span>
            <a
              href="#top"
              data-cursor="Top"
              className="group flex items-center gap-1.5 text-[11.5px] text-white/40 transition-colors hover:text-neon"
            >
              Back to top
              <span className="grid h-7 w-7 place-items-center rounded-full border border-white/10 transition-colors group-hover:border-neon/40">
                <ArrowUp className="h-3 w-3" strokeWidth={2.5} />
              </span>
            </a>
          </div>
        </div>
      </div>

      {/* Oversized watermark wordmark */}
      <div
        aria-hidden
        className="relative h-[clamp(4.5rem,13vw,11rem)] select-none overflow-hidden"
      >
        <p className="pointer-events-none absolute inset-x-0 top-0 whitespace-nowrap text-center font-display text-[clamp(5rem,19.5vw,17rem)] font-bold uppercase leading-[0.78] tracking-[-0.05em] text-transparent [-webkit-text-stroke:1px_rgba(255,255,255,0.09)]">
          Hustler
        </p>
      </div>
    </footer>
  );
}
