"use client";

import { useRef, useState } from "react";
import { motion, useScroll, useTransform, AnimatePresence } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { EASE, viewportOnce } from "@/lib/animations";
import { projects, type Project } from "@/lib/projects";
import SectionHeading from "@/components/ui/SectionHeading";

const FILTERS = ["All", "Web", "App", "UI/UX", "Brand"] as const;

function ProjectCard({
  project,
  index,
}: {
  project: Project;
  index: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  // Subtle parallax on the image inside its frame
  const y = useTransform(scrollYProgress, [0, 1], ["-6%", "6%"]);
  const featured = project.featured;

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={viewportOnce}
      transition={{ duration: 0.95, ease: EASE, delay: (index % 2) * 0.09 }}
      className={featured ? "sm:col-span-2" : ""}
    >
      <a
        href={project.href}
        data-cursor="Case study"
        className="group relative block overflow-hidden rounded-[1.75rem] border border-white/[0.08] bg-ink-900"
      >
        <div
          ref={ref}
          className={`relative w-full overflow-hidden ${
            featured ? "aspect-[16/11] sm:aspect-[21/9]" : "aspect-[4/3]"
          }`}
        >
          {/* Image with parallax + scale-on-hover */}
          <motion.div style={{ y }} className="absolute inset-[-6%]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={project.image}
              alt={`${project.title} — ${project.category} project by Hustler Agency`}
              loading="lazy"
              className="h-full w-full scale-100 object-cover opacity-70 saturate-[0.75] transition-all duration-[1.1s] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.07] group-hover:opacity-95 group-hover:saturate-100"
            />
          </motion.div>

          {/* Legibility scrim */}
          <div className="absolute inset-0 bg-gradient-to-t from-void via-void/55 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 h-2/3 bg-gradient-to-t from-void via-void/85 to-transparent opacity-95 transition-opacity duration-700 group-hover:opacity-100" />

          {/* Neon border light on hover */}
          <div
            aria-hidden
            className="pointer-events-none absolute inset-0 rounded-[1.75rem] opacity-0 ring-1 ring-inset ring-neon/45 transition-opacity duration-500 group-hover:opacity-100"
          />

          {/* Top meta chips */}
          <div className="absolute left-4 top-4 flex flex-wrap gap-2 sm:left-5 sm:top-5">
            <span className="rounded-full border border-white/15 bg-black/40 px-2.5 py-1 text-[10px] font-medium uppercase tracking-[0.16em] text-white/80 backdrop-blur-md">
              {project.category}
            </span>
            <span className="rounded-full border border-white/10 bg-black/30 px-2.5 py-1 text-[10px] font-medium uppercase tracking-[0.16em] text-white/50 backdrop-blur-md">
              {project.year}
            </span>
          </div>

          {/* Hover arrow */}
          <span className="absolute right-4 top-4 grid h-10 w-10 place-items-center rounded-full border border-neon/40 bg-neon/15 text-neon opacity-0 backdrop-blur-md transition-all duration-500 group-hover:opacity-100 group-hover:rotate-45 sm:right-5 sm:top-5">
            <ArrowUpRight className="h-4 w-4" strokeWidth={2.5} />
          </span>

          {/* Bottom content */}
          <div className="absolute inset-x-0 bottom-0 p-5 sm:p-7">
            <h3 className="font-display text-xl font-semibold tracking-[-0.025em] text-white sm:text-2xl">
              {project.title}
            </h3>
            <p className="mt-1.5 max-w-md text-[13px] leading-relaxed text-white/50 transition-colors duration-500 group-hover:text-white/70">
              {project.summary}
            </p>

            {/* Tags slide up on hover */}
            <div className="mt-3 flex flex-wrap gap-1.5 opacity-100 transition-all duration-700 sm:translate-y-1 sm:opacity-70 sm:group-hover:translate-y-0 sm:group-hover:opacity-100">
              {project.tags.map((tag) => (
                <span
                  key={tag}
                  className="rounded-full border border-white/10 px-2 py-0.5 text-[10px] uppercase tracking-[0.12em] text-white/40"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      </a>
    </motion.article>
  );
}

export default function Projects() {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("All");
  const visible =
    filter === "All" ? projects : projects.filter((p) => p.category === filter);

  return (
    <section id="work" className="relative scroll-mt-24 py-24 sm:py-32">
      <div className="container-x">
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <SectionHeading
            eyebrow="Selected work"
            lead="Projects that"
            accent="moved the needle"
            description="A slice of recent launches — fintech dashboards, travel products, identity systems. Every one shipped on time, measured after launch."
          />

          {/* Filters */}
          <div className="flex flex-wrap gap-1.5">
            {FILTERS.map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => setFilter(item)}
                className={`relative rounded-full px-4 py-2 text-[12px] font-medium uppercase tracking-[0.12em] transition-colors duration-300 ${
                  filter === item
                    ? "text-black"
                    : "text-white/45 hover:text-white/80"
                }`}
              >
                {filter === item && (
                  <motion.span
                    layoutId="filter-pill"
                    className="absolute inset-0 rounded-full bg-neon"
                    transition={{ type: "spring", stiffness: 380, damping: 32 }}
                  />
                )}
                <span className="relative z-10">{item}</span>
              </button>
            ))}
          </div>
        </div>

        <motion.div layout className="mt-14 grid gap-5 sm:grid-cols-2 lg:mt-16">
          <AnimatePresence mode="popLayout">
            {visible.map((project, index) => (
              <ProjectCard key={project.id} project={project} index={index} />
            ))}
          </AnimatePresence>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={viewportOnce}
          transition={{ duration: 0.8, ease: EASE }}
          className="mt-12 flex justify-center"
        >
          <a href="#contact" data-cursor="Enquire" className="btn-ghost">
            See the full archive — 68 projects
            <ArrowUpRight className="h-4 w-4" strokeWidth={2.4} />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
