"use client";

import { marqueeWords } from "@/lib/site";

/**
 * Infinite marquee band — the seam between hero and about.
 * Duplicated once, translated -50%, so the loop is invisible.
 */
export default function Marquee({ reverse = false }: { reverse?: boolean }) {
  const items = [...marqueeWords, ...marqueeWords];

  return (
    <div className="relative border-y border-white/[0.07] bg-white/[0.015] py-5 backdrop-blur-sm">
      <div className="mask-fade-x overflow-hidden">
        <div
          className={`flex w-max items-center gap-10 ${
            reverse ? "animate-marquee-fast [animation-direction:reverse]" : "animate-marquee"
          }`}
        >
          {items.map((word, i) => (
            <div key={`${word}-${i}`} className="flex items-center gap-10">
              <span className="whitespace-nowrap font-display text-xl font-medium tracking-[-0.02em] text-white/45 sm:text-2xl">
                {word}
              </span>
              <span
                aria-hidden
                className="h-1.5 w-1.5 shrink-0 rotate-45 bg-neon/70"
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
