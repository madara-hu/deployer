"use client";

import { motion } from "framer-motion";
import { Compass, Layers, Rocket, Search } from "lucide-react";
import { EASE, viewportOnce } from "@/lib/animations";
import SectionHeading from "@/components/ui/SectionHeading";

const steps = [
  {
    step: "01",
    title: "Discover",
    duration: "Week 1",
    body: "Stakeholder interviews, competitive teardown and a written brief. We agree on what success looks like before a single pixel moves.",
    icon: Search,
  },
  {
    step: "02",
    title: "Design",
    duration: "Weeks 2–3",
    body: "Flows, then interface. You review in Figma with real copy, real data and a clickable prototype — not grey boxes.",
    icon: Compass,
  },
  {
    step: "03",
    title: "Build",
    duration: "Weeks 4–6",
    body: "Next.js, TypeScript, a component library and a staging URL you can refresh anytime. Weekly demos, no black boxes.",
    icon: Layers,
  },
  {
    step: "04",
    title: "Launch",
    duration: "Week 7",
    body: "Analytics, performance budget, handover docs and 30 days of post-launch support. Then we measure what happened.",
    icon: Rocket,
  },
] as const;

export default function Process() {
  return (
    <section id="process" className="relative scroll-mt-24 py-24 sm:py-32">
      <div className="container-x">
        <SectionHeading
          eyebrow="How we work"
          lead="A calm, seven-week"
          accent="path to launch"
          description="No agency theatre. Fixed scope, fixed price, weekly demos. You always know what's shipping next."
          align="center"
          className="mx-auto max-w-3xl"
        />

        <div className="relative mt-16">
          {/* Connector line */}
          <div
            aria-hidden
            className="absolute left-0 right-0 top-[42px] hidden h-px bg-gradient-to-r from-transparent via-white/10 to-transparent lg:block"
          />

          <div className="grid gap-8 lg:grid-cols-4 lg:gap-6">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <motion.div
                  key={step.step}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={viewportOnce}
                  transition={{ duration: 0.85, ease: EASE, delay: index * 0.1 }}
                  className="group relative"
                >
                  <div className="relative mb-6 flex items-center gap-4">
                    <span className="relative grid h-14 w-14 shrink-0 place-items-center rounded-2xl border border-white/10 bg-ink-900 text-white/70 transition-all duration-500 group-hover:border-neon/45 group-hover:text-neon group-hover:shadow-[0_0_36px_-10px_rgba(0,224,122,0.75)]">
                      <Icon className="h-5 w-5" strokeWidth={1.7} />
                      <span className="absolute -inset-px rounded-2xl bg-neon/0 transition-colors duration-500 group-hover:bg-neon/[0.06]" />
                    </span>
                    <span className="font-display text-[11px] uppercase tracking-[0.24em] text-white/25">
                      {step.duration}
                    </span>
                  </div>

                  <h3 className="font-display text-xl font-semibold tracking-[-0.02em] text-white">
                    <span className="mr-2 text-neon/70">{step.step}</span>
                    {step.title}
                  </h3>
                  <p className="mt-2.5 text-[13.5px] leading-relaxed text-white/45">
                    {step.body}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Deliverables strip */}
        <motion.div
          initial={{ opacity: 0, y: 22 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={viewportOnce}
          transition={{ duration: 0.9, ease: EASE, delay: 0.15 }}
          className="glass mt-16 grid gap-6 rounded-3xl p-7 sm:grid-cols-3 sm:p-9"
        >
          {[
            { k: "Fixed price", v: "Quoted before we start. No surprise invoices." },
            { k: "Weekly demos", v: "A live staging link from day three onwards." },
            { k: "Full handover", v: "Repo, Figma file and docs are yours to keep." },
          ].map((item) => (
            <div key={item.k}>
              <p className="text-[11px] uppercase tracking-[0.2em] text-neon/80">
                {item.k}
              </p>
              <p className="mt-2 text-[13.5px] leading-relaxed text-white/50">
                {item.v}
              </p>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
