"use client";

import dynamic from "next/dynamic";
import { motion, useScroll, useTransform, useReducedMotion } from "framer-motion";
import { useRef } from "react";
import { ArrowDown, ArrowUpRight, Sparkles } from "lucide-react";
import { EASE } from "@/lib/animations";
import { site } from "@/lib/site";
import MagneticButton from "@/components/ui/MagneticButton";
import StaticOrb from "@/components/three/StaticOrb";
import SceneBoundary from "@/components/three/SceneBoundary";
import { isWebGLAvailable } from "@/lib/webgl";
import { useEffect, useState } from "react";

/** WebGL is client-only — keep it out of the server render + first paint. */
const HeroScene = dynamic(() => import("@/components/three/HeroScene"), {
  ssr: false,
  loading: () => null,
});

const HEADLINE = ["Hustler", "Agency"];

export default function Hero() {
  const ref = useRef<HTMLElement>(null);
  const prefersReduced = useReducedMotion();
  const [quality, setQuality] = useState<"low" | "high">("low");
  const [sceneReady, setSceneReady] = useState(false);
  const [webgl, setWebgl] = useState(false);

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });

  const contentY = useTransform(scrollYProgress, [0, 1], [0, 120]);
  const contentOpacity = useTransform(scrollYProgress, [0, 0.75], [1, 0]);
  const sceneScale = useTransform(scrollYProgress, [0, 1], [1, 1.22]);
  const sceneY = useTransform(scrollYProgress, [0, 1], [0, -80]);

  // Only mount WebGL after the browser is idle, and dial down quality on small screens.
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const isSmall = window.innerWidth < 768;
    const isLowPower =
      typeof navigator !== "undefined" &&
      (navigator.hardwareConcurrency ?? 8) <= 4;

    // Never attempt to mount a GL context the device cannot create.
    if (!isWebGLAvailable()) return;

    setWebgl(true);

    const timer = window.setTimeout(() => {
      setQuality(isSmall || isLowPower ? "low" : "high");
      setSceneReady(true);
    }, 260);

    return () => window.clearTimeout(timer);
  }, []);

  return (
    <section
      ref={ref}
      id="top"
      className="relative flex min-h-[100svh] flex-col items-center justify-center overflow-hidden pb-24 pt-32 sm:pt-36"
    >
      {/* 3D layer */}
      <motion.div
        aria-hidden
        style={{
          scale: prefersReduced ? 1 : sceneScale,
          y: prefersReduced ? 0 : sceneY,
        }}
        className="pointer-events-none absolute inset-0 z-0"
      >
        <div className="absolute inset-0 opacity-80 [mask-image:radial-gradient(circle_at_50%_45%,black_32%,transparent_76%)]">
          {sceneReady ? (
            <SceneBoundary fallback={<StaticOrb />}>
              <HeroScene quality={quality} />
            </SceneBoundary>
          ) : (
            webgl ? null : <StaticOrb />
          )}
        </div>
      </motion.div>

      {/* Radial vignette + grid */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 z-[1] bg-[radial-gradient(ellipse_at_center,rgba(5,5,5,0.1)_18%,rgba(5,5,5,0.72)_62%,#050505_88%)]"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 bottom-0 z-[1] h-56 bg-gradient-to-t from-void via-void/80 to-transparent"
      />
      {/* Local scrim so the sub-copy always clears the 3D object */}
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-[52%] z-[1] h-[52%] w-[115%] -translate-x-1/2 bg-[radial-gradient(ellipse_at_50%_65%,rgba(5,5,5,0.92)_0%,rgba(5,5,5,0.72)_38%,transparent_72%)]"
      />

      <motion.div
        style={{
          y: prefersReduced ? 0 : contentY,
          opacity: prefersReduced ? 1 : contentOpacity,
        }}
        className="container-x relative z-10 flex flex-col items-center text-center"
      >
        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: EASE, delay: 0.15 }}
          className="eyebrow mb-7 gap-2.5"
        >
          <Sparkles className="h-3.5 w-3.5 text-neon" />
          <span className="normal-case tracking-[0.14em] text-white/70">
            {site.availability}
          </span>
        </motion.div>

        {/* Massive headline */}
        <h1 className="display relative text-[clamp(3.1rem,11.5vw,9.75rem)] uppercase">
          {HEADLINE.map((word, wordIndex) => (
            <span key={word} className="block overflow-hidden pb-[0.06em]">
              <motion.span
                initial={{ y: "115%", rotate: 4 }}
                animate={{ y: "0%", rotate: 0 }}
                transition={{
                  duration: 1.25,
                  ease: EASE,
                  delay: 0.25 + wordIndex * 0.13,
                }}
                className={`inline-block ${
                  wordIndex === 1 ? "text-gradient-neon text-shadow-glow" : "text-white"
                }`}
              >
                {word}
              </motion.span>
            </span>
          ))}

          {/* Floating accent dot */}
          <motion.span
            aria-hidden
            animate={{ y: [0, -10, 0], rotate: [0, 12, 0] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -right-2 top-2 hidden h-3 w-3 rounded-full bg-neon shadow-[0_0_24px_4px_rgba(0,224,122,0.8)] sm:block"
          />
        </h1>

        {/* Sub copy */}
        <motion.p
          initial={{ opacity: 0, y: 20, filter: "blur(6px)" }}
          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          transition={{ duration: 0.95, ease: EASE, delay: 0.62 }}
          className="mt-8 max-w-[38ch] text-pretty text-[15px] leading-relaxed text-white/55 sm:max-w-xl sm:text-lg"
        >
          A design-led studio by{" "}
          <span className="font-medium text-white/90">Navneet</span> — crafting
          premium websites, products and brands for founders who refuse to blend
          in.
        </motion.p>

        {/* CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 22 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, ease: EASE, delay: 0.78 }}
          className="mt-10 flex flex-col items-center gap-3 sm:flex-row sm:gap-4"
        >
          <MagneticButton
            href="#work"
            cursor="View"
            className="btn-neon w-full justify-center sm:w-auto"
          >
            View Selected Work
            <ArrowUpRight className="h-4 w-4" strokeWidth={2.6} />
          </MagneticButton>

          <MagneticButton
            href="#contact"
            cursor="Talk"
            className="btn-ghost w-full justify-center sm:w-auto"
          >
            Start a Project
            <span className="h-1.5 w-1.5 rounded-full bg-neon shadow-[0_0_10px_2px_rgba(0,224,122,0.9)]" />
          </MagneticButton>
        </motion.div>

        {/* Mini stat strip */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.05 }}
          className="mt-14 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-[11px] uppercase tracking-[0.2em] text-white/35 sm:gap-x-12"
        >
          <span>68+ Projects</span>
          <span className="hidden h-3 w-px bg-white/15 sm:block" />
          <span>7 Years Craft</span>
          <span className="hidden h-3 w-px bg-white/15 sm:block" />
          <span>Global Clients</span>
        </motion.div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.a
        href="#about"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.3, duration: 0.8, ease: EASE }}
        style={{ opacity: prefersReduced ? 1 : contentOpacity }}
        className="group absolute bottom-7 left-1/2 z-10 flex -translate-x-1/2 flex-col items-center gap-2.5"
        aria-label="Scroll to explore"
      >
        <span className="text-[10px] uppercase tracking-[0.32em] text-white/35 transition-colors group-hover:text-neon">
          Scroll to explore
        </span>
        <span className="relative grid h-9 w-9 place-items-center rounded-full border border-white/10 transition-colors group-hover:border-neon/60">
          <motion.span
            animate={{ y: [-2, 3, -2] }}
            transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
          >
            <ArrowDown className="h-3.5 w-3.5 text-white/60 transition-colors group-hover:text-neon" />
          </motion.span>
          <span className="absolute inset-0 animate-pulse-ring rounded-full border border-neon/30" />
        </span>
      </motion.a>
    </section>
  );
}
