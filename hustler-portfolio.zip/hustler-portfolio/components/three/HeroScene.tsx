"use client";

import { useRef, useMemo, Suspense } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Float, MeshDistortMaterial, Sparkles, TorusKnot } from "@react-three/drei";
import * as THREE from "three";

/* --------------------------------------------------------------------------
 * Pointer rig — smoothly interpolates the scene toward the mouse position.
 * -------------------------------------------------------------------------- */
function PointerRig({ children }: { children: React.ReactNode }) {
  const group = useRef<THREE.Group>(null);
  const { pointer } = useThree();

  useFrame((_, delta) => {
    if (!group.current) return;
    const damp = Math.min(1, delta * 3.2);
    group.current.rotation.y +=
      (pointer.x * 0.45 - group.current.rotation.y) * damp;
    group.current.rotation.x +=
      (-pointer.y * 0.3 - group.current.rotation.x) * damp;
    group.current.position.x += (pointer.x * 0.35 - group.current.position.x) * damp;
    group.current.position.y += (pointer.y * 0.22 - group.current.position.y) * damp;
  });

  return <group ref={group}>{children}</group>;
}

/* --------------------------------------------------------------------------
 * The hero object: a distorted torus knot inside a wireframe shell.
 * -------------------------------------------------------------------------- */
function KnotCore() {
  const inner = useRef<THREE.Mesh>(null);
  const shell = useRef<THREE.Mesh>(null);

  useFrame((state, delta) => {
    const t = state.clock.getElapsedTime();
    if (inner.current) {
      inner.current.rotation.z += delta * 0.08;
    }
    if (shell.current) {
      shell.current.rotation.z -= delta * 0.12;
      shell.current.rotation.y += delta * 0.05;
      const s = 1 + Math.sin(t * 0.7) * 0.015;
      shell.current.scale.setScalar(s);
    }
  });

  return (
    <group>
      {/* Solid, metallic core */}
      <TorusKnot ref={inner} args={[1, 0.34, 220, 32, 2, 3]} castShadow>
        <meshPhysicalMaterial
          color="#0b0f0d"
          metalness={0.92}
          roughness={0.16}
          clearcoat={1}
          clearcoatRoughness={0.08}
          emissive="#00e07a"
          emissiveIntensity={0.12}
          envMapIntensity={1.4}
        />
      </TorusKnot>

      {/* Neon wireframe shell */}
      <TorusKnot ref={shell} args={[1.005, 0.345, 140, 20, 2, 3]}>
        <meshBasicMaterial
          color="#00e07a"
          wireframe
          transparent
          opacity={0.16}
        />
      </TorusKnot>

      {/* Companion violet knot — depth + colour contrast */}
      <TorusKnot args={[0.62, 0.11, 160, 20, 3, 4]} rotation={[0.6, 0.4, 0]}>
        <meshStandardMaterial
          color="#7c3aed"
          emissive="#7c3aed"
          emissiveIntensity={1.4}
          roughness={0.35}
          metalness={0.2}
          transparent
          opacity={0.85}
        />
      </TorusKnot>
    </group>
  );
}

/* --------------------------------------------------------------------------
 * Soft glowing orb behind the knot.
 * -------------------------------------------------------------------------- */
function GlowOrb() {
  return (
    <mesh position={[0, 0, -2.6]} scale={2.8}>
      <sphereGeometry args={[1, 32, 32]} />
      <MeshDistortMaterial
        color="#00e07a"
        emissive="#00b863"
        emissiveIntensity={0.35}
        roughness={1}
        metalness={0}
        distort={0.55}
        speed={1.2}
        transparent
        opacity={0.1}
      />
    </mesh>
  );
}

/* --------------------------------------------------------------------------
 * Scene
 * -------------------------------------------------------------------------- */
function Scene({ quality }: { quality: "low" | "high" }) {
  return (
    <>
      <color attach="background" args={["#050505"]} />
      <fog attach="fog" args={["#050505", 7, 16]} />

      <ambientLight intensity={0.35} />
      <directionalLight position={[4, 5, 5]} intensity={1.1} color="#d9ffe9" />
      <pointLight position={[-4, -2, 2]} intensity={26} color="#7c3aed" distance={12} />
      <pointLight position={[3, 2, 3]} intensity={30} color="#00e07a" distance={12} />

      <Suspense fallback={null}>
        <Float speed={1.4} rotationIntensity={0.35} floatIntensity={0.9}>
          <PointerRig>
            <KnotCore />
          </PointerRig>
        </Float>

        <GlowOrb />

        <Sparkles
          count={quality === "high" ? 90 : 40}
          scale={[8, 6, 6]}
          size={2.2}
          speed={0.32}
          opacity={0.55}
          color="#5cffb1"
        />

        {quality === "high" && (
          <Sparkles
            count={30}
            scale={[9, 7, 4]}
            size={3.4}
            speed={0.2}
            opacity={0.28}
            color="#a78bfa"
          />
        )}
      </Suspense>
    </>
  );
}

/* --------------------------------------------------------------------------
 * Public canvas wrapper
 * -------------------------------------------------------------------------- */
export default function HeroScene({ quality = "high" }: { quality?: "low" | "high" }) {
  const dpr = useMemo<[number, number]>(() => [1, quality === "high" ? 1.9 : 1.3], [quality]);

  return (
    <Canvas
      dpr={dpr}
      camera={{ position: [0, 0, 6.2], fov: 42 }}
      gl={{
        antialias: true,
        alpha: true,
        powerPreference: "high-performance",
      }}
      style={{ pointerEvents: "none" }}
      onCreated={({ gl }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping;
        gl.toneMappingExposure = 1.15;
      }}
    >
      <Scene quality={quality} />
    </Canvas>
  );
}
