"use client";

import { motion, useReducedMotion } from "framer-motion";

/**
 * Static hero backdrop used whenever WebGL is unavailable.
 * Pure CSS: layered conic/radial gradients + a wireframe ring,
 * so the hero still reads as premium without a GL context.
 */
export default function StaticOrb() {
  const reduced = useReducedMotion();

  return (
    <div aria-hidden className="absolute inset-0 grid place-items-center">
      {/* Slow orbiting conic bloom */}
      <div className="relative h-[78vmin] w-[78vmin] max-h-[720px] max-w-[720px]">
        <motion.div
          animate={reduced ? undefined : { rotate: 360 }}
          transition={{ duration: 46, repeat: Infinity, ease: "linear" }}
          className="absolute inset-0 rounded-full opacity-60 blur-[60px] [background:conic-gradient(from_0deg,transparent_0%,rgba(0,224,122,0.55)_22%,transparent_44%,rgba(124,58,237,0.5)_68%,transparent_88%,rgba(0,224,122,0.55)_100%)]"
        />
        <div className="absolute inset-[18%] rounded-full bg-[radial-gradient(circle_at_38%_32%,rgba(0,224,122,0.28),transparent_62%)] blur-2xl" />

        {/* Wireframe rings */}
        {[0, 1, 2].map((i) => (
          <motion.div
            key={i}
            animate={reduced ? undefined : { rotate: i % 2 === 0 ? 360 : -360 }}
            transition={{
              duration: 38 + i * 14,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute rounded-full border"
            style={{
              inset: `${18 + i * 9}%`,
              borderColor:
                i === 1 ? "rgba(167,139,250,0.22)" : "rgba(0,224,122,0.2)",
              transform: `rotateX(${62 + i * 8}deg)`,
            }}
          />
        ))}

        <div className="absolute inset-[34%] rounded-full border border-neon/25 shadow-[0_0_70px_-10px_rgba(0,224,122,0.55)]" />
      </div>
    </div>
  );
}
