"use client";

import { Component, type ErrorInfo, type ReactNode } from "react";

type Props = {
  children: ReactNode;
  fallback?: ReactNode;
};

type State = { hasError: boolean };

/**
 * Error boundary for the WebGL layer.
 *
 * React Three Fiber throws if a GL context cannot be created (blocklisted
 * drivers, disabled hardware acceleration, low-memory mobile browsers).
 * Without this boundary that throw unmounts the whole page — so we trap it
 * and render a CSS-only fallback instead.
 */
export default class SceneBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // Keep the console useful but non-fatal.
    console.warn("3D scene unavailable, using static fallback.", error, info);
  }

  render() {
    if (this.state.hasError) return this.props.fallback ?? null;
    return this.props.children;
  }
}
