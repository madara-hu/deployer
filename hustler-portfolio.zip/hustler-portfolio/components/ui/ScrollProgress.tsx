"use client";

import { motion, useScroll, useSpring } from "framer-motion";

/** Thin neon progress bar pinned to the very top of the viewport. */
export default function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 140,
    damping: 26,
    restDelta: 0.001,
  });

  return (
    <motion.div
      aria-hidden
      style={{ scaleX }}
      className="fixed left-0 right-0 top-0 z-[100] h-[2px] origin-left bg-gradient-to-r from-neon via-neon-soft to-violet-soft shadow-[0_0_18px_rgba(0,224,122,0.8)]"
    />
  );
}
