import type { SVGProps } from "react";

/**
 * Hand-drawn service glyphs.
 * Inline SVG (rather than an icon set) so they render identically
 * everywhere and can inherit stroke weight from the card.
 */
const base = {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.7,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};

export function CodeGlyph(props: SVGProps<SVGSVGElement>) {
  return (
    <svg {...base} {...props}>
      <path d="M8.5 8.5 5 12l3.5 3.5" />
      <path d="M15.5 8.5 19 12l-3.5 3.5" />
      <path d="M13.2 5.5 10.8 18.5" />
    </svg>
  );
}

export function PhoneGlyph(props: SVGProps<SVGSVGElement>) {
  return (
    <svg {...base} {...props}>
      <rect x="6.5" y="2.8" width="11" height="18.4" rx="3" />
      <path d="M10.4 5.4h3.2" />
      <path d="M10.8 17.9h2.4" />
    </svg>
  );
}

export function PenGlyph(props: SVGProps<SVGSVGElement>) {
  return (
    <svg {...base} {...props}>
      <path d="M4 20 5.2 15.6 16.1 4.7a2.1 2.1 0 0 1 3 3L8.2 18.6 4 20Z" />
      <path d="M14.6 6.2l3 3" />
    </svg>
  );
}

export function SparkGlyph(props: SVGProps<SVGSVGElement>) {
  return (
    <svg {...base} {...props}>
      <path d="M12 3.2l1.9 5.1 5.1 1.9-5.1 1.9L12 17.2l-1.9-5.1L5 10.2l5.1-1.9L12 3.2Z" />
      <path d="M18.4 15.6l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8.8-2Z" />
    </svg>
  );
}

export const SERVICE_GLYPHS = {
  code: CodeGlyph,
  smartphone: PhoneGlyph,
  pen: PenGlyph,
  sparkles: SparkGlyph,
} as const;
