"use client";

import { useEffect, useState } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

/**
 * Bespoke cursor: a precise neon dot plus a lagging ring.
 * Automatically disabled on touch devices and when the user
 * prefers reduced motion.
 */
export default function Cursor() {
  const [enabled, setEnabled] = useState(false);
  const [hovering, setHovering] = useState(false);
  const [label, setLabel] = useState<string | null>(null);
  const [clicking, setClicking] = useState(false);

  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const ringX = useSpring(x, { stiffness: 260, damping: 26, mass: 0.5 });
  const ringY = useSpring(y, { stiffness: 260, damping: 26, mass: 0.5 });

  useEffect(() => {
    const fine = window.matchMedia("(pointer: fine)").matches;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (!fine || reduced) return;

    setEnabled(true);
    document.documentElement.classList.add("cursor-none-root");

    const move = (event: PointerEvent) => {
      x.set(event.clientX);
      y.set(event.clientY);

      const target = (event.target as HTMLElement | null)?.closest<HTMLElement>(
        "[data-cursor]"
      );
      if (target) {
        setHovering(true);
        setLabel(target.dataset.cursor || null);
      } else {
        const clickable = (event.target as HTMLElement | null)?.closest(
          "a, button, input, textarea, [role='button']"
        );
        setHovering(Boolean(clickable));
        setLabel(null);
      }
    };

    const down = () => setClicking(true);
    const up = () => setClicking(false);

    window.addEventListener("pointermove", move, { passive: true });
    window.addEventListener("pointerdown", down);
    window.addEventListener("pointerup", up);

    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerdown", down);
      window.removeEventListener("pointerup", up);
      document.documentElement.classList.remove("cursor-none-root");
    };
  }, [x, y]);

  if (!enabled) return null;

  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-[9999] hidden md:block">
      {/* Precise dot */}
      <motion.div
        className="absolute h-1.5 w-1.5 rounded-full bg-neon"
        style={{ x, y, translateX: "-50%", translateY: "-50%" }}
        animate={{ scale: clicking ? 0.6 : 1 }}
        transition={{ duration: 0.15 }}
      />
      {/* Lagging ring */}
      <motion.div
        className="absolute flex items-center justify-center rounded-full border border-neon/60 mix-blend-difference"
        style={{ x: ringX, y: ringY, translateX: "-50%", translateY: "-50%" }}
        animate={{
          width: label ? 88 : hovering ? 56 : 34,
          height: label ? 88 : hovering ? 56 : 34,
          backgroundColor: hovering ? "rgba(0,224,122,0.12)" : "rgba(0,224,122,0)",
          borderColor: hovering ? "rgba(0,224,122,0.9)" : "rgba(0,224,122,0.4)",
          scale: clicking ? 0.85 : 1,
        }}
        transition={{ type: "spring", stiffness: 320, damping: 24, mass: 0.4 }}
      >
        {label && (
          <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-neon">
            {label}
          </span>
        )}
      </motion.div>
    </div>
  );
}
