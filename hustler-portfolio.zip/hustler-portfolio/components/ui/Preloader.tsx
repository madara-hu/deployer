"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { EASE } from "@/lib/animations";

const WORDS = ["Design", "Build", "Ship"];

/**
 * Brief intro curtain that counts up and slides away.
 * Purely presentational — never blocks interaction after it exits.
 */
export default function Preloader() {
  const [done, setDone] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setDone(true);
      return;
    }

    document.documentElement.classList.add("lenis-stopped");
    let value = 0;
    const interval = window.setInterval(() => {
      value = Math.min(100, value + Math.random() * 16 + 6);
      setProgress(Math.floor(value));
      if (value >= 100) {
        window.clearInterval(interval);
        window.setTimeout(() => setDone(true), 280);
      }
    }, 90);

    return () => {
      window.clearInterval(interval);
      document.documentElement.classList.remove("lenis-stopped");
    };
  }, []);

  useEffect(() => {
    if (!done) return;
    document.documentElement.classList.remove("lenis-stopped");
  }, [done]);

  return (
    <AnimatePresence>
      {!done && (
        <motion.div
          className="fixed inset-0 z-[9998] flex flex-col items-center justify-center bg-void"
          exit={{ y: "-100%" }}
          transition={{ duration: 1, ease: EASE }}
        >
          <div className="relative flex flex-col items-center">
            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, ease: EASE }}
              className="relative"
            >
              <span className="font-display text-4xl font-bold tracking-[-0.05em] text-white sm:text-6xl">
                Hustler
                <span className="text-neon">.</span>
              </span>
              <span className="absolute -inset-8 -z-10 rounded-full bg-neon/20 blur-3xl" />
            </motion.div>

            <div className="mt-8 h-[2px] w-52 overflow-hidden rounded-full bg-white/10 sm:w-64">
              <motion.div
                className="h-full bg-gradient-to-r from-neon to-neon-soft"
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.3, ease: "linear" }}
              />
            </div>

            <div className="mt-4 flex w-52 items-center justify-between text-[10px] uppercase tracking-[0.28em] text-white/40 sm:w-64">
              <AnimatePresence mode="wait">
                <motion.span
                  key={WORDS[Math.min(WORDS.length - 1, Math.floor(progress / 34))]}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  transition={{ duration: 0.25 }}
                >
                  {WORDS[Math.min(WORDS.length - 1, Math.floor(progress / 34))]}
                </motion.span>
              </AnimatePresence>
              <span className="tabular-nums text-neon/80">{progress}%</span>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
