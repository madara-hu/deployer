"use client";

import { motion } from "framer-motion";
import { EASE, viewportOnce } from "@/lib/animations";

/**
 * Section heading: eyebrow + massive two-tone display type.
 * `lead` renders in white, `accent` in the neon gradient.
 */
export default function SectionHeading({
  eyebrow,
  lead,
  accent,
  description,
  align = "left",
  className = "",
}: {
  eyebrow: string;
  lead: string;
  accent?: string;
  description?: string;
  align?: "left" | "center";
  className?: string;
}) {
  return (
    <div
      className={`flex flex-col gap-6 ${
        align === "center" ? "items-center text-center" : "items-start"
      } ${className}`}
    >
      <motion.span
        initial={{ opacity: 0, y: 14 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={viewportOnce}
        transition={{ duration: 0.7, ease: EASE }}
        className="eyebrow"
      >
        <span className="h-1.5 w-1.5 rounded-full bg-neon shadow-[0_0_10px_2px_rgba(0,224,122,0.8)]" />
        {eyebrow}
      </motion.span>

      <motion.h2
        initial={{ opacity: 0, y: 26, filter: "blur(8px)" }}
        whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
        viewport={viewportOnce}
        transition={{ duration: 0.95, ease: EASE, delay: 0.06 }}
        className="display text-balance text-[clamp(2.4rem,6.4vw,5.25rem)]"
      >
        <span className="text-gradient-ghost">{lead}</span>{" "}
        {accent && <span className="text-gradient-neon">{accent}</span>}
      </motion.h2>

      {description && (
        <motion.p
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={viewportOnce}
          transition={{ duration: 0.85, ease: EASE, delay: 0.14 }}
          className={`max-w-xl text-[15px] leading-relaxed text-white/50 sm:text-base ${
            align === "center" ? "mx-auto" : ""
          }`}
        >
          {description}
        </motion.p>
      )}
    </div>
  );
}
