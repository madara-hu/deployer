"use client";

import { useRef, type ReactNode } from "react";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";

/**
 * Magnetic wrapper: the child drifts toward the pointer while hovered.
 * Falls back to a plain element on touch / reduced motion.
 */
export default function MagneticButton({
  children,
  className = "",
  href,
  strength = 0.35,
  cursor,
  onClick,
  ariaLabel,
}: {
  children: ReactNode;
  className?: string;
  href?: string;
  strength?: number;
  cursor?: string;
  onClick?: () => void;
  ariaLabel?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const x = useSpring(mx, { stiffness: 220, damping: 18, mass: 0.4 });
  const y = useSpring(my, { stiffness: 220, damping: 18, mass: 0.4 });
  const innerX = useTransform(x, (v) => v * 0.4);
  const innerY = useTransform(y, (v) => v * 0.4);

  const handleMove = (event: React.PointerEvent) => {
    if (window.matchMedia("(pointer: coarse)").matches) return;
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    mx.set((event.clientX - (rect.left + rect.width / 2)) * strength);
    my.set((event.clientY - (rect.top + rect.height / 2)) * strength);
  };

  const reset = () => {
    mx.set(0);
    my.set(0);
  };

  return (
    <motion.div
      ref={ref}
      onPointerMove={handleMove}
      onPointerLeave={reset}
      style={{ x, y }}
      className="inline-flex will-change-transform"
    >
      {href ? (
        <a
          href={href}
          onClick={onClick}
          data-cursor={cursor}
          aria-label={ariaLabel}
          className={className}
        >
          <motion.span
            style={{ x: innerX, y: innerY }}
            className="inline-flex items-center gap-2"
          >
            {children}
          </motion.span>
        </a>
      ) : (
        <button
          type="button"
          onClick={onClick}
          data-cursor={cursor}
          aria-label={ariaLabel}
          className={className}
        >
          <motion.span
            style={{ x: innerX, y: innerY }}
            className="inline-flex items-center gap-2"
          >
            {children}
          </motion.span>
        </button>
      )}
    </motion.div>
  );
}
