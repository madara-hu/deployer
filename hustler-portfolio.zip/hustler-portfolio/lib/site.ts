export const site = {
  name: "Hustler",
  agency: "Hustler Agency",
  founder: "Navneet",
  role: "Designer · Developer · Founder",
  tagline: "We turn complex ideas into premium digital experiences.",
  email: "hello@hustler.agency",
  phone: "+91 98765 43210",
  location: "Patna, India — working worldwide",
  availability: "Available for Q1 2026 projects",
  url: "https://hustler.agency",
} as const;

export const navLinks = [
  { label: "Work", href: "#work" },
  { label: "Services", href: "#services" },
  { label: "About", href: "#about" },
  { label: "Process", href: "#process" },
  { label: "Contact", href: "#contact" },
] as const;

export const socials = [
  {
    label: "Instagram",
    handle: "@hustler.agency",
    href: "https://instagram.com",
    icon: "instagram",
  },
  {
    label: "GitHub",
    handle: "@navneet",
    href: "https://github.com",
    icon: "github",
  },
  {
    label: "LinkedIn",
    handle: "in/navneet",
    href: "https://linkedin.com",
    icon: "linkedin",
  },
] as const;

export const stats = [
  { value: 68, suffix: "+", label: "Projects shipped" },
  { value: 24, suffix: "", label: "Happy clients" },
  { value: 7, suffix: "yrs", label: "Design experience" },
  { value: 12, suffix: "", label: "Awards & features" },
] as const;

export const marqueeWords = [
  "Web Development",
  "App Development",
  "UI/UX Design",
  "Branding",
  "Motion",
  "Design Systems",
  "3D & WebGL",
  "Strategy",
] as const;
