export type Service = {
  id: string;
  index: string;
  title: string;
  description: string;
  tags: string[];
  accent: "neon" | "violet";
  icon: "code" | "smartphone" | "pen" | "sparkles";
};

export const services: Service[] = [
  {
    id: "web-development",
    index: "01",
    title: "Web Development",
    description:
      "Blazing-fast, accessible websites built on Next.js and TypeScript. Headless CMS, edge rendering, buttery scroll and 100/100 Lighthouse scores.",
    tags: ["Next.js", "TypeScript", "Headless CMS", "WebGL"],
    accent: "neon",
    icon: "code",
  },
  {
    id: "app-development",
    index: "02",
    title: "App Development",
    description:
      "Cross-platform products that feel native on every device. From MVP architecture to App Store launch, with analytics wired in from day one.",
    tags: ["React Native", "Expo", "Supabase", "CI/CD"],
    accent: "violet",
    icon: "smartphone",
  },
  {
    id: "ui-ux-design",
    index: "03",
    title: "UI/UX Design",
    description:
      "Research-driven interfaces and design systems that scale. Wireframes, prototypes and pixel-perfect handoff — no lorem ipsum shipped to production.",
    tags: ["Figma", "Design Systems", "Prototyping", "Accessibility"],
    accent: "neon",
    icon: "pen",
  },
  {
    id: "branding",
    index: "04",
    title: "Branding",
    description:
      "Identity systems with a point of view: naming, logotype, type pairing, motion guidelines and a brand book your team will actually use.",
    tags: ["Identity", "Art Direction", "Motion", "Guidelines"],
    accent: "violet",
    icon: "sparkles",
  },
];
