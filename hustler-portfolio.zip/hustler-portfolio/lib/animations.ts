import type { Variants } from "framer-motion";

/** Signature easing used across the whole site. */
export const EASE = [0.22, 1, 0.36, 1] as const;

/** Fade + rise, used for headings and cards. */
export const fadeUp: Variants = {
  hidden: { opacity: 0, y: 28, filter: "blur(6px)" },
  show: {
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
    transition: { duration: 0.9, ease: EASE },
  },
};

/** Simple fade. */
export const fade: Variants = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { duration: 1, ease: EASE } },
};

/** Stagger wrapper — pair with `fadeUp` children. */
export const stagger = (staggerChildren = 0.09, delayChildren = 0): Variants => ({
  hidden: {},
  show: { transition: { staggerChildren, delayChildren } },
});

/** Word-by-word headline reveal (clip mask). */
export const wordReveal: Variants = {
  hidden: { y: "110%" },
  show: {
    y: "0%",
    transition: { duration: 1.05, ease: EASE },
  },
};

/** Line-mask variant for hero copy. */
export const maskUp: Variants = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.8, ease: EASE } },
};

/** Shared viewport config so every section reveals the same way. */
export const viewportOnce = { once: true, margin: "-80px 0px -80px 0px" } as const;
