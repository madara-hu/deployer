export type Project = {
  id: string;
  title: string;
  client: string;
  category: "Web" | "App" | "Brand" | "UI/UX";
  year: string;
  summary: string;
  image: string;
  href: string;
  /** Layout weight — larger tiles get more grid space on desktop. */
  featured?: boolean;
  tags: string[];
};

export const projects: Project[] = [
  {
    id: "aether-fintech",
    title: "Aether Finance",
    client: "Aether",
    category: "Web",
    year: "2026",
    summary:
      "A trading dashboard for a neo-bank — 3D data viz, sub-second routing and a design system covering 140 components.",
    image:
      "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1600&q=80",
    href: "#work",
    featured: true,
    tags: ["Next.js", "WebGL", "Design System"],
  },
  {
    id: "orbit-travel",
    title: "Orbit Travel",
    client: "Orbit",
    category: "App",
    year: "2025",
    summary:
      "Flight-first travel companion with offline itineraries and a gesture-driven booking flow.",
    image:
      "https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&w=1200&q=80",
    href: "#work",
    tags: ["React Native", "Expo"],
  },
  {
    id: "monolith-studio",
    title: "Monolith Studio",
    client: "Monolith",
    category: "Brand",
    year: "2025",
    summary:
      "Full identity rebuild for an architecture practice — logotype, kinetic type and a print-ready system.",
    image:
      "https://images.unsplash.com/photo-1518005020951-eccb494ad742?auto=format&fit=crop&w=1200&q=80",
    href: "#work",
    tags: ["Identity", "Art Direction"],
  },
  {
    id: "pulse-health",
    title: "Pulse Health",
    client: "Pulse",
    category: "UI/UX",
    year: "2025",
    summary:
      "Patient onboarding reduced from 11 screens to 4, lifting completion by 38% in the first month.",
    image:
      "https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=1200&q=80",
    href: "#work",
    tags: ["Research", "Product Design"],
  },
  {
    id: "noir-commerce",
    title: "Noir Commerce",
    client: "Noir",
    category: "Web",
    year: "2024",
    summary:
      "Headless storefront for a luxury eyewear label — editorial layouts, 3D try-on, 1.9s LCP.",
    image:
      "https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?auto=format&fit=crop&w=1600&q=80",
    href: "#work",
    featured: true,
    tags: ["Shopify Hydrogen", "3D Try-on"],
  },
  {
    id: "tempo-audio",
    title: "Tempo Audio",
    client: "Tempo",
    category: "App",
    year: "2024",
    summary:
      "A collaborative mastering tool with real-time waveform sync across devices.",
    image:
      "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=1200&q=80",
    href: "#work",
    tags: ["Web Audio", "Realtime"],
  },
];
