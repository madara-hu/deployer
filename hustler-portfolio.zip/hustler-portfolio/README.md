# Hustler — Premium 3D Portfolio

An Awwwards-grade, fully animated portfolio site for **Hustler Agency**, founded by **Navneet**.
Built with Next.js 14 (App Router), TypeScript, Tailwind CSS, Framer Motion and React Three Fiber.

> Ultra-premium dark theme · neon-green (`#00E07A`) + electric-violet accents · glassmorphism · real WebGL hero · smooth scrolling · fully responsive.

---

## ⚡ Quick start

```bash
npm install
npm run dev
```

Open <http://localhost:3000>.

```bash
npm run build   # production build (type-checked + linted)
npm start       # serve the production build
```

Node **18.17+** required (Node 20 LTS recommended).

---

## 📁 Project structure

```
hustler-portfolio/
├── app/
│   ├── layout.tsx          # Root layout: fonts, metadata, providers, cursor, preloader
│   ├── page.tsx            # Section composition (the whole page)
│   ├── globals.css         # Design tokens, glass/btn utilities, Lenis + reduced-motion
│   ├── not-found.tsx       # Custom 404
│   ├── robots.ts           # SEO
│   └── sitemap.ts          # SEO
├── components/
│   ├── sections/
│   │   ├── Navbar.tsx          # Glass pill nav, scroll-aware, mobile drawer
│   │   ├── Hero.tsx            # Massive headline + 3D scene + scroll indicator
│   │   ├── Marquee.tsx         # Infinite service marquee band
│   │   ├── About.tsx           # "Hi, I'm Navneet" + glowing portrait frame + stats
│   │   ├── Services.tsx        # 4 service cards w/ 3D tilt + glow hover
│   │   ├── Projects.tsx        # Filterable portfolio grid, parallax + scale-on-hover
│   │   ├── Process.tsx         # 4-step process timeline
│   │   ├── Testimonials.tsx    # Client quotes
│   │   ├── Contact.tsx         # "Let's Talk" CTA + contact card
│   │   └── Footer.tsx          # Socials, nav, giant watermark wordmark
│   ├── three/
│   │   ├── HeroScene.tsx       # R3F canvas: torus knot, pointer rig, sparkles
│   │   ├── SceneBoundary.tsx   # Error boundary for the WebGL layer
│   │   └── StaticOrb.tsx       # CSS-only hero fallback (no WebGL / reduced motion)
│   ├── providers/
│   │   └── SmoothScroll.tsx    # Lenis smooth scroll + anchor interception
│   └── ui/
│       ├── Cursor.tsx          # Custom neon cursor with contextual labels
│       ├── MagneticButton.tsx  # Magnetic hover wrapper
│       ├── TiltCard.tsx        # 3D pointer-tilt card + glare
│       ├── Counter.tsx         # Scroll-triggered animated counters
│       ├── SectionHeading.tsx  # Shared eyebrow + display heading
│       ├── ScrollProgress.tsx  # Top neon progress bar
│       ├── Preloader.tsx       # Intro curtain with % counter
│       └── ServiceGlyph.tsx    # Custom inline SVG service icons
├── lib/
│   ├── site.ts             # Site name, email, nav links, socials, stats
│   ├── services.ts         # Service card content  ← edit me
│   ├── projects.ts         # Portfolio items + images ← edit me
│   ├── animations.ts       # Shared Framer Motion variants + easing
│   └── webgl.ts            # WebGL capability detection
├── tailwind.config.ts      # Colours, fonts, keyframes, shadows
├── next.config.mjs         # Unsplash remote patterns
├── tsconfig.json
├── postcss.config.mjs
├── package.json
└── .eslintrc.json
```

---

## 🎨 Design system

| Token | Value | Used for |
| --- | --- | --- |
| `void` / `#050505` | near-black | page background |
| `ink-900 … ink-600` | `#0A0A0B` → `#26262B` | cards, surfaces |
| `neon` / `#00E07A` | neon green | primary accent, CTAs, glows |
| `neon-soft` / `#5CFFB1` | mint | gradient highlights |
| `violet-neon` / `#7C3AED` | electric violet | secondary accent |
| `--font-space` | Space Grotesk | display / headings |
| `--font-inter` | Inter | body / UI |

Reusable classes in `globals.css`: `.glass`, `.glass-deep`, `.btn-neon`, `.btn-ghost`,
`.eyebrow`, `.display`, `.text-gradient-neon`, `.text-gradient-ghost`, `.dot-grid`,
`.link-line`, `.mask-fade-x`, `.grain`.

---

## ✨ What's animated

- **Hero** — word-by-word masked headline reveal, 3D torus-knot core that tracks the mouse, parallax on scroll, animated scroll indicator.
- **Navbar** — fades in, morphs into a glass pill after 40px, full-screen mobile drawer with staggered links.
- **Cursor** — precise dot + lagging spring ring; grows and shows a label on `data-cursor` elements (desktop only).
- **Preloader** — counter to 100%, then the curtain slides up and Lenis unlocks.
- **Services** — pointer-driven 3D tilt, neon bloom on hover, tags and arrow respond.
- **Projects** — `layout` + `AnimatePresence` filter pills, staggered reveals, scroll parallax inside each frame, image scale + saturation on hover.
- **About** — rotating conic glow frame, parallax portrait, counters that ease-out on view.
- **Contact / Footer** — slot-availability bar animates in, magnetic CTAs, cropped watermark wordmark.

---

## 🧠 Engineering notes

- **No build errors, by construction.** `npm run build` passes with strict TypeScript *and* Next lint. (Verified on Next 14.2.35, React 18.3.)
- **WebGL is fail-safe.** `lib/webgl.ts` detects support before mounting `<Canvas>`; `SceneBoundary` catches any GL throw. If 3D is unavailable (old GPU, disabled hardware acceleration, locked-down in-app browsers) the hero gracefully swaps to `StaticOrb` — a CSS-only premium backdrop. Without this, React Three Fiber's throw would blank the whole page.
- **3D is deferred.** The canvas mounts after a short idle timeout and only in client components, so first paint and LCP aren't blocked. `dpr` is capped at 1.9 (1.3 on weak devices).
- **Motion is accessible.** Every animation honours `prefers-reduced-motion` — the 3D scene doesn't mount, Lenis doesn't initialise, the preloader is skipped, cursor effects are disabled, and CSS transitions are neutralised.
- **Touch-aware.** Tilt, magnetic hover and the custom cursor all no-op on coarse pointers.
- **Images** are plain `<img>` with Unsplash URLs, so the project runs with zero image-config friction. Swap in `next/image` when you add local assets (the `remotePatterns` for `images.unsplash.com` are already configured in `next.config.mjs`).
- **Scroll** is handled by Lenis, exposed as `window.__lenis`, with in-page anchor clicks intercepted for buttery section jumps.

---

## 🔧 Make it yours

| What | Where |
| --- | --- |
| Name, email, phone, location, availability | `lib/site.ts` |
| Nav links & socials | `lib/site.ts` |
| Services (copy, tags, pricing) | `lib/services.ts` |
| Portfolio projects (title, image, tags) | `lib/projects.ts` |
| Hero headline & sub-copy | `components/sections/Hero.tsx` |
| Bio + pull quote | `components/sections/About.tsx` |
| Process steps | `components/sections/Process.tsx` |
| Testimonials | `components/sections/Testimonials.tsx` |
| Accent colours | `tailwind.config.ts` → `colors.neon` / `colors.violet` |
| Portrait & project images | Unsplash URLs in `About.tsx` / `lib/projects.ts` |

**Swap the portrait:** replace the `img src` in `components/sections/About.tsx` with your own photo
(put it in `public/` and reference `/navneet.jpg`).

---

## 🚀 Deploy

**Vercel** (recommended): push the repo, import it, deploy — zero config.

```bash
npm i -g vercel && vercel
```

Any Node host works too: `npm run build && npm start`.

---

## 📄 License

Free to use and modify for the Hustler Agency. Replace the dummy portrait, project imagery
and testimonial names with real ones before going live.
