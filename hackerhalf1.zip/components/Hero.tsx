'use client';

import { useEffect, useRef } from 'react';
import Image from 'next/image';
import gsap from 'gsap';
import { motion } from 'framer-motion';
import MagneticButton from '@/components/MagneticButton';
import { useTypewriter } from '@/lib/hooks';
import { site } from '@/lib/site';

const LETTERS = site.name.split('');

export default function Hero() {
  const rootRef = useRef<HTMLElement>(null);
  const lettersRef = useRef<HTMLDivElement>(null);
  const typed = useTypewriter(site.roles, 72, 34, 1200);

  useEffect(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce || !rootRef.current) return;

    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power4.out' } });

      tl.from('[data-hero-eyebrow]', { y: 24, autoAlpha: 0, duration: 0.7 }, 0.1)
        .from(
          lettersRef.current ? (Array.from(lettersRef.current.children) as HTMLElement[]) : [],
          { yPercent: 118, rotateX: -78, autoAlpha: 0, duration: 1.05, stagger: 0.055 },
          0.18,
        )
        .from('[data-hero-type]', { y: 18, autoAlpha: 0, duration: 0.6 }, 0.8)
        .from('[data-hero-copy]', { y: 20, autoAlpha: 0, duration: 0.7 }, 0.95)
        .from('[data-hero-cta]', { y: 18, autoAlpha: 0, duration: 0.6, stagger: 0.09 }, 1.05)
        .from('[data-hero-meta]', { y: 14, autoAlpha: 0, duration: 0.5, stagger: 0.07 }, 1.15)
        .from('[data-hero-frame]', { scale: 0.9, autoAlpha: 0, duration: 1.15, ease: 'expo.out' }, 0.35)
        .from('[data-hero-scan]', { scaleY: 0, duration: 0.9, ease: 'power3.inOut' }, 0.9);

      // continuous frame float
      gsap.to('[data-hero-frame]', {
        y: -10,
        duration: 3.4,
        ease: 'sine.inOut',
        yoyo: true,
        repeat: -1,
      });

      // parallax on scroll (feeds from Lenis scroll)
      gsap.to('[data-hero-shot]', {
        yPercent: 12,
        ease: 'none',
        scrollTrigger: {
          trigger: rootRef.current,
          start: 'top top',
          end: 'bottom top',
          scrub: true,
        },
      });
    }, rootRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="hero"
      ref={rootRef}
      className="relative z-10 flex min-h-[100svh] items-center overflow-hidden pt-24 pb-16 sm:pt-28"
    >
      <div aria-hidden className="grid-bg absolute inset-0 z-0 opacity-70" />
      <div
        aria-hidden
        className="absolute left-1/2 top-0 z-0 h-[420px] w-[880px] -translate-x-1/2 rounded-full bg-matrix/10 blur-[140px]"
      />

      <div className="relative z-10 mx-auto grid w-full max-w-7xl grid-cols-1 items-center gap-12 px-5 sm:px-8 lg:grid-cols-[1.15fr_0.85fr] lg:gap-8">
        {/* ---------- text column ---------- */}
        <div className="order-1">
          <div
            data-hero-eyebrow
            className="mb-5 inline-flex items-center gap-2.5 border border-matrix/25 bg-matrix/[0.04] px-3 py-1.5"
          >
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-matrix" />
            <span className="font-mono text-[9px] font-bold uppercase tracking-[0.34em] text-matrix/90">
              root@hustler:~$ session active
            </span>
          </div>

          <div className="overflow-hidden">
            <div
              ref={lettersRef}
              className="glitch flex flex-wrap font-mono text-[19vw] font-black leading-[0.82] tracking-[-0.03em] sm:text-[15vw] lg:text-[9.6rem]"
              data-text={site.name}
            >
              {LETTERS.map((char, i) => (
                <span key={`${char}-${i}`} className="inline-block will-change-transform">
                  {char}
                </span>
              ))}
            </div>
          </div>

          <div
            data-hero-type
            className="mt-5 flex min-h-[30px] items-center gap-2 font-mono text-[13px] text-cyan sm:text-[15px]"
          >
            <span className="text-matrix">&gt;</span>
            <span>{typed}</span>
            <span className="inline-block h-[15px] w-[8px] animate-blink bg-matrix" />
          </div>

          <p
            data-hero-copy
            className="mt-6 max-w-xl text-[15px] leading-relaxed text-white/60 sm:text-base"
          >
            Navneet Singh — building fast, brutal, beautiful interfaces from a phone. Termux, Codespaces,
            Next.js, Three.js. I ship static, I ship clean, I ship zero build errors.
          </p>

          <div className="mt-9 flex flex-wrap items-center gap-3.5">
            <div data-hero-cta>
              <MagneticButton scrollTo="#terminal">
                enter terminal
                <span className="text-[13px] leading-none">→</span>
              </MagneticButton>
            </div>
            <div data-hero-cta>
              <MagneticButton variant="ghost" scrollTo="#about">
                who is hustler
              </MagneticButton>
            </div>
          </div>

          <div className="mt-11 grid max-w-lg grid-cols-3 gap-4 border-t border-white/[0.07] pt-6">
            {[
              { k: 'STACK', v: 'Next.js 14' },
              { k: 'DEPLOY', v: 'Cloudflare' },
              { k: 'BASED', v: 'Bihar, IN' },
            ].map((m) => (
              <div key={m.k} data-hero-meta>
                <div className="font-mono text-[8.5px] uppercase tracking-[0.3em] text-white/35">
                  {m.k}
                </div>
                <div className="mt-1.5 font-mono text-[11px] font-semibold uppercase tracking-[0.12em] text-matrix/90">
                  {m.v}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ---------- photo column ---------- */}
        <div className="order-2 flex justify-center lg:justify-end">
          <div data-hero-frame className="relative w-[64%] max-w-[260px] sm:w-[52%] sm:max-w-[300px] lg:w-full lg:max-w-[340px]">
            <div
              aria-hidden
              className="absolute -inset-3 border border-matrix/15"
              style={{ clipPath: 'polygon(0 0, 26% 0, 26% 1px, 74% 1px, 74% 0, 100% 0, 100% 100%, 74% 100%, 74% calc(100% - 1px), 26% calc(100% - 1px), 26% 100%, 0 100%)' }}
            />
            <div className="hud-corners hud-corners-2 relative border border-matrix/30 bg-panel p-2 shadow-[0_0_60px_rgba(0,255,156,0.12)]">
              <span aria-hidden className="pointer-events-none absolute -inset-2 border border-cyan/20" />
              <div data-hero-shot className="relative overflow-hidden bg-black">
                <Image
                  src="/photo.png"
                  alt="Navneet Singh — HUSTLER"
                  width={842}
                  height={1264}
                  priority
                  sizes="(max-width: 1024px) 60vw, 330px"
                  className="h-auto w-full object-cover"
                />
                {/* HUD overlays inside frame */}
                <div
                  aria-hidden
                  className="pointer-events-none absolute inset-0 bg-[linear-gradient(to_right,rgba(0,255,156,0.13)_1px,transparent_1px),linear-gradient(to_bottom,rgba(0,255,156,0.13)_1px,transparent_1px)] bg-[size:34px_34px] opacity-35 mix-blend-screen"
                />
                <div
                  aria-hidden
                  className="pointer-events-none absolute inset-x-0 h-24 animate-scan bg-gradient-to-b from-transparent via-matrix/25 to-transparent"
                />
                <div
                  aria-hidden
                  className="pointer-events-none absolute inset-0 shadow-[inset_0_0_70px_rgba(0,0,0,0.9)]"
                />
                <div className="pointer-events-none absolute left-2 top-2 flex items-center gap-1.5 bg-black/60 px-1.5 py-1 backdrop-blur-sm">
                  <span className="h-1 w-1 animate-pulse rounded-full bg-red-500" />
                  <span className="font-mono text-[7px] font-bold uppercase tracking-[0.22em] text-white/85">
                    rec · id:ns-88077
                  </span>
                </div>
                <div className="pointer-events-none absolute bottom-2 right-2 bg-black/60 px-1.5 py-1 backdrop-blur-sm">
                  <span className="font-mono text-[7px] font-bold uppercase tracking-[0.22em] text-matrix">
                    25.1988n 85.5238e
                  </span>
                </div>
                <div
                  aria-hidden
                  data-hero-scan
                  className="pointer-events-none absolute inset-y-0 left-1/2 w-px origin-top bg-gradient-to-b from-transparent via-cyan/70 to-transparent"
                />
              </div>
              <div className="mt-2 flex items-center justify-between border-t border-white/[0.07] pt-2">
                <span className="font-mono text-[7.5px] uppercase tracking-[0.24em] text-white/40">
                  target acquired
                </span>
                <span className="font-mono text-[7.5px] uppercase tracking-[0.24em] text-matrix">
                  online
                </span>
              </div>
            </div>

            <motion.div
              initial={{ opacity: 0, x: 14 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 1.5, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              className="absolute -right-2 top-1/3 hidden border border-cyan/30 bg-black/80 px-2 py-1.5 backdrop-blur-sm sm:block"
            >
              <span className="font-mono text-[7px] uppercase tracking-[0.22em] text-cyan">
                sys.monitor
              </span>
            </motion.div>
          </div>
        </div>
      </div>

      <div className="pointer-events-none absolute bottom-6 left-1/2 z-10 -translate-x-1/2">
        <motion.div
          animate={{ y: [0, 9, 0] }}
          transition={{ duration: 2.1, repeat: Infinity, ease: 'easeInOut' }}
          className="flex flex-col items-center gap-1.5"
        >
          <span className="font-mono text-[8px] uppercase tracking-[0.4em] text-white/35">scroll</span>
          <span className="h-8 w-px bg-gradient-to-b from-matrix/80 to-transparent" />
        </motion.div>
      </div>
    </section>
  );
}
