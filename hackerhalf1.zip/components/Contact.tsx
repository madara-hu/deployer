'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import Reveal from '@/components/Reveal';
import MagneticButton from '@/components/MagneticButton';
import { copyText } from '@/lib/utils';
import { site } from '@/lib/site';

export default function Contact() {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    const ok = await copyText(site.email);
    if (ok) {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <section id="contact" className="relative z-10 border-t border-white/[0.06] py-24 sm:py-32">
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-1/3 h-[320px] w-[720px] -translate-x-1/2 rounded-full bg-matrix/[0.07] blur-[130px]"
      />

      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <Reveal className="mb-12" stagger>
          <div className="font-mono text-[9px] uppercase tracking-[0.4em] text-matrix/70">
            03 / connect
          </div>
          <h2 className="mt-3 font-mono text-4xl font-black uppercase leading-[0.95] tracking-[-0.02em] text-white sm:text-6xl lg:text-7xl">
            let us build
            <br />
            something<span className="text-matrix">.</span>
          </h2>
        </Reveal>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <Reveal className="lg:col-span-2">
            <div className="group relative h-full border border-matrix/25 bg-panel/70 p-6 backdrop-blur-sm transition-colors hover:border-matrix/50 sm:p-8">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[9px] uppercase tracking-[0.3em] text-white/35">
                  primary channel
                </span>
                <span className="font-mono text-[9px] uppercase tracking-[0.3em] text-matrix">
                  mail
                </span>
              </div>

              <a
                href={`mailto:${site.email}`}
                className="mt-6 block break-all font-mono text-lg font-bold tracking-tight text-white transition-colors hover:text-matrix sm:text-2xl lg:text-3xl"
              >
                {site.email}
              </a>

              <div className="mt-7 flex flex-wrap items-center gap-3">
                <MagneticButton href={`mailto:${site.email}`} onClick={() => undefined}>
                  send transmission
                </MagneticButton>
                <motion.button
                  type="button"
                  onClick={handleCopy}
                  whileTap={{ scale: 0.96 }}
                  className="border border-white/15 px-5 py-3 font-mono text-[10px] font-bold uppercase tracking-[0.26em] text-white/60 transition-colors hover:border-matrix/60 hover:text-matrix"
                >
                  {copied ? 'copied ✓' : 'copy address'}
                </motion.button>
              </div>
            </div>
          </Reveal>

          <Reveal>
            <a
              href={`https://wa.me/${site.whatsappIntl}`}
              target="_blank"
              rel="noopener noreferrer"
              data-cursor="CHAT"
              className="group flex h-full flex-col justify-between border border-matrix/25 bg-matrix/[0.04] p-6 transition-colors hover:border-matrix/60 hover:bg-matrix/[0.08] sm:p-8"
            >
              <div className="flex items-center justify-between">
                <span className="font-mono text-[9px] uppercase tracking-[0.3em] text-white/35">
                  direct line
                </span>
                <span className="font-mono text-[9px] uppercase tracking-[0.3em] text-matrix">
                  whatsapp
                </span>
              </div>
              <div className="mt-10">
                <div className="font-mono text-xl font-bold tracking-tight text-white sm:text-2xl">
                  +91 {site.whatsapp}
                </div>
                <div className="mt-3 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.24em] text-matrix/80">
                  open chat
                  <span className="transition-transform duration-300 group-hover:translate-x-1">→</span>
                </div>
              </div>
            </a>
          </Reveal>
        </div>

        <Reveal className="mt-16 border-t border-white/[0.06] pt-8" stagger>
          <div className="flex flex-col items-start justify-between gap-5 sm:flex-row sm:items-center">
            <div>
              <div className="font-mono text-[13px] font-bold uppercase tracking-[0.24em] text-white">
                hustler<span className="text-matrix">//</span>navneet singh
              </div>
              <p className="mt-2 font-mono text-[10px] uppercase tracking-[0.22em] text-white/25">
                {site.location} · built in termux · deployed on cloudflare
              </p>
            </div>
            <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-white/20">
              © {new Date().getFullYear()} — all lines of code reserved
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
