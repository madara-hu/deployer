'use client';

import { motion } from 'framer-motion';
import { site } from '@/lib/site';

export default function StackMarquee() {
  const items = [...site.stack, ...site.stack];

  return (
    <div className="relative z-10 overflow-hidden border-y border-white/[0.06] bg-black/40 py-4">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-black to-transparent"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-black to-transparent"
      />
      <motion.div
        className="flex w-max items-center gap-10 whitespace-nowrap"
        animate={{ x: ['0%', '-50%'] }}
        transition={{ duration: 28, repeat: Infinity, ease: 'linear' }}
      >
        {items.map((item, i) => (
          <span
            key={`${item}-${i}`}
            className="flex items-center gap-3 font-mono text-[11px] font-semibold uppercase tracking-[0.3em] text-white/40"
          >
            <span className="h-1 w-1 rotate-45 bg-matrix/80" />
            {item}
          </span>
        ))}
      </motion.div>
    </div>
  );
}
