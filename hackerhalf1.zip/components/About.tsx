'use client';

import Reveal from '@/components/Reveal';
import MagneticButton from '@/components/MagneticButton';
import { site } from '@/lib/site';

const dossier = [
  { k: 'alias', v: 'hustler' },
  { k: 'shell', v: '/bin/termux' },
  { k: 'editor', v: 'nvim · no mouse' },
  { k: 'deploys', v: 'cloudflare pages' },
  { k: 'status', v: 'building, always' },
];

export default function About() {
  return (
    <section id="about" className="relative z-10 border-t border-white/[0.06] py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <Reveal className="mb-14 flex items-end justify-between gap-6" stagger>
          <div>
            <div className="font-mono text-[9px] uppercase tracking-[0.4em] text-matrix/70">
              01 / dossier
            </div>
            <h2 className="mt-3 font-mono text-4xl font-black uppercase tracking-[-0.02em] text-white sm:text-5xl lg:text-6xl">
              about<span className="text-matrix">_</span>me
            </h2>
          </div>
          <div className="hidden text-right font-mono text-[9px] uppercase leading-relaxed tracking-[0.26em] text-white/25 sm:block">
            file: ns-88077.dossier
            <br />
            clearance: none
          </div>
        </Reveal>

        <div className="grid grid-cols-1 gap-10 lg:grid-cols-[1.25fr_0.75fr] lg:gap-14">
          <Reveal className="space-y-7" stagger>
            <p className="font-mono text-xl font-semibold tracking-tight text-white sm:text-2xl">
              <span className="text-matrix">&gt;</span> I am Navneet Singh.
            </p>

            <p className="max-w-2xl text-[15px] leading-[1.85] text-white/65 sm:text-base">
              {site.bio}
            </p>

            <div className="relative border-l-2 border-matrix/40 bg-matrix/[0.03] px-5 py-4">
              <p className="font-mono text-[12.5px] leading-relaxed text-matrix/90 sm:text-[13.5px]">
                {site.schooling}
              </p>
            </div>

            <p className="max-w-2xl text-[15px] leading-[1.85] text-white/55 sm:text-base">
              I work out of Termux on Android and GitHub Codespaces in the browser. No PC, no excuses.
              Every interface I ship is statically exported, edge-served, and tested until the build log
              is silent.
            </p>

            <div className="flex flex-wrap gap-3 pt-2">
              <MagneticButton variant="ghost" scrollTo="#terminal">
                open terminal
              </MagneticButton>
              <MagneticButton href={`mailto:${site.email}`} variant="ghost">
                mail me
              </MagneticButton>
            </div>
          </Reveal>

          <Reveal className="relative">
            <div className="hud-corners relative border border-matrix/20 bg-panel/80 p-5 backdrop-blur-sm">
              <div className="mb-4 flex items-center justify-between border-b border-white/[0.07] pb-3">
                <span className="font-mono text-[9px] uppercase tracking-[0.3em] text-matrix">
                  dossier.dat
                </span>
                <span className="flex gap-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-matrix/70" />
                  <span className="h-1.5 w-1.5 rounded-full bg-cyan/70" />
                  <span className="h-1.5 w-1.5 rounded-full bg-white/20" />
                </span>
              </div>

              <dl className="space-y-3">
                {dossier.map((row) => (
                  <div key={row.k} className="flex items-baseline justify-between gap-4">
                    <dt className="font-mono text-[9.5px] uppercase tracking-[0.22em] text-white/35">
                      {row.k}
                    </dt>
                    <dd className="font-mono text-[11px] font-semibold uppercase tracking-[0.1em] text-white/80">
                      {row.v}
                    </dd>
                  </div>
                ))}
              </dl>

              <div className="mt-5 border-t border-white/[0.07] pt-4">
                <div className="mb-2 flex items-center justify-between font-mono text-[9px] uppercase tracking-[0.22em] text-white/30">
                  <span>integrity</span>
                  <span className="text-matrix">100%</span>
                </div>
                <div className="h-1 w-full overflow-hidden bg-white/10">
                  <div className="h-full w-full bg-gradient-to-r from-matrix via-cyan to-matrix" />
                </div>
              </div>

              <p className="mt-5 font-mono text-[10px] leading-relaxed text-white/25">
                {'// redacted lines are intentional. ask better questions.'}
              </p>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
