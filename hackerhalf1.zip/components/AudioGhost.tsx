'use client';

import { useEffect } from 'react';

/**
 * Ghost audio engine.
 * - No <audio> element rendered in the UI, no controls, no mute button, no indicator.
 * - Always loop, never stops.
 * - Browsers block unmuted autoplay until a gesture, so:
 *     1) try to play immediately (works when the browser allows it),
 *     2) silently arm one-shot gesture listeners + retry on visibility change,
 *        so playback starts the instant the visitor touches / scrolls / taps a key.
 */
export default function AudioGhost() {
  useEffect(() => {
    const audio = new Audio('/solo.mp3');
    audio.loop = true;
    audio.volume = 0.45;
    audio.preload = 'auto';
    audio.setAttribute('playsinline', 'true');

    let dead = false;

    const tryPlay = () => {
      if (dead) return;
      const p = audio.play();
      if (p && typeof p.catch === 'function') {
        p.catch(() => {
          /* blocked -> keep silent, wait for a gesture */
        });
      }
    };

    tryPlay();

    const events: Array<keyof WindowEventMap> = [
      'pointerdown',
      'touchstart',
      'keydown',
      'scroll',
      'click',
      'wheel',
    ];

    const onGesture = () => {
      tryPlay();
      if (!audio.paused) disarm();
    };

    const onVisible = () => {
      if (document.visibilityState === 'visible' && audio.paused) tryPlay();
    };

    const disarm = () => {
      events.forEach((ev) => window.removeEventListener(ev, onGesture));
      document.removeEventListener('visibilitychange', onVisible);
    };

    events.forEach((ev) =>
      window.addEventListener(ev, onGesture, { passive: true } as AddEventListenerOptions),
    );
    document.addEventListener('visibilitychange', onVisible);

    // keep-alive: some mobile browsers pause on route/lock -> resume silently
    const keepAlive = window.setInterval(() => {
      if (audio.paused && !dead) tryPlay();
    }, 2500);

    return () => {
      dead = true;
      window.clearInterval(keepAlive);
      disarm();
      audio.pause();
      audio.src = '';
    };
  }, []);

  return null;
}
