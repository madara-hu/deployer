'use client';

import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';

export default function CustomCursor() {
  const dotRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLSpanElement>(null);
  const [enabled, setEnabled] = useState(false);

  useEffect(() => {
    const fine = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!fine || reduce) return;

    setEnabled(true);
    document.body.classList.add('custom-cursor');

    const dot = dotRef.current;
    const ring = ringRef.current;
    const label = labelRef.current;
    if (!dot || !ring || !label) return;

    const dotX = gsap.quickTo(dot, 'x', { duration: 0.08, ease: 'power2.out' });
    const dotY = gsap.quickTo(dot, 'y', { duration: 0.08, ease: 'power2.out' });
    const ringX = gsap.quickTo(ring, 'x', { duration: 0.45, ease: 'power3.out' });
    const ringY = gsap.quickTo(ring, 'y', { duration: 0.45, ease: 'power3.out' });

    let visible = false;

    const onMove = (e: PointerEvent) => {
      if (!visible) {
        visible = true;
        gsap.to([dot, ring], { autoAlpha: 1, duration: 0.3 });
      }
      dotX(e.clientX);
      dotY(e.clientY);
      ringX(e.clientX);
      ringY(e.clientY);
    };

    const onDown = () => {
      gsap.to(ring, { scale: 0.8, duration: 0.18, ease: 'power2.out' });
    };
    const onUp = () => {
      gsap.to(ring, { scale: 1, duration: 0.25, ease: 'power2.out' });
    };

    const interactiveSelector = 'a, button, input, textarea, [data-cursor]';

    const onOver = (e: PointerEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target) return;
      const hit = target.closest(interactiveSelector) as HTMLElement | null;
      if (hit) {
        const text = hit.getAttribute('data-cursor') ?? '';
        label.textContent = text;
        gsap.to(ring, {
          scale: text ? 2.5 : 1.9,
          borderColor: 'rgba(34,230,255,0.95)',
          backgroundColor: 'rgba(34,230,255,0.10)',
          duration: 0.3,
          ease: 'power3.out',
        });
        gsap.to(label, { autoAlpha: text ? 1 : 0, duration: 0.25 });
        gsap.to(dot, { scale: 0, duration: 0.25 });
      }
    };

    const onOut = (e: PointerEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target) return;
      const hit = target.closest(interactiveSelector) as HTMLElement | null;
      if (hit) {
        label.textContent = '';
        gsap.to(ring, {
          scale: 1,
          borderColor: 'rgba(0,255,156,0.9)',
          backgroundColor: 'rgba(0,255,156,0)',
          duration: 0.3,
          ease: 'power3.out',
        });
        gsap.to(label, { autoAlpha: 0, duration: 0.2 });
        gsap.to(dot, { scale: 1, duration: 0.25 });
      }
    };

    window.addEventListener('pointermove', onMove, { passive: true });
    window.addEventListener('pointerdown', onDown);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointerover', onOver);
    window.addEventListener('pointerout', onOut);

    return () => {
      document.body.classList.remove('custom-cursor');
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerdown', onDown);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('pointerover', onOver);
      window.removeEventListener('pointerout', onOut);
    };
  }, []);

  if (!enabled) return null;

  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-[70] hidden md:block">
      <div
        ref={ringRef}
        className="absolute left-0 top-0 flex h-10 w-10 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-matrix/90 opacity-0 mix-blend-screen"
        style={{ boxShadow: '0 0 18px rgba(0,255,156,0.35), inset 0 0 12px rgba(0,255,156,0.12)' }}
      >
        <span
          ref={labelRef}
          className="select-none font-mono text-[4px] font-bold uppercase tracking-[0.2em] text-cyan opacity-0"
        />
      </div>
      <div
        ref={dotRef}
        className="absolute left-0 top-0 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-matrix opacity-0"
        style={{ boxShadow: '0 0 12px rgba(0,255,156,0.9)' }}
      />
    </div>
  );
}
