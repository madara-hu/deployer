'use client';

import dynamic from 'next/dynamic';
import { useEffect, useState } from 'react';

const Scene3D = dynamic(() => import('@/components/Scene3D'), { ssr: false });

export default function SceneBackground() {
  const [mount, setMount] = useState(false);

  useEffect(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) return;
    // defer WebGL boot until after first paint -> zero blocking, no CLS
    const id = window.setTimeout(() => setMount(true), 260);
    return () => window.clearTimeout(id);
  }, []);

  if (!mount) return null;

  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-0 z-0 opacity-60"
      style={{ contain: 'strict' }}
    >
      <Scene3D />
    </div>
  );
}
