'use client';

import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

type RevealProps = {
  children: React.ReactNode;
  className?: string;
  stagger?: boolean;
  delay?: number;
  y?: number;
  as?: 'div' | 'section' | 'ul';
};

export default function Reveal({
  children,
  className = '',
  stagger = false,
  delay = 0,
  y = 44,
  as = 'div',
}: RevealProps) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) return;

    gsap.registerPlugin(ScrollTrigger);

    const ctx = gsap.context(() => {
      const targets: Element[] = stagger ? (Array.from(el.children) as Element[]) : [el];
      gsap.from(targets, {
        y,
        autoAlpha: 0,
        duration: 0.9,
        ease: 'power3.out',
        delay,
        stagger: stagger ? 0.09 : 0,
        scrollTrigger: {
          trigger: el,
          start: 'top 88%',
          once: true,
        },
      });
    }, el);

    return () => ctx.revert();
  }, [stagger, delay, y]);

  const Tag = as as 'div';

  return (
    <Tag ref={ref} className={className}>
      {children}
    </Tag>
  );
}
