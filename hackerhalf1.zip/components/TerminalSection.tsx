'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import Reveal from '@/components/Reveal';
import { useInViewOnce } from '@/lib/hooks';
import { scrollToSection } from '@/lib/utils';
import { site } from '@/lib/site';

type Kind = 'in' | 'out' | 'ok' | 'err' | 'dim';

type Line = { id: number; kind: Kind; text: string };

const boot: Array<{ kind: Kind; text: string }> = [
  { kind: 'dim', text: 'hustler-shell v2.4.0 (static build, cloudflare edge)' },
  { kind: 'dim', text: 'loading kernel modules .......... ok' },
  { kind: 'dim', text: 'mounting /dev/ambition .......... ok' },
  { kind: 'ok', text: 'session established. type "help" to list commands.' },
];

const helpText = [
  'available commands:',
  '  help        -> list every command',
  '  about       -> who is behind this shell',
  '  whoami      -> identity check',
  '  skills      -> loaded stack modules',
  '  schooling   -> origin log',
  '  contact     -> email + whatsapp',
  '  email       -> copy target address',
  '  whatsapp    -> open a direct line',
  '  projects    -> what is in the pipeline',
  '  music       -> reply from the ghost audio',
  '  matrix      -> enter the rain',
  '  sudo        -> try it, i dare you',
  '  clear       -> wipe the buffer',
  '  exit        -> there is no exit',
];

export default function TerminalSection() {
  const [lines, setLines] = useState<Line[]>([]);
  const [value, setValue] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const bodyRef = useRef<HTMLDivElement>(null);
  const idRef = useRef(0);
  const bootedRef = useRef(false);
  const { ref: sectionRef, seen } = useInViewOnce<HTMLDivElement>(0.2);

  const push = useCallback((kind: Kind, text: string) => {
    idRef.current += 1;
    const id = idRef.current;
    setLines((prev) => [...prev, { id, kind, text }]);
  }, []);

  const pushBlock = useCallback(
    (kind: Kind, rows: string[]) => {
      rows.forEach((row) => push(kind, row));
    },
    [push],
  );

  useEffect(() => {
    if (!seen || bootedRef.current) return;
    bootedRef.current = true;
    boot.forEach((row, i) => {
      window.setTimeout(() => push(row.kind, row.text), i * 260);
    });
  }, [seen, push]);

  useEffect(() => {
    const el = bodyRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [lines]);

  const run = useCallback(
    (raw: string) => {
      const cmd = raw.trim().toLowerCase();
      if (!cmd) return;

      push('in', raw.trim());

      if (cmd === 'clear') {
        setLines([]);
        return;
      }

      switch (cmd) {
        case 'help':
          pushBlock('out', helpText);
          break;
        case 'about':
          pushBlock('out', [
            'name      : Navneet Singh',
            'alias     : HUSTLER',
            'mode      : build fast, break faster, rebuild clean',
            'philosophy: everything else is none of your business.',
          ]);
          break;
        case 'whoami':
          push('ok', 'you: anonymous visitor // ip masked // curiosity detected');
          break;
        case 'skills':
          push('out', `loaded: ${site.stack.join(' · ')}`);
          break;
        case 'schooling':
          push('out', site.schooling);
          break;
        case 'contact':
          pushBlock('out', [
            `email    : ${site.email}`,
            `whatsapp : +91 ${site.whatsapp}`,
            'status   : open to work, open to chaos',
          ]);
          break;
        case 'email':
          push('ok', `target locked: ${site.email} -> running mailto...`);
          window.location.href = `mailto:${site.email}`;
          break;
        case 'whatsapp':
          push('ok', 'opening secure line...');
          window.open(`https://wa.me/${site.whatsappIntl}`, '_blank', 'noopener,noreferrer');
          break;
        case 'projects':
          pushBlock('out', [
            '1. hustler-portfolio   [this site]  status: shipped',
            '2. ghost-audio-engine  [silent]     status: running',
            '3. terminal-ui-kit     [private]    status: in progress',
            'more under nda. yes, really.',
          ]);
          break;
        case 'music':
          push('dim', 'there is a track playing right now. no controls. no proof.');
          break;
        case 'matrix':
          pushBlock('ok', [
            '01001000 01010101 01010011 01010100 01001100 01000101 01010010',
            'wake up. the build is already green.',
          ]);
          break;
        case 'sudo':
        case 'sudo su':
          push('err', 'permission denied: you were never root here.');
          break;
        case 'ls':
          push('out', 'about/  skills/  projects/  terminal/  contact/  .secrets');
          break;
        case 'date':
          push('out', new Date().toString());
          break;
        case 'exit':
          push('err', 'there is no exit. only scroll.');
          break;
        case 'hack':
          push('ok', 'hacking... just kidding. everything here is hand-written typescript.');
          break;
        default:
          push('err', `command not found: ${cmd} — type "help"`);
      }
    },
    [push, pushBlock],
  );

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    run(value);
    setValue('');
  };

  return (
    <section id="terminal" className="relative z-10 border-t border-white/[0.06] py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <Reveal className="mb-12" stagger>
          <div className="font-mono text-[9px] uppercase tracking-[0.4em] text-matrix/70">
            02 / shell
          </div>
          <h2 className="mt-3 font-mono text-4xl font-black uppercase tracking-[-0.02em] text-white sm:text-5xl lg:text-6xl">
            the<span className="text-matrix">_</span>terminal
          </h2>
          <p className="mt-4 max-w-xl text-sm leading-relaxed text-white/50">
            A real interactive shell. Tap the window, then start typing. Try{' '}
            <span className="font-mono text-matrix">help</span>,{' '}
            <span className="font-mono text-matrix">about</span> or{' '}
            <span className="font-mono text-matrix">contact</span>.
          </p>
        </Reveal>

        <div ref={sectionRef}>
          <Reveal>
            <div className="hud-corners relative border border-matrix/25 bg-[#03070a]/95 shadow-[0_0_80px_rgba(0,255,156,0.10)] backdrop-blur-sm">
              <div className="flex items-center justify-between border-b border-matrix/15 bg-matrix/[0.04] px-4 py-2.5">
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-red-500/80" />
                  <span className="h-2 w-2 rounded-full bg-yellow-500/80" />
                  <span className="h-2 w-2 rounded-full bg-matrix/80" />
                  <span className="ml-2 font-mono text-[9.5px] uppercase tracking-[0.24em] text-white/45">
                    hustler@root: ~/portfolio
                  </span>
                </div>
                <span className="hidden font-mono text-[9px] uppercase tracking-[0.24em] text-matrix/60 sm:block">
                  bash · utf-8
                </span>
              </div>

              <div
                ref={bodyRef}
                onClick={() => inputRef.current?.focus()}
                className="h-[320px] cursor-text overflow-y-auto px-4 py-4 font-mono text-[11.5px] leading-[1.75] sm:h-[400px] sm:text-[12.5px]"
              >
                {lines.map((line) => (
                  <div
                    key={line.id}
                    className={
                      line.kind === 'in'
                        ? 'text-white'
                        : line.kind === 'ok'
                          ? 'text-matrix'
                          : line.kind === 'err'
                            ? 'text-[#ff4d6d]'
                            : line.kind === 'dim'
                              ? 'text-white/30'
                              : 'text-white/70'
                    }
                  >
                    {line.kind === 'in' ? (
                      <span className="whitespace-pre-wrap">
                        <span className="text-cyan">visitor@hustler</span>
                        <span className="text-white/40">:~$ </span>
                        {line.text}
                      </span>
                    ) : (
                      <span className="whitespace-pre-wrap">{line.text}</span>
                    )}
                  </div>
                ))}

                <form onSubmit={onSubmit} className="mt-1 flex items-center gap-2">
                  <span className="shrink-0">
                    <span className="text-cyan">visitor@hustler</span>
                    <span className="text-white/40">:~$</span>
                  </span>
                  <input
                    ref={inputRef}
                    value={value}
                    onChange={(e) => setValue(e.target.value)}
                    spellCheck={false}
                    autoComplete="off"
                    autoCapitalize="none"
                    aria-label="Terminal input"
                    className="terminal-input w-full flex-1 border-none bg-transparent font-mono text-[11.5px] text-white outline-none placeholder:text-white/20 sm:text-[12.5px]"
                    placeholder="type a command..."
                  />
                </form>
              </div>

              <div className="flex flex-wrap items-center gap-2 border-t border-matrix/10 bg-black/50 px-4 py-2.5">
                {['help', 'about', 'contact', 'projects', 'matrix'].map((cmd) => (
                  <motion.button
                    key={cmd}
                    type="button"
                    whileHover={{ y: -1 }}
                    whileTap={{ scale: 0.96 }}
                    onClick={() => run(cmd)}
                    className="border border-matrix/25 bg-matrix/[0.05] px-2.5 py-1 font-mono text-[9.5px] uppercase tracking-[0.18em] text-matrix/80 transition-colors hover:border-matrix hover:text-matrix"
                  >
                    {cmd}
                  </motion.button>
                ))}
                <button
                  type="button"
                  onClick={() => setLines([])}
                  className="ml-auto font-mono text-[9px] uppercase tracking-[0.22em] text-white/25 transition-colors hover:text-[#ff4d6d]"
                >
                  clear
                </button>
              </div>
            </div>
          </Reveal>

          <Reveal className="mt-6 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => scrollToSection('#contact')}
              className="font-mono text-[10px] uppercase tracking-[0.28em] text-matrix/70 underline decoration-matrix/30 underline-offset-4 transition-colors hover:text-matrix"
            >
              skip the shell, just hire me →
            </button>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
