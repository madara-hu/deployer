'use client';

import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { scrollToSection } from '@/lib/utils';

type MagneticButtonProps = {
  children: React.ReactNode;
  href?: string;
  target?: string;
  scrollTo?: string;
  onClick?: () => void;
  variant?: 'solid' | 'ghost';
  className?: string;
  strength?: number;
  ariaLabel?: string;
};

export default function MagneticButton({
  children,
  href,
  target,
  scrollTo,
  onClick,
  variant = 'solid',
  className = '',
  strength = 0.35,
  ariaLabel,
}: MagneticButtonProps) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const innerRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const wrap = wrapRef.current;
    const inner = innerRef.current;
    if (!wrap || !inner) return;

    const fine = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!fine || reduce) return;

    const xTo = gsap.quickTo(wrap, 'x', { duration: 0.6, ease: 'power3.out' });
    const yTo = gsap.quickTo(wrap, 'y', { duration: 0.6, ease: 'power3.out' });
    const ixTo = gsap.quickTo(inner, 'x', { duration: 0.9, ease: 'power3.out' });
    const iyTo = gsap.quickTo(inner, 'y', { duration: 0.9, ease: 'power3.out' });

    const onMove = (e: PointerEvent) => {
      const r = wrap.getBoundingClientRect();
      const relX = e.clientX - (r.left + r.width / 2);
      const relY = e.clientY - (r.top + r.height / 2);
      xTo(relX * strength);
      yTo(relY * strength);
      ixTo(relX * strength * 0.45);
      iyTo(relY * strength * 0.45);
    };

    const onLeave = () => {
      xTo(0);
      yTo(0);
      ixTo(0);
      iyTo(0);
    };

    wrap.addEventListener('pointermove', onMove);
    wrap.addEventListener('pointerleave', onLeave);

    return () => {
      wrap.removeEventListener('pointermove', onMove);
      wrap.removeEventListener('pointerleave', onLeave);
    };
  }, [strength]);

  const base =
    'group relative inline-flex items-center justify-center gap-2 overflow-hidden px-7 py-3.5 font-mono text-[11px] font-bold uppercase tracking-[0.28em] transition-colors duration-300';
  const styles =
    variant === 'solid'
      ? 'bg-matrix text-black shadow-neon hover:bg-[#33ffb1]'
      : 'border border-matrix/40 bg-matrix/[0.04] text-matrix hover:border-matrix hover:bg-matrix/10';

  const content = (
    <>
      <span
        aria-hidden
        className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/25 to-transparent transition-transform duration-700 group-hover:translate-x-full"
      />
      <span ref={innerRef} className="relative z-10 flex items-center gap-2">
        {children}
      </span>
    </>
  );

  const handleClick = (e: React.MouseEvent) => {
    if (scrollTo) {
      e.preventDefault();
      scrollToSection(scrollTo);
    }
    onClick?.();
  };

  return (
    <div ref={wrapRef} className={`inline-block ${className}`}>
      {href ? (
        <a
          href={href}
          target={target}
          rel={target === '_blank' ? 'noopener noreferrer' : undefined}
          aria-label={ariaLabel}
          onClick={handleClick}
          className={`${base} ${styles}`}
        >
          {content}
        </a>
      ) : (
        <button type="button" aria-label={ariaLabel} onClick={handleClick} className={`${base} ${styles}`}>
          {content}
        </button>
      )}
    </div>
  );
}
