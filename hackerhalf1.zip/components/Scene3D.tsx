'use client';

import { useMemo, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { AdaptiveDpr, Float } from '@react-three/drei';
import * as THREE from 'three';

function WireGlobe() {
  const group = useRef<THREE.Group>(null);
  const inner = useRef<THREE.Mesh>(null);

  useFrame((state, delta) => {
    if (group.current) {
      group.current.rotation.y += delta * 0.12;
      group.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.18) * 0.16;
    }
    if (inner.current) {
      inner.current.rotation.y -= delta * 0.3;
      inner.current.rotation.z += delta * 0.06;
    }
  });

  return (
    <group ref={group}>
      <mesh>
        <icosahedronGeometry args={[1.72, 3]} />
        <meshBasicMaterial color="#00ff9c" wireframe transparent opacity={0.16} />
      </mesh>
      <mesh ref={inner} scale={0.985}>
        <icosahedronGeometry args={[1.72, 1]} />
        <meshBasicMaterial color="#22e6ff" wireframe transparent opacity={0.2} />
      </mesh>
      <mesh>
        <sphereGeometry args={[1.9, 32, 32]} />
        <meshBasicMaterial color="#00ff9c" transparent opacity={0.03} side={THREE.BackSide} />
      </mesh>
    </group>
  );
}

function ParticleShell({ count }: { count: number }) {
  const points = useRef<THREE.Points>(null);

  const positions = useMemo(() => {
    const arr = new Float32Array(count * 3);
    for (let i = 0; i < count; i += 1) {
      const r = 2.1 + Math.random() * 1.9;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      arr[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      arr[i * 3 + 1] = r * Math.cos(phi) * 0.75;
      arr[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta);
    }
    return arr;
  }, [count]);

  useFrame((_, delta) => {
    if (points.current) {
      points.current.rotation.y += delta * 0.05;
      points.current.rotation.x += delta * 0.012;
    }
  });

  return (
    <points ref={points}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial
        color="#22e6ff"
        size={0.022}
        sizeAttenuation
        transparent
        opacity={0.75}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

function OrbitRing({ radius, tilt, speed }: { radius: number; tilt: number; speed: number }) {
  const mesh = useRef<THREE.Mesh>(null);

  useFrame((_, delta) => {
    if (mesh.current) mesh.current.rotation.z += delta * speed;
  });

  return (
    <mesh ref={mesh} rotation={[tilt, 0.2, 0]}>
      <torusGeometry args={[radius, 0.0035, 8, 128]} />
      <meshBasicMaterial color="#00ff9c" transparent opacity={0.4} />
    </mesh>
  );
}

function Rig() {
  useFrame((state) => {
    const { pointer, camera } = state;
    camera.position.x += (pointer.x * 0.45 - camera.position.x) * 0.04;
    camera.position.y += (pointer.y * 0.3 - camera.position.y) * 0.04;
    camera.lookAt(0, 0, 0);
  });
  return null;
}

export default function Scene3D() {
  const isSmall = typeof window !== 'undefined' ? window.innerWidth < 768 : true;

  return (
    <Canvas
      dpr={[1, isSmall ? 1.35 : 1.75]}
      gl={{ antialias: !isSmall, alpha: true, powerPreference: 'high-performance' }}
      camera={{ position: [0, 0, 5.2], fov: 45 }}
      style={{ pointerEvents: 'none' }}
    >
      <AdaptiveDpr pixelated />
      <Rig />
      <Float speed={1.1} rotationIntensity={0.25} floatIntensity={0.7}>
        <group position={[0, 0.1, 0]} scale={isSmall ? 0.82 : 1}>
          <WireGlobe />
          <OrbitRing radius={2.5} tilt={1.2} speed={0.22} />
          <OrbitRing radius={2.95} tilt={1.75} speed={-0.16} />
          <ParticleShell count={isSmall ? 420 : 900} />
        </group>
      </Float>
      <gridHelper args={[26, 26, '#0a3d28', '#05130e']} position={[0, -2.6, 0]} />
      <fog attach="fog" args={['#000000', 6, 14]} />
    </Canvas>
  );
}
