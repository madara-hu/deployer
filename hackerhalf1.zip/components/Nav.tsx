'use client';

import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { scrollToSection } from '@/lib/utils';
import { site } from '@/lib/site';

const links = [
  { label: 'ABOUT', target: '#about' },
  { label: 'TERMINAL', target: '#terminal' },
  { label: 'CONTACT', target: '#contact' },
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -70, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1], delay: 0.15 }}
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'border-b border-matrix/15 bg-black/80 backdrop-blur-xl'
          : 'border-b border-transparent bg-transparent'
      }`}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3.5 sm:px-8">
        <button
          type="button"
          onClick={() => scrollToSection('#hero')}
          className="group flex items-center gap-2.5"
          aria-label="Back to top"
        >
          <span className="relative flex h-8 w-8 items-center justify-center border border-matrix/50 bg-matrix/5">
            <span className="font-mono text-[13px] font-black text-matrix">H</span>
            <span className="absolute -right-px -top-px h-1.5 w-1.5 bg-cyan" />
          </span>
          <span className="hidden font-mono text-[11px] font-bold uppercase tracking-[0.34em] text-white/70 sm:inline">
            Hustler<span className="text-matrix">//</span>root
          </span>
        </button>

        <div className="hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <button
              key={l.target}
              type="button"
              onClick={() => scrollToSection(l.target)}
              data-cursor="GO"
              className="group relative px-4 py-2 font-mono text-[10px] font-semibold uppercase tracking-[0.28em] text-white/55 transition-colors hover:text-matrix"
            >
              {l.label}
              <span className="absolute inset-x-3 bottom-1 h-px scale-x-0 bg-matrix transition-transform duration-300 group-hover:scale-x-100" />
            </button>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <span className="hidden items-center gap-2 font-mono text-[9px] uppercase tracking-[0.28em] text-matrix/80 sm:flex">
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-matrix opacity-75" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-matrix" />
            </span>
            online
          </span>
          <a
            href={`https://wa.me/${site.whatsappIntl}`}
            target="_blank"
            rel="noopener noreferrer"
            data-cursor="CHAT"
            className="hidden border border-matrix/40 px-4 py-2 font-mono text-[10px] font-bold uppercase tracking-[0.24em] text-matrix transition-colors hover:bg-matrix hover:text-black sm:block"
          >
            ping me
          </a>
          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            aria-label="Toggle menu"
            className="flex h-9 w-9 flex-col items-center justify-center gap-1.5 border border-matrix/30 md:hidden"
          >
            <span
              className={`h-px w-4 bg-matrix transition-transform ${open ? 'translate-y-[3px] rotate-45' : ''}`}
            />
            <span
              className={`h-px w-4 bg-matrix transition-transform ${open ? '-translate-y-[3px] -rotate-45' : ''}`}
            />
          </button>
        </div>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="overflow-hidden border-t border-matrix/15 bg-black/95 md:hidden"
          >
            <div className="flex flex-col px-5 py-3">
              {links.map((l, i) => (
                <button
                  key={l.target}
                  type="button"
                  onClick={() => {
                    setOpen(false);
                    scrollToSection(l.target);
                  }}
                  className="flex items-center justify-between border-b border-white/5 py-3.5 text-left font-mono text-[11px] uppercase tracking-[0.3em] text-white/70"
                >
                  <span>{l.label}</span>
                  <span className="text-matrix/60">0{i + 1}</span>
                </button>
              ))}
              <a
                href={`https://wa.me/${site.whatsappIntl}`}
                target="_blank"
                rel="noopener noreferrer"
                className="py-4 font-mono text-[11px] uppercase tracking-[0.3em] text-matrix"
              >
                whatsapp · {site.whatsapp}
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
