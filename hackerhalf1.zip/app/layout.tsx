import type { Metadata, Viewport } from 'next';
import './globals.css';
import SmoothScroll from '@/components/SmoothScroll';
import CustomCursor from '@/components/CustomCursor';
import AudioGhost from '@/components/AudioGhost';

export const metadata: Metadata = {
  metadataBase: new URL('https://hustler-portfolio.pages.dev'),
  title: 'HUSTLER // Navneet Singh',
  description:
    'HUSTLER — rogue developer portfolio of Navneet Singh. Coding, breaking, rebuilding. Terminal-grade interfaces, 3D visuals, zero excuses.',
  keywords: [
    'Hustler',
    'Navneet Singh',
    'portfolio',
    'hacker portfolio',
    'Next.js developer',
    'full stack developer Bihar',
    'Termux',
  ],
  authors: [{ name: 'Navneet Singh' }],
  openGraph: {
    title: 'HUSTLER // Navneet Singh',
    description: 'Coding. Hacking. Building the future.',
    type: 'website',
    images: ['/photo.png'],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'HUSTLER // Navneet Singh',
    description: 'Coding. Hacking. Building the future.',
    images: ['/photo.png'],
  },
  icons: {
    icon: '/icon.svg',
  },
};

export const viewport: Viewport = {
  themeColor: '#000000',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@300;400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="fx-scanlines fx-vignette bg-void text-[#d7e2e0] antialiased">
        <SmoothScroll />
        <CustomCursor />
        <AudioGhost />
        {children}
      </body>
    </html>
  );
}
