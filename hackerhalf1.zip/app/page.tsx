import Nav from '@/components/Nav';
import SceneBackground from '@/components/SceneBackground';
import Hero from '@/components/Hero';
import About from '@/components/About';
import StackMarquee from '@/components/StackMarquee';
import TerminalSection from '@/components/TerminalSection';
import Contact from '@/components/Contact';

export default function Home() {
  return (
    <main className="relative min-h-screen bg-void">
      <SceneBackground />
      <Nav />
      <Hero />
      <StackMarquee />
      <About />
      <TerminalSection />
      <Contact />
    </main>
  );
}
