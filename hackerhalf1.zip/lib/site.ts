export const site = {
  name: 'HUSTLER',
  realName: 'Navneet Singh',
  email: 'navneetsingh88077@gmail.com',
  whatsapp: '7632978903',
  whatsappIntl: '917632978903',
  location: 'Bihar Sharif, Bihar, IN',
  roles: ['Coding...', 'Hacking...', 'Building the future...'],
  bio: 'I am interested in coding and breaking things to build them better. Everything else is none of your business. Fuck out of my business.',
  schooling: 'Passed schooling from DAV BSF Bihar Sharif.',
  stack: [
    'TypeScript',
    'Next.js',
    'React',
    'Tailwind CSS',
    'GSAP',
    'Framer Motion',
    'Three.js',
    'React Three Fiber',
    'Firebase',
    'Cloudflare',
    'Node.js',
    'Git',
    'Termux',
    'Codespaces',
  ],
} as const;

export type TerminalLine = {
  kind: 'in' | 'out' | 'err' | 'ok';
  text: string;
};
