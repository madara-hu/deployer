'use client';

import { useEffect, useRef, useState } from 'react';

export function useTypewriter(words: readonly string[], speed = 70, backspace = 34, hold = 1300) {
  const [text, setText] = useState('');
  const [index, setIndex] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const current = words[index % words.length];
    let timeout: number;

    if (!deleting && text === current) {
      timeout = window.setTimeout(() => setDeleting(true), hold);
    } else if (deleting && text === '') {
      setDeleting(false);
      setIndex((i) => (i + 1) % words.length);
      timeout = window.setTimeout(() => undefined, 120);
    } else {
      timeout = window.setTimeout(
        () => {
          setText(
            deleting ? current.slice(0, text.length - 1) : current.slice(0, text.length + 1),
          );
        },
        deleting ? backspace : speed,
      );
    }

    return () => window.clearTimeout(timeout);
  }, [text, deleting, index, words, speed, backspace, hold]);

  return text;
}

export function useInViewOnce<T extends HTMLElement>(threshold = 0.25) {
  const ref = useRef<T | null>(null);
  const [seen, setSeen] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el || seen) return;

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setSeen(true);
            io.disconnect();
          }
        });
      },
      { threshold },
    );

    io.observe(el);
    return () => io.disconnect();
  }, [seen, threshold]);

  return { ref, seen };
}
