'use client';

type LenisWindow = Window & { __lenis?: { scrollTo: (target: string | number | HTMLElement, opts?: Record<string, unknown>) => void } };

export function scrollToSection(id: string) {
  if (typeof window === 'undefined') return;
  const el = document.querySelector(id);
  if (!el) return;

  const lenis = (window as LenisWindow).__lenis;
  if (lenis) {
    lenis.scrollTo(el as HTMLElement, { offset: 0, duration: 1.4 });
    return;
  }
  (el as HTMLElement).scrollIntoView({ behavior: 'smooth', block: 'start' });
}

export async function copyText(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    ta.style.top = '-1000px';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return ok;
  } catch {
    return false;
  }
}
